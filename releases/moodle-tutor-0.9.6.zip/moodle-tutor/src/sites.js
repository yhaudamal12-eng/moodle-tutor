// Which Moodle the student uses. The Hebrew University is the default; any other Moodle is connected
// by its address, and the extension works out from it whether the site changes every academic year.
//
// Three year patterns seen in Israeli universities:
//   path "2026-27"   moodle.huji.ac.il/2026-27        (checked 15.10.2026)
//   path "2026"      moodle.tau.ac.il/2026
//   host "moodle26"  moodle26.technion.ac.il
// Anything else is one site for all years.

export const HUJI = 'https://moodle.huji.ac.il';

const startYear = year => Number(String(year).slice(0, 4));

// From the address of the site's front page (Moodle's wwwroot): its parts and its year pattern.
export function siteFrom(wwwroot) {
  const u = new URL(String(wwwroot).replace(/\/+$/, ''));
  const origin = u.origin;
  const path = u.pathname.replace(/\/+$/, '');
  const segs = path.split('/').filter(Boolean);
  const last = segs[segs.length - 1] || '';
  let style = 'fixed';
  if (/^\d{4}-\d{2}$/.test(last)) style = 'path-range';
  else if (/^20\d{2}$/.test(last)) style = 'path-year';
  else if (/^moodle\d{2}\./.test(u.host)) style = 'host-yy';
  const base = style.startsWith('path') ? origin + '/' + segs.slice(0, -1).join('/') : origin;
  return { root: origin + path, origin, host: u.host, style, base: base.replace(/\/+$/, '') };
}

// The site for a given academic year ("2026-27").
export function rootFor(site, year) {
  if (!site) return `${HUJI}/${year}`;
  const y = startYear(year);
  if (site.style === 'path-range') return `${site.base}/${year}`;
  if (site.style === 'path-year') return `${site.base}/${y}`;
  if (site.style === 'host-yy') return `https://${site.host.replace(/^moodle\d{2}\./, `moodle${String(y).slice(2)}.`)}`;
  return site.root;
}

export const changesYearly = site => !site || site.style !== 'fixed';

// The pattern of tabs that belong to the student's Moodle, for every year.
export function tabPattern(site) {
  if (!site) return `${HUJI}/*`;
  // Match patterns allow a wildcard only as the first part of a host.
  if (site.style === 'host-yy') return `https://*.${site.host.replace(/^moodle\d{2}\./, '')}/*`;
  return `${site.origin}/*`;
}
export function originPattern(site) { return tabPattern(site); }

// Where a request ended up when the login expired: the university's sign-in pages. A redirect to any
// other outside site (a course link, a video) is not a sign-in page and must not stop a scan.
const LOGIN = /\/login\/index\.php|\/\/idp\.|\/idp\/|saml|\/\/sso\.|\/sso\/|\/\/auth\.|login\.microsoftonline\.com|accounts\.google\.com\/(?:o\/oauth|signin|ServiceLogin)|\/cas\/login|shibboleth|\/adfs\//i;
export function isLoginUrl(url) {
  return !!url && LOGIN.test(url);
}

// Suggestions in the setup screen. Addresses other than the Hebrew University are where those
// universities' Moodle sites were found, and are checked when the student connects.
export const KNOWN = [
  { id: 'huji', name: 'האוניברסיטה העברית', url: HUJI },
  { id: 'technion', name: 'הטכניון', url: 'https://moodle26.technion.ac.il' },
  { id: 'biu', name: 'בר־אילן', url: 'https://lemida.biu.ac.il' },
  { id: 'ariel', name: 'אוניברסיטת אריאל', url: 'https://moodlearn.ariel.ac.il' },
  { id: 'tau', name: 'תל אביב', url: 'https://moodle.tau.ac.il' },
];
