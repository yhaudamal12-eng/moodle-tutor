// Panopto auto-transcripts are often useless (wrong language, bad audio, a silent room).
// A transcript is used only if it passes these checks; otherwise the recording is ignored.

export function parseSrt(srt) {
  const cues = [];
  for (const block of srt.replace(/\r/g, '').split(/\n\n+/)) {
    const lines = block.trim().split('\n');
    const t = lines.find(l => l.includes('-->'));
    if (!t) continue;
    const [a, b] = t.split('-->').map(s => toMs(s.trim()));
    const text = lines.slice(lines.indexOf(t) + 1).join(' ').replace(/\[Auto-generated[^\]]*\]/i, '').trim();
    if (text) cues.push({ start: a, end: b, text });
  }
  return cues;
}

function toMs(s) {
  const m = s.match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return m ? ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * 1000 + +m[4] : 0;
}

// expectedLang: 'he' or 'en' (the language the lecture is given in), or null if unknown.
export function transcriptQuality(srt, { expectedLang = null } = {}) {
  const cues = parseSrt(srt || '');
  const reasons = [];
  if (cues.length < 20) return { usable: false, reasons: ['too-short'], stats: { cues: cues.length } };

  const text = cues.map(c => c.text).join(' ');
  const words = text.split(/\s+/).filter(Boolean);
  const minutes = Math.max(1, (cues[cues.length - 1].end - cues[0].start) / 60000);
  const wpm = words.length / minutes;
  const hebrew = (text.match(/[֐-׿]/g) || []).length;
  const latin = (text.match(/[A-Za-z]/g) || []).length;
  const hebShare = hebrew / Math.max(1, hebrew + latin);
  const lang = hebShare > 0.5 ? 'he' : 'en';

  // A lecture runs at roughly 100-160 words a minute. Far below that = mostly silence or noise.
  if (wpm < 40) reasons.push('too-sparse');
  // Hebrew lecture transcribed as English (or the reverse) produces fluent-looking nonsense.
  if (expectedLang && expectedLang !== lang) reasons.push('wrong-language');
  // Many tiny fragments ("And. Then.") is the signature of a failed recognition.
  const tiny = cues.filter(c => c.text.split(/\s+/).length <= 3).length / cues.length;
  if (tiny > 0.4) reasons.push('fragmented');
  // The same short phrase over and over.
  const counts = new Map();
  for (const c of cues) counts.set(c.text, (counts.get(c.text) || 0) + 1);
  const repeated = Math.max(...counts.values()) / cues.length;
  if (repeated > 0.15) reasons.push('repetitive');

  return { usable: reasons.length === 0, reasons, stats: { cues: cues.length, wpm: Math.round(wpm), lang, tiny: +tiny.toFixed(2) } };
}

// Lecture language guess from the course: mostly Hebrew names/sections -> 'he'.
export function guessCourseLanguage(names) {
  const text = names.join(' ');
  const he = (text.match(/[֐-׿]/g) || []).length;
  const en = (text.match(/[A-Za-z]/g) || []).length;
  if (he + en < 20) return null;
  return he > en * 0.6 ? 'he' : 'en';
}
