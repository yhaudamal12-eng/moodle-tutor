// One Claude project per course, kept up to date from Moodle. Pure functions: what to upload,
// the course map the tutor reads, and the project instructions. No browser APIs here.

import { semesterOf } from './semester.js';
import { MODES, INTAKE, FIRST_TIME, STYLES, STYLE_COMMON, BASE_RULES, RTL_RULES, PROFILE_TEXT, CATEGORY_LABEL, courseFiles } from './session.js';

export const MAX_FILE_BYTES = 30 * 1024 * 1024;   // Claude's per-file limit
export const MAP_NAME = 'מפת הקורס.md';
export const PROGRESS_NAME = 'התקדמות.md';
const MARK_START = '=== הוראות המורה הפרטי (התוסף מעדכן את החלק הזה) ===';
const MARK_END = '=== סוף הוראות התוסף ===';

const fileKey = f => `${f.cmid}|${String(f.url).replace(/\/content\/\d+\//, '/content/X/').replace(/[?#].*$/, '')}`;
const sigOf = f => `${f.etag || ''}|${f.size || ''}`;

// Why a course file does not go into the project, or null if it does.
export function skipReason(f, maxBytes = MAX_FILE_BYTES) {
  if (/^(video|audio)\//.test(f.type || '') || /\.(mp4|mov|mkv|avi|webm|m4v|mp3|m4a|wav)$/i.test(f.filename)) return 'הקלטה או סרטון';
  if (/\.(zip|rar|7z|exe|dmg|iso)$/i.test(f.filename)) return 'קובץ מכווץ או תוכנה';
  if (f.size && f.size > maxBytes) return `גדול מ־${Math.round(maxBytes / 1048576)} מגה`;
  return null;
}

// When a service limits the number of files, the most useful ones go in first.
const IMPORTANCE = ['syllabus', 'exam-solution', 'solution', 'summary', 'exam', 'assignment', 'slides', 'lecture', 'tutorial', 'other'];
const importance = f => { const i = IMPORTANCE.indexOf(f.category); return (i < 0 ? IMPORTANCE.length : i) * 2 + (f.material === 'current' ? 0 : 1); };

function dated(name, when) {
  const d = `${String(when.getDate()).padStart(2, '0')}.${String(when.getMonth() + 1).padStart(2, '0')}`;
  const m = name.match(/^(.*?)(\.[^.]+)?$/);
  return `${m[1]} (עודכן ${d})${m[2] || ''}`;
}

// What to do now. record = what this extension already put in the project:
//   { files: { key: {uuid, name, sig} }, superseded: [{uuid, name, by}], failed: {key: why} }
// projectFiles = the files the project holds right now (from Claude).
export function planSync(course, record = {}, projectFiles = [], when = new Date(), limits = {}) {
  const maxBytes = limits.maxFileBytes || MAX_FILE_BYTES;
  const maxFiles = limits.maxFiles ?? Infinity;
  const files = courseFiles(course).sort((a, b) => importance(a) - importance(b));
  const rec = record.files || {};
  const upload = [], adopt = [], skipped = [], overflow = [];
  let room = maxFiles - projectFiles.length;
  const taken = new Set(projectFiles.map(f => f.file_name));
  for (const f of files) {
    const key = fileKey(f);
    const why = skipReason(f, maxBytes);
    if (why) { skipped.push({ file: f, why }); continue; }
    const have = rec[key];
    if (have && have.sig === sigOf(f)) continue;
    if (room <= 0) { overflow.push({ file: f, why: 'מעבר למספר הקבצים שהשירות מאפשר' }); continue; }
    if (!have) {
      // A project linked after the student uploaded files by hand: the same file is not sent twice.
      const same = projectFiles.find(p => p.file_name === f.filename && (!f.size || !p.size_bytes || p.size_bytes === f.size));
      if (same) { adopt.push({ key, file: f, uuid: same.file_uuid || same.uuid, name: same.file_name, sig: sigOf(f) }); continue; }
    }
    let name = have ? dated(f.filename, when) : f.filename;
    for (let i = 2; taken.has(name); i++) name = name.replace(/(?: \(\d+\))?(\.[^.]+)?$/, ` (${i})$1`);
    taken.add(name);
    upload.push({ key, file: f, name, sig: sigOf(f), replaces: have ? { uuid: have.uuid, name: have.name } : null });
    room--;
  }
  return { upload, adopt, skipped, overflow };
}

// Applies upload results to the record.
export function recordUploads(record = {}, done = [], failed = []) {
  const r = { ...record, files: { ...(record.files || {}) }, superseded: [...(record.superseded || [])], failed: { ...(record.failed || {}) } };
  for (const d of done) {
    if (d.replaces) r.superseded.push({ uuid: d.replaces.uuid, name: d.replaces.name, by: d.name });
    r.files[d.key] = { uuid: d.uuid, name: d.name, sig: d.sig };
    delete r.failed[d.key];
  }
  for (const f of failed) r.failed[f.key] = f.why;
  return r;
}

const MATERIAL = { current: 'מהסמסטר הנוכחי', support: 'חומר עזר משנים קודמות' };

// The course map: what every file in the project is. Rewritten after each sync.
export function courseMap(course, record = {}, { recordings = [], when = new Date(), year = '', overflow = [] } = {}) {
  const left = new Set(overflow.map(o => o.file && o.file.url));
  const files = courseFiles(course);
  const rec = record.files || {};
  const L = [];
  const name = (course.short || course.name || '').replace(/^\d+(?:_\d+)?-/, '');
  L.push(`# מפת הקורס: ${name}`);
  L.push('');
  const sem = semesterOf(course);
  if (sem.key !== '?') L.push(`${sem.label}, שנת הלימודים ${year || ''}`.trim());
  L.push(`הקובץ נכתב אוטומטית מתוך אתר הקורס במודל (${year}), ומתעדכן בכל סריקה. עודכן לאחרונה: ${when.toISOString().slice(0, 10)}.`);
  L.push('לכל קובץ בפרויקט: מה הוא, באיזה נושא הוא נמצא במודל, והאם הוא מהסמסטר הנוכחי או חומר עזר משנים קודמות.');
  const bySection = new Map();
  for (const f of files) { const s = f.section || 'כללי'; if (!bySection.has(s)) bySection.set(s, []); bySection.get(s).push(f); }
  for (const [sec, fs] of bySection) {
    L.push(''); L.push(`## ${sec}`);
    for (const f of fs) {
      const r = rec[fileKey(f)];
      const why = skipReason(f);
      const tag = [CATEGORY_LABEL[f.category] || 'חומר', MATERIAL[f.material] || null, f.item && f.item !== f.filename ? `בפריט "${f.item}"` : null].filter(Boolean).join(', ');
      if (r) L.push(`- ${tag}: ${r.name}`);
      else if (why) L.push(`- ${tag}: ${f.filename} (לא בפרויקט: ${why})`);
      else if (left.has(f.url)) L.push(`- ${tag}: ${f.filename} (לא בפרויקט: אין מקום לעוד קבצים)`);
      else L.push(`- ${tag}: ${f.filename} (עוד לא הועלה)`);
    }
  }
  const sup = record.superseded || [];
  if (sup.length) {
    L.push(''); L.push('## גרסאות ישנות');
    L.push('המרצה החליף את הקבצים האלה בגרסה חדשה. אל תסתמך עליהם.');
    for (const s of sup) L.push(`- גרסה ישנה: ${s.name}, הוחלפה ב־${s.by}`);
  }
  if (recordings.length) {
    L.push(''); L.push('## הקלטות');
    L.push('ההקלטות לא נמצאות בפרויקט.');
    for (const r of recordings) L.push(`- הקלטה: ${r.title}`);
  }
  return L.join('\n') + '\n';
}

export function progressTemplate(course) {
  const name = (course.short || course.name || '').replace(/^\d+(?:_\d+)?-/, '');
  return `# התקדמות: ${name}\n\nהקובץ מתעדכן אוטומטית מהסיכומים שבסוף השיחות. אפשר לערוך אותו.\n\nעוד אין שיעורים.\n`;
}

export function progressDoc(course, t = {}) {
  const name = (course.short || course.name || '').replace(/^\d+(?:_\d+)?-/, '');
  const L = [`# התקדמות: ${name}`, '', 'הקובץ מתעדכן אוטומטית מהסיכומים שבסוף השיחות. אפשר לערוך אותו.'];
  const topics = Object.entries(t.topics || {});
  if (topics.length) {
    const dates = t.topicDates || {};
    const dm = d => d ? ` (עודכן ${d.slice(8, 10)}.${d.slice(5, 7)})` : '';
    L.push('', '## מצב הנושאים'); for (const [k, v] of topics) L.push(`- ${k}: ${v}${dm(dates[k])}`);
  }
  const ss = t.sessions || [];
  if (ss.length) {
    L.push('', '## שיעורים אחרונים');
    for (const s of ss.slice(0, 8)) L.push(`- בתאריך ${s.date}: נלמד ${s.learned || '—'}. קשיים: ${s.struggles || '—'}. הצעד הבא: ${s.next || '—'}`);
  }
  const pf = t.prefs;
  if (pf) {
    L.push('', '## ההעדפות שלי');
    for (const [k, lbl] of [['goal', 'מטרה'], ['background', 'רקע'], ['exam', 'מבחן'], ['explain', 'הסבר'], ['style', 'סגנון'], ['hard', 'קשיים'], ['extra', 'עוד']]) if (pf[k]) L.push(`- ${lbl}: ${pf[k]}`);
  }
  const tips = t.tips || [];
  if (tips.length) { L.push('', '## דגשים מתרגילים'); for (const r of tips) L.push(`- ${r.text} (נרשם ${r.date.slice(8, 10)}.${r.date.slice(5, 7)})`); }
  const review = t.review || [];
  if (review.length) { L.push('', '## לחזרה'); for (const r of review) L.push(`- ${r.text} (נרשם ${r.date.slice(8, 10)}.${r.date.slice(5, 7)})`); }
  if (t.lecturer && t.lecturer.trim()) { L.push('', '## על המרצה'); for (const l of t.lecturer.trim().split('\n')) L.push(`- ${l.replace(/^-\s*/, '')}`); }
  if (!topics.length && !ss.length) L.push('', 'עוד אין שיעורים.');
  return L.join('\n') + '\n';
}

// The project instructions. The student says in the chat what they want; the tutor picks the way.
export function projectInstructions(course, profile = {}, { lang = 'he' } = {}) {
  const name = (course.short || course.name || '').replace(/^\d+(?:_\d+)?-/, '');
  const L = [MARK_START];
  L.push(`אתה המורה הפרטי שלי בקורס ${name}. כל קבצי הקורס נמצאים בידע של הפרויקט, ומתעדכנים אוטומטית מאתר הקורס.`);
  L.push('הוראות שכתבתי בעצמי, מחוץ לחלק הזה, גוברות על ההוראות שבו.');
  L.push('');
  L.push('בתחילת כל שיחה:');
  L.push(`- קרא את "${MAP_NAME}": הוא אומר מה כל קובץ, באיזה נושא, ואם הוא מהסמסטר הנוכחי או חומר עזר משנים קודמות. קבצים שמסומנים כגרסה ישנה לא בתוקף.`);
  L.push(`- קרא את "${PROGRESS_NAME}": מה כבר למדנו, איפה התקשיתי, מה הצעד הבא, ומה ההעדפות שלי.`);
  L.push('- הבן מההודעה שלי מה אני צריך עכשיו, ובחר את דרך העבודה המתאימה. אם לא ברור, שאל שאלה אחת קצרה.');
  L.push('');
  L.push('שיחת היכרות, פעם אחת בקורס:');
  for (const r of INTAKE) L.push(r.startsWith('  ') ? `  - ${r.trim()}` : `- ${r}`);
  L.push('');
  L.push('לימוד נושא חדש:');
  for (const r of FIRST_TIME) L.push(`- ${r}`);
  L.push('');
  const style = STYLES[profile.style] || STYLES.active;
  L.push(`סגנון הלמידה שבחרתי: ${style.label}.`);
  for (const r of [...style.rules, ...STYLE_COMMON]) L.push(`- ${r}`);
  L.push('');
  L.push('דרכי עבודה:');
  for (const m of Object.values(MODES)) L.push(`- ${m.label}: ${m.goal} ${m.rules.join(' ')}`);
  L.push('');
  L.push('כללים:');
  for (const r of BASE_RULES) L.push(`- ${r}`);
  if (lang === 'he') { L.push('- השפה: עברית, אלא אם אבקש אחרת.'); for (const r of RTL_RULES) L.push(`- ${r}`); }
  const p = [];
  if (profile.kind) p.push(`אופי הקורס: ${PROFILE_TEXT.kind[profile.kind] || profile.kind}`);
  if (profile.examFormat) p.push(`פורמט המבחן: ${PROFILE_TEXT.examFormat[profile.examFormat] || profile.examFormat}`);
  if (profile.formulaSheet !== undefined) p.push(profile.formulaSheet ? 'יש דף נוסחאות במבחן' : 'אין דף נוסחאות במבחן, ולכן צריך לזכור נוסחאות בעל פה');
  if (profile.background) p.push(`הרקע שלי: ${PROFILE_TEXT.background[profile.background] || profile.background}`);
  if (profile.notes) p.push(profile.notes);
  const pr = profile.prefs || {};
  for (const [k, lbl] of [['goal', 'המטרה שלי'], ['explain', 'איך להסביר לי'], ['hard', 'מה מקשה עליי'], ['extra', 'עוד ממני']]) if (pr[k]) p.push(`${lbl}: ${pr[k]}`);
  if (p.length) { L.push(''); L.push('על הקורס ועליי:'); for (const x of p) L.push(`- ${x}`); }
  L.push('');
  L.push('בלוק ההעדפות, בסוף שיחת ההיכרות (התוסף שומר אותו לכל הצ\'אטים של הקורס):');
  L.push('### העדפות');
  L.push('מטרה: ...');
  L.push('רקע: ...');
  L.push('מבחן: מתי, הפורמט (שאלות פתוחות / אמריקאי / משולב), ויש או אין דף נוסחאות');
  L.push('הסבר: איך אני אוהב שמסבירים לי');
  L.push('סגנון: פעילה או זורמת');
  L.push('קשיים: ...');
  L.push('עוד: מה שאמרתי בשאלה הפתוחה');
  L.push('### סוף');
  L.push('');
  L.push('סיום שיעור: כשאכתוב "סיום", החזר את הבלוק הבא, בשורות קצרות. התוסף מעביר אותו לקובץ ההתקדמות.');
  L.push('- אם בשיחה פתרנו תרגיל או שיעורי בית, ועוד לא כתבת עליו סיכום תרגיל מקוצר, כתוב אותו לפני הבלוק.');
  L.push('### סיכום סשן');
  L.push('נלמד: ...');
  L.push('קשיים: ...');
  L.push('הצעד הבא: ...');
  L.push('לחזרה: שאלות או נקודות שלא הצלחתי בהן, מופרדות בנקודה־פסיק');
  L.push('דגשים: מה שלמדנו מהתרגילים בשיחה (טעות שעשיתי, תנאי שקל לשכוח, צעד מפתח), מופרדים בנקודה־פסיק. אם לא פתרנו תרגיל, כתוב "אין"');
  L.push('נושאים: נושא = מצב (טרם התחלנו / בתהליך / הוסבר / מתרגלים / מוכן למבחן), מופרדים בנקודה־פסיק');
  L.push('על המרצה: משפטים, שיטות וטעויות שהוא מדגיש, אם למדת משהו חדש מהחומר');
  L.push('### סוף');
  L.push(MARK_END);
  return L.join('\n');
}

export const MOVED_HEAD = 'שינויים שלי (הועברו מהחלק של התוסף, כדי שלא יימחקו בעדכון):';

// Puts our block into the project's instructions without losing anything the student wrote.
// last: the block the extension wrote the previous time (null if unknown). Returns
//   text           the new instructions
//   moved          the student's own lines found inside our block, kept below it under MOVED_HEAD
//   markersMissing our block was there before but its marker lines were removed: nothing is written,
//                  the student decides (force: true puts a fresh block on top anyway)
export function updateInstructions(existing, ours, last = null, { force = false } = {}) {
  const cur = String(existing || '');
  const a = cur.indexOf(MARK_START), b = cur.indexOf(MARK_END);
  if (a >= 0 && b > a) {
    const block = cur.slice(a, b + MARK_END.length);
    const known = new Set(String(last || '').split('\n').map(l => l.trim()));
    const moved = last ? block.split('\n').map(l => l.trimEnd()).filter(l => l.trim() && !known.has(l.trim())) : [];
    let text = cur.slice(0, a) + ours + cur.slice(b + MARK_END.length);
    if (moved.length) text = `${text.trimEnd()}\n\n${MOVED_HEAD}\n${moved.join('\n')}`;
    return { text, moved, markersMissing: false };
  }
  if (last && cur.trim() && !force) return { text: cur, moved: [], markersMissing: true };
  return { text: cur.trim() ? `${ours}\n\n${cur.trim()}` : ours, moved: [], markersMissing: false };
}

// Puts our block into existing instructions, keeping whatever the student wrote around it.
export function mergeInstructions(existing, ours) {
  const cur = String(existing || '');
  const a = cur.indexOf(MARK_START), b = cur.indexOf(MARK_END);
  if (a >= 0 && b > a) return cur.slice(0, a) + ours + cur.slice(b + MARK_END.length);
  return cur.trim() ? `${ours}\n\n${cur.trim()}` : ours;
}
