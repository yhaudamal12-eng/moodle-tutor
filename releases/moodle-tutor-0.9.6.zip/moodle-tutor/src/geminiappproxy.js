// Injected into a gemini.google.com tab (the Gemini app). Notebooks show up there too, and there every
// question in a notebook opens a new conversation. The extension only reads those conversations, to
// find the session summaries; it never writes here. Calls go out from the page, with the student's login.
// Wire format of the page's batchexecute calls, checked 21.10.2026.
if (!globalThis.__moodleTutorGeminiApp) {
globalThis.__moodleTutorGeminiApp = true;
let tokens = null;
// The Google account of this tab: the app keeps it in the path, /u/1/app.
const account = (location.pathname.match(/^\/u\/(\d+)\//) || [])[1] || '0';
const base = account === '0' ? '' : `/u/${account}`;

async function loadTokens() {
  const html = await (await fetch(`${base}/app`, { credentials: 'include' })).text();
  const pick = k => { const m = html.match(new RegExp(`"${k}":"([^"]*)"`)); return m ? m[1] : null; };
  const t = { at: pick('SNlM0e'), bl: pick('cfb2h'), sid: pick('FdrFJe') };
  if (!t.at) throw new Error('login');
  tokens = t;
  return t;
}

function parseBatch(text, id) {
  const out = [];
  for (const line of text.split('\n')) {
    if (!line.startsWith('[')) continue;
    let arr; try { arr = JSON.parse(line); } catch { continue; }
    for (const e of arr) {
      if (Array.isArray(e) && e[0] === 'wrb.fr' && e[1] === id) out.push(e[2] ? JSON.parse(e[2]) : null);
      if (Array.isArray(e) && e[0] === 'er') out.push({ __error: e });
    }
  }
  return out;
}

async function rpc(id, params, path) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const t = tokens || await loadTokens();
    const q = new URLSearchParams({ rpcids: id, 'source-path': `${base}${path || '/app'}`, bl: t.bl || '', 'f.sid': t.sid || '', hl: 'iw', _reqid: String(100000 + Math.floor(Math.random() * 800000)), rt: 'c' });
    const body = 'f.req=' + encodeURIComponent(JSON.stringify([[[id, JSON.stringify(params), null, 'generic']]])) + '&at=' + encodeURIComponent(t.at) + '&';
    const res = await fetch(`${base}/_/BardChatUi/data/batchexecute?` + q, { method: 'POST', credentials: 'include', headers: { 'content-type': 'application/x-www-form-urlencoded;charset=UTF-8' }, body });
    if ((res.status === 400 || res.status === 401) && attempt === 0) { tokens = null; continue; }
    if (res.status === 401 || res.status === 403) throw new Error('login');
    return { status: res.status, results: parseBatch(await res.text(), id) };
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('gapp-')) return;
  (async () => {
    if (msg.type === 'gapp-ping') return { pong: true, account };
    if (msg.type === 'gapp-rpc') return rpc(msg.id, msg.params, msg.path);
    return { error: 'unknown' };
  })().then(reply, e => reply({ error: String(e && e.message || e) }));
  return true;
});
}
