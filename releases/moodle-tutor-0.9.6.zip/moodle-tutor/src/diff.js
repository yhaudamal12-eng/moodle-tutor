// Pure change-detection engine. No browser APIs, so it runs in tests and in the extension alike.
//
// A snapshot is { courses: { [courseId]: CourseSnapshot } }.
// CourseSnapshot = { complete: boolean, items: { [cmid]: Item } }
// Item = { cmid, kind, name, sectionId, sectionTitle, visible, files: [File] }
// File = { url, filename, etag, size, mtime }
//
// "complete: false" means the scan of that course was cut short (login expired, network error).
// An incomplete course never produces "removed" events, so a broken scan can never look like
// the lecturer deleted everything.

export function fileKey(f) {
  // pluginfile URLs carry a revision segment (/content/3/...). Strip it so a re-upload of the
  // same file name is seen as an update of the same file, not as delete + add.
  return f.url.replace(/\/content\/\d+\//, '/content/*/').replace(/[?#].*$/, '');
}

function fileChanged(a, b) {
  if (a.etag && b.etag) return a.etag !== b.etag;
  return a.size !== b.size || a.mtime !== b.mtime;
}

export function diffCourse(prev, next) {
  const events = [];
  const prevItems = (prev && prev.items) || {};
  const nextItems = next.items || {};

  for (const [cmid, item] of Object.entries(nextItems)) {
    const old = prevItems[cmid];
    if (!old) { events.push({ type: 'added', cmid, item }); continue; }
    if (old.name !== item.name) events.push({ type: 'renamed', cmid, from: old.name, to: item.name, item });
    if (old.sectionId !== item.sectionId) events.push({ type: 'moved', cmid, from: old.sectionTitle, to: item.sectionTitle, item });
    if (!old.visible && item.visible) events.push({ type: 'unlocked', cmid, item });

    // Files inside the item. Items whose files were not resolved this scan (files === undefined)
    // keep their previous files and produce no file events.
    if (item.files === undefined) continue;
    const oldFiles = new Map((old.files || []).map(f => [fileKey(f), f]));
    const newFiles = new Map(item.files.map(f => [fileKey(f), f]));
    for (const [k, f] of newFiles) {
      const of = oldFiles.get(k);
      if (!of) events.push({ type: 'file-added', cmid, file: f, item });
      else if (fileChanged(of, f)) events.push({ type: 'file-updated', cmid, file: f, before: of, item });
    }
    for (const [k, f] of oldFiles) {
      if (!newFiles.has(k)) events.push({ type: 'file-removed', cmid, file: f, item });
    }
  }

  if (next.complete) {
    for (const [cmid, old] of Object.entries(prevItems)) {
      if (!nextItems[cmid] && !old.removed) events.push({ type: 'removed', cmid, item: old });
    }
  }
  return events;
}

// Merge a new scan into the stored snapshot. Removed items are kept with removed: true
// (the local copy stays); unresolved files are carried over from the previous snapshot.
export function mergeCourse(prev, next) {
  const prevItems = (prev && prev.items) || {};
  const items = {};
  for (const [cmid, item] of Object.entries(next.items || {})) {
    const old = prevItems[cmid];
    items[cmid] = {
      ...item,
      files: item.files !== undefined ? item.files : (old ? old.files : undefined),
      firstSeen: old ? old.firstSeen : next.scannedAt,
      category: old && old.categoryByUser ? old.category : item.category,
      categoryByUser: old ? old.categoryByUser : false,
      material: old && old.materialByUser ? old.material : item.material,
      materialByUser: old ? !!old.materialByUser : false,
      removed: false,
    };
  }
  for (const [cmid, old] of Object.entries(prevItems)) {
    if (!items[cmid]) items[cmid] = next.complete ? { ...old, removed: true } : old;
  }
  return { complete: next.complete, scannedAt: next.scannedAt, items };
}

// Files that appear more than once across all courses (same content signature).
export function findDuplicates(snapshot) {
  const byEtag = new Map();
  for (const [courseId, c] of Object.entries(snapshot.courses || {})) {
    for (const item of Object.values(c.items || {})) {
      if (item.removed) continue;
      for (const f of item.files || []) {
        if (!f.etag) continue;
        if (!byEtag.has(f.etag)) byEtag.set(f.etag, []);
        byEtag.get(f.etag).push({ courseId, cmid: item.cmid, filename: f.filename });
      }
    }
  }
  return [...byEtag.entries()].filter(([, v]) => v.length > 1).map(([etag, places]) => ({ etag, places }));
}
