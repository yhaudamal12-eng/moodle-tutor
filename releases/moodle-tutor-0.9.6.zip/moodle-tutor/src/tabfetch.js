// A fetch() look-alike that performs the request inside an open Moodle tab (see content.js).
// The Moodle client only uses: ok, status, url, type, headers.get(), text().

export function makeTabFetch(sendToTab) {
  return async (url, opts = {}) => {
    const { credentials, ...rest } = opts;
    const r = await sendToTab({ type: 'proxy-fetch', url, opts: rest });
    if (!r) throw new TypeError('Moodle tab did not answer');
    if (r.error) throw new TypeError(r.error);
    const headers = r.headers || {};
    return {
      ok: r.ok, status: r.status, url: r.url, type: r.type,
      headers: { get: name => headers[name.toLowerCase()] ?? null },
      text: async () => r.body || '',
    };
  };
}
