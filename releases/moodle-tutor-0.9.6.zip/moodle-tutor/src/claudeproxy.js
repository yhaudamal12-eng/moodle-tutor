// Injected into a claude.ai tab. Requests to Claude's own site go out from the page itself,
// with the student's login, exactly like the page's own requests.
if (!globalThis.__moodleTutorClaude) {
globalThis.__moodleTutorClaude = true;
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('claude-')) return;
  (async () => {
    if (msg.type === 'claude-ping') return { pong: true };
    if (msg.type === 'claude-fetch') {
      const opts = { method: msg.method || 'GET', credentials: 'include', headers: {} };
      if (msg.json !== undefined) { opts.headers['content-type'] = 'application/json'; opts.body = JSON.stringify(msg.json); }
      const res = await fetch(msg.path, opts);
      return { status: res.status, body: await res.text() };
    }
    if (msg.type === 'claude-upload') {
      const bin = atob(msg.b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const fd = new FormData();
      fd.append('file', new File([bytes], msg.name, { type: msg.mime || 'application/octet-stream' }));
      const res = await fetch(msg.path, { method: 'POST', body: fd, credentials: 'include' });
      return { status: res.status, body: await res.text() };
    }
    return { error: 'unknown' };
  })().then(reply, e => reply({ error: String(e && e.message || e) }));
  return true;
});
}
