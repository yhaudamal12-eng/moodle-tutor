// Runs inside every Moodle page. The background scanner sends its requests through here, so they
// go out from the Moodle page itself with the student's login, exactly like the page's own requests.
if (!globalThis.__moodleTutorProxy) {
globalThis.__moodleTutorProxy = true;
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg && msg.type === 'proxy-ping') { reply({ pong: true }); return; }
  if (msg && msg.type === 'proxy-bytes') {
    // A course file's content, for attaching it to a chat. Base64 so it survives the message.
    (async () => {
      try {
        const res = await fetch(msg.url, { credentials: 'include' });
        const type = res.headers.get('content-type') || '';
        if (!res.ok) return reply({ error: `http-${res.status}` });
        if (/text\/html/i.test(type) && !/\.html?($|\?)/i.test(msg.url)) return reply({ error: 'login' });
        const buf = new Uint8Array(await res.arrayBuffer());
        let bin = '';
        for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
        reply({ ok: true, b64: btoa(bin), type: type.split(';')[0], size: buf.length });
      } catch (e) { reply({ error: String(e && e.message || e) }); }
    })();
    return true;
  }
  if (!msg || msg.type !== 'proxy-fetch') return;
  (async () => {
    try {
      const { peek, ...opts } = msg.opts || {};
      const ctrl = new AbortController();
      const res = await fetch(msg.url, { ...opts, credentials: 'include', signal: ctrl.signal });
      const pick = ['etag', 'content-length', 'last-modified', 'content-type', 'date'];
      const headers = Object.fromEntries(pick.map(h => [h, res.headers.get(h)]));
      // "peek": only pages are read; a file is cut off after its headers instead of downloaded.
      if (peek && !/text\/html/i.test(headers['content-type'] || '')) {
        ctrl.abort();
        reply({ ok: res.ok, status: res.status, url: res.url, type: res.type, headers, body: '' });
        return;
      }
      const wantBody = opts.method !== 'HEAD' && res.type !== 'opaqueredirect';
      reply({ ok: res.ok, status: res.status, url: res.url, type: res.type, headers, body: wantBody ? await res.text() : '' });
    } catch (e) {
      reply({ error: String(e && e.message || e) });
    }
  })();
  return true;
});
}
