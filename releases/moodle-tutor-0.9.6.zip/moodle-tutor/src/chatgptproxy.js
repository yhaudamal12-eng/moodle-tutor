// Injected into a chatgpt.com tab. Calls go out from the page itself, with the student's login,
// the same calls the ChatGPT page makes for its projects (checked 15.10.2026).
if (!globalThis.__moodleTutorChatGPT) {
globalThis.__moodleTutorChatGPT = true;
let session = null;

async function auth(force = false) {
  if (session && !force && session.until > Date.now()) return session;
  const s = await (await fetch('/api/auth/session', { credentials: 'include' })).json().catch(() => ({}));
  if (!s || !s.accessToken) throw new Error('login');
  session = { token: s.accessToken, account: s.account && s.account.id, until: Date.now() + 10 * 60 * 1000 };
  return session;
}

async function api(method, path, json, extra = {}) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const a = await auth(attempt > 0);
    const headers = { authorization: `Bearer ${a.token}`, ...(a.account ? { 'chatgpt-account-id': a.account } : {}), ...extra };
    if (json !== undefined) headers['content-type'] = 'application/json';
    const res = await fetch(path, { method, credentials: 'include', headers, body: json !== undefined ? JSON.stringify(json) : undefined });
    if (res.status === 401 && attempt === 0) continue;
    if (res.status === 401 || res.status === 403) throw new Error('login');
    return { status: res.status, body: await res.text() };
  }
}

// A file into a project: ask for an upload slot, put the bytes there, let ChatGPT index it, attach it.
async function upload({ projectId, name, mime, b64 }) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const type = mime || 'application/octet-stream';
  const proj = { 'chatgpt-project-id': projectId };
  const slot = await api('POST', '/backend-api/files', { file_name: name, file_size: bytes.length, gizmo_id: projectId, mime_type: type,
    reset_rate_limits: false, supports_direct_azure_multipart: false, timezone_offset_min: new Date().getTimezoneOffset(), use_case: 'gizmo' }, proj);
  let s; try { s = JSON.parse(slot.body); } catch { s = null; }
  if (slot.status !== 200 || !s || !s.upload_url) return { status: slot.status, error: 'slot', body: slot.body.slice(0, 200) };
  const put = await fetch(s.upload_url, { method: 'PUT', headers: { 'x-ms-blob-type': 'BlockBlob', 'x-ms-version': '2020-04-08', 'content-type': type }, body: bytes });
  if (!put.ok) return { status: put.status, error: 'put' };
  const proc = await api('POST', '/backend-api/files/process_upload_stream', { entry_surface: 'project_sources', file_id: s.file_id, file_name: name, gizmo_id: projectId,
    index_for_retrieval: true, mime_type: type, use_case: 'gizmo' }, proj);
  if (proc.status !== 200) return { status: proc.status, error: 'process' };
  const att = await api('POST', `/backend-api/projects/${projectId}/files`, { files: [{ file_id: s.file_id, last_modified: Date.now(), location: 'fs', name, size: bytes.length, type }] });
  if (att.status !== 200) return { status: att.status, error: 'attach', body: att.body.slice(0, 200) };
  return { status: 200, file_id: s.file_id };
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('cgpt-')) return;
  (async () => {
    if (msg.type === 'cgpt-ping') return { pong: true };
    if (msg.type === 'cgpt-api') return api(msg.method, msg.path, msg.json);
    if (msg.type === 'cgpt-upload') return upload(msg);
    return { error: 'unknown' };
  })().then(reply, e => reply({ error: String(e && e.message || e) }));
  return true;
});
}
