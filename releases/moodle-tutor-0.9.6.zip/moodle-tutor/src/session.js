// Builds a tutoring session: picks the course files for the chosen mode, writes the opening
// instructions, and reads back the end-of-session summary. Pure functions, no browser APIs.

export const MODES = {
  scratch: {
    label: 'מאפס',
    goal: 'ללמד נושא חדש מהיסודות.',
    rules: [
      'מלמדים ברצף, לפי מה שביקשתי, בלי לעצור לשאלות באמצע: קודם האינטואיציה, אחריה הניסוח הפורמלי, ואז דוגמה.',
      'בין חלק לחלק רק שואלים אם להמשיך.',
      'נושא אחד בכל פעם, לפי סדר החומר בקורס.',
    ],
  },
  refresh: {
    label: 'רענון',
    goal: 'לרענן חומר שכבר נלמד ולאתר פערים.',
    rules: [
      'סיכום קצר של הנושא, ואחריו שאלה שבודקת אם הוא באמת זכור.',
      'מה שזכור מדלגים עליו. מה שלא זכור מסבירים מחדש בקצרה.',
      'מדגישים הנחות ותנאים שנוטים לשכוח.',
    ],
  },
  exam: {
    label: 'הכנה למבחן',
    goal: 'להכין למבחן הקרוב, לפי המבחנים, התרגילים והפתרונות הרשמיים של הקורס.',
    rules: [
      'ממפים קודם את מבנה המבחן ואת סוגי השאלות מתוך המבחנים שצורפו.',
      'שאלות תרגול בסגנון המרצה, אחת בכל פעם. אחרי כל תשובה: בדיקה, איפה הטעות, ומה הנימוק שהמרצה מצפה לראות.',
      'מצביעים על מלכודות שחוזרות בפתרונות הרשמיים.',
      'כשאין דף נוסחאות: בסוף כל נושא, כרטיס זיכרון קצר עם מה שחייבים לזכור בעל פה.',
      'כשאבקש "מבחן לדוגמה": מבחן שלם במבנה ובהיקף של המבחן האמיתי, עם הזמן המוקצב. בלי רמזים ובלי משוב באמצע. בסוף: ציון לפי השאלות, מה היה חסר בכל תשובה, ואילו נושאים לחזור עליהם.',
    ],
  },
  homework: {
    label: 'עזרה בשיעורי בית',
    goal: 'לעזור לפתור את המטלה בלי לפתור אותה במקומי.',
    rules: [
      'רמזים והכוונה צעד אחר צעד. פתרון מלא רק אם אבקש במפורש "פתור במלואו".',
      'מזהים לכל שאלה את הנושא ואת הכלים הנדרשים, ומקשרים לתרגיל דומה שכבר נפתר בקורס.',
      'תרגיל שיש לו פתרון רשמי בחומר נחשב תרגול, ומותר לפתור אותו במלואו.',
      `כשתרגיל נגמר: ${'סיכום תרגיל מקוצר'}, בשלוש עד חמש שורות. מה התרגיל בדק, באילו כלים השתמשנו, ומה הדגשים שלמדנו מהתרגיל הזה דווקא: איפה טעיתי, איזה תנאי קל לשכוח, ואיזה צעד פתח את הפתרון. בסוף שואלים אם לכתוב סיכום מורחב.`,
      'סיכום מורחב, רק אם ביקשתי: החומר התיאורטי שהתרגיל נשען עליו, מסודר לפי הצעדים בפתרון, עם הפניות לחומר הקורס.',
    ],
  },
};

// The first time a topic is taught: a continuous lesson, the questions only after it. Same in both styles.
export const FIRST_TIME = [
  'נושא שעוד לא למדנו (לפי קובץ ההתקדמות) מלמדים ברצף, לפי מה שביקשתי, בלי שאלות באמצע ובלי לבקש ממני לנסות קודם.',
  'רק בסוף הנושא מגיע שלב ההבנה, לפי סגנון הלמידה שלמטה.',
];

// How the tutor teaches. The student picks one per course; a word in the chat switches for that chat.
// "active" follows the research on learning with AI: retrieval, try first on exercises, explain back.
export const STYLES = {
  active: {
    label: 'פעילה',
    rules: [
      'בסוף נושא חדש: שתיים או שלוש שאלות הבנה, ובקשה להסביר במילים שלי את הרעיון המרכזי. לא לשאול "הבנת?".',
      'בתרגילים, בחזרה על חומר שכבר נלמד ובהכנה למבחן: קודם אני מנסה, אחר כך רמזים בשלבים, והסבר מלא רק אם עדיין לא הצלחתי.',
      'בפתיחת שיחה: שתיים או שלוש שאלות קצרות על נושאים שכבר נלמדו ולא חזרנו עליהם כמה ימים, ועל מה שרשום "לחזרה" בקובץ ההתקדמות. רק אחר כך ממשיכים. נושא שלא זכרתי חוזר לתרגול.',
      'כשאני מבקש סיכום: סיכום קצר, ואחריו שתיים או שלוש שאלות עליו.',
    ],
  },
  flow: {
    label: 'זורמת',
    rules: [
      'מסבירים ישר וברור, גם בתרגילים, בלי לבקש ממני לנסות קודם.',
      'בסוף נושא חדש: הצעה לשאלה אחת לבדיקה עצמית, בלי להתעקש.',
      'בפתיחת שיחה, אם יש בקובץ ההתקדמות נושאים שלא חזרנו עליהם כמה ימים, או משהו שרשום "לחזרה", מציעים במשפט אחד חזרה קצרה.',
    ],
  },
};
export const STYLE_COMMON = [
  'אפשר להחליף סגנון בשיחה במילים: "תסביר ישר" עובר לזורמת, ו"בחן אותי" עובר לפעילה, עד סוף השיחה.',
  'כשהשיחה מתארכת (בערך 30 הודעות) או כשעוברים לנושא אחר, הצע לכתוב "סיום". אחריו, איפה שאפשר, כדאי לפתוח שיחה חדשה: היא ממשיכה מקובץ ההתקדמות, ושיחה קצרה מדויקת יותר.',
];

// The first conversation in a course: getting to know the student, once. The answers come back in a
// "### העדפות" block, which the extension keeps for every chat of the course.
export const INTAKE = [
  'אם בקובץ ההתקדמות אין עדיין חלק "ההעדפות שלי", זו שיחת ההיכרות שלנו. לפני שמתחילים ללמוד, שואלים שאלה אחת בכל פעם, ומדלגים על מה שכבר כתוב למטה ב"על הקורס ועליי":',
  '  המטרה שלי בקורס: להבין לעומק, לעבור את המבחן, או להשלים פערים.',
  '  הרקע שלי בנושא.',
  '  מתי המבחן, מה הפורמט שלו, והאם יש דף נוסחאות.',
  '  איך אני אוהב שמסבירים לי: עם דוגמאות, מהאינטואיציה או בניסוח פורמלי, ובאיזה אורך.',
  '  האם לבחון אותי תוך כדי (למידה פעילה) או להסביר ישר (למידה זורמת).',
  '  מה בדרך כלל מקשה עליי.',
  '  שאלה פתוחה, בסוף: איך אני רוצה שהלימוד שלנו ייראה, ואם יש לי עוד משהו להוסיף. כאן מקשיבים, שואלים שאלת המשך אם משהו לא ברור, ולא ממהרים.',
  'בסוף ההיכרות משקפים לי במילים פשוטות מה הבנת ממני, ואיך תעבוד איתי בעקבות זה. שואלים אם זה נכון ואם לשנות משהו. רק אחרי שאישרתי, כותבים את בלוק ההעדפות (בפורמט שלמטה) ויוצאים לדרך.',
  'אם פתחתי בשאלה דחופה, עונים עליה קודם ומציעים את ההיכרות בסוף השיחה. אם אמרתי "לא עכשיו", מדלגים ומציעים שוב בשיחה הבאה.',
  'בכל שיחה אפשר לכתוב "בוא נעדכן את ההעדפות": שואלים רק על מה שאני רוצה לשנות, משקפים שוב, וכותבים בלוק העדפות חדש ומלא.',
];

export const BASE_RULES = [
  'בלי הקדמות, בלי סיכומים ובלי "הבנתי". ישר לחומר.',
  'תשובות קצרות וממוקדות. בלי טבלאות או לוחות שלא ביקשתי.',
  'נשענים רק על החומרים המצורפים. פתרון רשמי הוא מקור הסמכות הגבוה ביותר.',
  'כל טענה מהחומר מקבלת הפניה בסוגריים, שנפתחים במילה בעברית: (קובץ: שם הקובץ, עמ׳ 3). ידע כללי שלא מהחומר מסומן במילה "כללי".',
  'בכל שימוש במודל או במשפט, תזכורת קצרה להנחות שלו.',
  'סימון מקובל באקדמיה.',
];

// Hebrew and English in one text: a line that starts or ends in English flips direction and becomes
// unreadable. These rules keep every line anchored in Hebrew.
export const RTL_RULES = [
  'הסיבה: אני קורא מימין לשמאל. פסקה, שורה או פריט ברשימה שמתחילים באות לטינית, באות יוונית, בסמל או במספר מתהפכים לשמאל־לימין, והטקסט נעשה בלתי קריא. זה הכלל החשוב ביותר בעיצוב.',
  'לכן כל פסקה, שורה, כותרת ופריט ברשימה מתחילים במילה בעברית. בלי יוצא מן הכלל, גם כשהנושא של המשפט הוא סמל.',
  'כשהמשפט עוסק בסמל, פותחים בשם שלו בעברית ומוסיפים את הסמל אחריו. לא כך: "μ הוא התוחלת". אלא כך: "התוחלת μ היא מרכז הפעמון". לא כך: "σ² מודדת את הרוחב". אלא כך: "השונות σ² מודדת את הרוחב".',
  'גם פריט ברשימה: לא "x הוא המשתנה", אלא "המשתנה x הוא...". ולא "2 תצפיות", אלא "שתי תצפיות".',
  'משפט לא מסתיים במילה באנגלית, בנוסחה או בסמל. אם צריך, מנסחים מחדש כך שהמילה האחרונה בעברית.',
  'מונח באנגלית מופיע רק בפעם הראשונה, בסוגריים אחרי המונח בעברית. אחר כך כותבים רק בעברית.',
  'בתוך אותם סוגריים לא מערבבים עברית ואנגלית, חוץ מהפניה לקובץ.',
  'נוסחה או ביטוי של יותר מסמל אחד עומדים בשורה משלהם, לא בתוך משפט. משתנה בודד באמצע המשפט מותר, אבל לא בתחילתו ולא בסופו.',
  'קוד ופלט של תוכנה רק בבלוק קוד נפרד.',
  'לפני ששולחים תשובה: בודקים את המילה הראשונה של כל פסקה ושל כל פריט. אם היא לא בעברית, מנסחים מחדש.',
];

export const CATEGORY_LABEL = {
  'exam-solution': 'מבחן עם פתרון רשמי', exam: 'מבחן', solution: 'פתרון רשמי', assignment: 'מטלה',
  slides: 'מצגת', summary: 'סיכום', lecture: 'הרצאה', tutorial: 'תרגול', syllabus: 'מבנה הקורס',
  recording: 'הקלטה', other: 'חומר', forum: 'פורום',
};

// Order of importance of each kind of file in each mode (lower = more important).
const PRIORITY = {
  exam: ['syllabus', 'exam-solution', 'solution', 'exam', 'summary', 'slides', 'lecture', 'tutorial', 'assignment', 'other'],
  homework: ['assignment', 'solution', 'slides', 'summary', 'lecture', 'tutorial', 'syllabus', 'exam-solution', 'exam', 'other'],
  refresh: ['summary', 'slides', 'syllabus', 'lecture', 'tutorial', 'solution', 'exam-solution', 'exam', 'assignment', 'other'],
  scratch: ['slides', 'lecture', 'summary', 'syllabus', 'tutorial', 'solution', 'assignment', 'exam-solution', 'exam', 'other'],
};

const SLIDE_CAP = { exam: 1, homework: 3, refresh: 4, scratch: 4 };

// Per message limits of the chat sites. Checked on 15.10.2026; adjustable in settings.
export const CHAT_LIMITS = {
  claude: { maxFiles: 20, maxFileBytes: 30 * 1024 * 1024, maxTotalBytes: 60 * 1024 * 1024 },
  gemini: { maxFiles: 10, maxFileBytes: 100 * 1024 * 1024, maxTotalBytes: 100 * 1024 * 1024 },
};

const SOLUTION_WORDS = /[-–_ ]*(?:עם\s*)?(?:פי?תרו(?:ן|נות)|פתור(?:\s*\([^)]*\))?|with\s*solutions?|solutions?)/gi;
const baseName = s => String(s).replace(/\.[a-z0-9]{2,5}$/i, '').replace(SOLUTION_WORDS, ' ').replace(/[_\-–()]/g, ' ').replace(/\s+/g, ' ').trim();

// Course files as a flat list: one entry per file, with what it is and where it sits.
export function courseFiles(course) {
  const out = [];
  for (const it of Object.values(course.items || {})) {
    if (it.removed || !Array.isArray(it.files)) continue;
    for (const f of it.files) {
      out.push({ cmid: it.cmid, item: it.name, section: it.sectionTitle || '', category: it.category || 'other',
        material: it.material || 'current', url: f.url, filename: f.filename, size: f.size || 0, type: f.type || '', etag: f.etag || '' });
    }
  }
  return out;
}

// Picks files for a session. Returns { picked, left: [{file, why}] } — nothing is dropped silently.
export function selectFiles(files, { mode = 'exam', chat = 'claude', sections = null, targetCmid = null, limits = CHAT_LIMITS[chat] } = {}) {
  const order = PRIORITY[mode] || PRIORITY.exam;
  const left = [];
  let pool = files.filter(f => {
    if (/^video\//.test(f.type) || /\.(mp4|mov|mkv|avi|webm)$/i.test(f.filename)) { left.push({ file: f, why: 'סרטון' }); return false; }
    if (sections && sections.length && !sections.includes(f.section) && !['syllabus', 'exam', 'exam-solution'].includes(f.category)) { left.push({ file: f, why: 'מחוץ לנושאים שנבחרו' }); return false; }
    return true;
  });

  // An exam that also exists "with solution" is sent only once, with the solution.
  const solvedBases = new Set(pool.filter(f => f.category === 'exam-solution').map(f => baseName(f.item) + '|' + baseName(f.filename)));
  const solvedItemBases = new Set(pool.filter(f => f.category === 'exam-solution').map(f => baseName(f.item)));
  pool = pool.filter(f => {
    if (f.category === 'exam' && (solvedItemBases.has(baseName(f.item)) || solvedBases.has(baseName(f.item) + '|' + baseName(f.filename)))) {
      left.push({ file: f, why: 'קיים גם עם פתרון' }); return false;
    }
    return true;
  });

  // An exercise whose official solution is also there is sent once, with the solution
  // (except the open assignment in homework mode, which is the point of the session).
  const solvedExercises = new Set(pool.filter(f => f.category === 'solution').map(f => baseName(f.item)));
  pool = pool.filter(f => {
    if (f.category === 'assignment' && solvedExercises.has(baseName(f.item)) && !(mode === 'homework' && f.cmid === targetCmid)) {
      left.push({ file: f, why: 'קיים גם עם פתרון' }); return false;
    }
    return true;
  });

  // Homework on an open assignment: never hand over that assignment's own solution.
  if (mode === 'homework' && targetCmid) {
    const target = files.find(f => f.cmid === targetCmid);
    const targetBase = target ? baseName(target.item) : null;
    pool = pool.filter(f => {
      if (f.category === 'solution' && targetBase && baseName(f.item) === targetBase) { left.push({ file: f, why: 'הפתרון של המטלה הפתוחה' }); return false; }
      return true;
    });
  }

  const rank = f => {
    let r = order.indexOf(f.category); if (r < 0) r = order.length;
    if (targetCmid && f.cmid === targetCmid) r = -1;
    return r * 10 + (f.material === 'current' ? 0 : 1);
  };
  pool.sort((a, b) => rank(a) - rank(b) || naturalCompare(a.filename, b.filename));

  // Slide decks are long (40-80 pages each); a chat message holds only so many. Each mode gets a
  // few by default, the course summary deck first. The student can add more in the panel.
  const slideCap = sections && sections.length ? Infinity : (SLIDE_CAP[mode] ?? 3);
  const isSummaryDeck = f => /summary|סיכום/i.test(`${f.item} ${f.filename} ${f.section}`);
  const decks = pool.filter(f => f.category === 'slides').sort((a, b) => Number(isSummaryDeck(b)) - Number(isSummaryDeck(a)));
  const keepDecks = new Set(decks.slice(0, slideCap));
  pool = pool.filter(f => {
    if (f.category === 'slides' && !keepDecks.has(f)) { left.push({ file: f, why: 'מצגת נוספת: אפשר להוסיף ידנית' }); return false; }
    return true;
  });

  const picked = [];
  let total = 0;
  for (const f of pool) {
    if (f.size && f.size > limits.maxFileBytes) { left.push({ file: f, why: 'גדול מדי לצ\'אט' }); continue; }
    if (picked.length >= limits.maxFiles) { left.push({ file: f, why: 'מעבר למספר הקבצים בהודעה' }); continue; }
    if (total + (f.size || 0) > limits.maxTotalBytes) { left.push({ file: f, why: 'מעבר לנפח הכולל' }); continue; }
    picked.push(f); total += f.size || 0;
  }
  return { picked, left, totalBytes: total };
}

function naturalCompare(a, b) {
  return String(a).localeCompare(String(b), 'he', { numeric: true });
}

export const PROFILE_TEXT = {
  kind: { math: 'מתמטי, עם הוכחות וחישובים', models: 'השוואת מודלים והנחות', code: 'תכנות וניתוח נתונים' },
  examFormat: { open: 'שאלות פתוחות', mcq: 'רב־ברירה', mixed: 'משולב' },
  background: { new: 'חדש לי', rusty: 'למדתי, וזה חלוד', prior: 'למדתי קורס קודם בנושא' },
};

export function buildPrompt({ course, mode = 'exam', lang = 'he', profile = {}, learner = '', knowledge = null, files = [], left = [], customMode = null }) {
  const m = customMode || MODES[mode] || MODES.exam;
  const L = [];
  const courseName = (course.short || course.name || '').replace(/^\d+(?:_\d+)?-/, '');
  L.push(`אתה המורה הפרטי שלי בקורס ${courseName}. מצב הסשן: ${m.label}. המטרה: ${m.goal}`);
  L.push('');
  L.push('כללים:');
  for (const r of [...BASE_RULES, ...m.rules]) L.push(`- ${r}`);
  if (lang === 'he') { L.push('- השפה: עברית.'); for (const r of RTL_RULES) L.push(`- ${r}`); }
  else if (lang === 'en') L.push('- השפה: אנגלית.');
  else L.push('- השפה: לפי השפה שבה אני כותב.');

  const p = [];
  if (profile.kind) p.push(`אופי הקורס: ${PROFILE_TEXT.kind[profile.kind] || profile.kind}`);
  if (profile.examFormat) p.push(`פורמט המבחן: ${PROFILE_TEXT.examFormat[profile.examFormat] || profile.examFormat}`);
  if (profile.formulaSheet !== undefined) p.push(profile.formulaSheet ? 'יש דף נוסחאות במבחן' : 'אין דף נוסחאות במבחן, ולכן צריך לזכור נוסחאות בעל פה');
  if (profile.background) p.push(`הרקע שלי: ${PROFILE_TEXT.background[profile.background] || profile.background}`);
  if (profile.notes) p.push(profile.notes);
  if (p.length) { L.push(''); L.push('על הקורס ועליי:'); for (const x of p) L.push(`- ${x}`); }

  if (learner && learner.trim()) { L.push(''); L.push('מה שכבר ידוע עליי מסשנים קודמים:'); L.push(learner.trim()); }
  if (knowledge && knowledge.trim()) { L.push(''); L.push('מה שכבר ידוע על הקורס ועל המרצה:'); L.push(knowledge.trim()); }

  if (files.length) {
    L.push(''); L.push('הקבצים המצורפים:');
    for (const f of files) {
      const section = /^(כללי|general)$/i.test((f.section || '').trim()) ? null : f.section;
      const tag = [CATEGORY_LABEL[f.category] || 'חומר', f.material === 'support' ? 'חומר עזר משנים קודמות' : null, section].filter(Boolean).join(', ');
      L.push(`- ${tag}: ${f.filename}`);
    }
  }
  if (left.length) L.push(`- לא צורפו ${left.length} קבצים נוספים מהקורס. אם חסר לך משהו, תגיד ואצרף.`);

  L.push('');
  L.push('סיום הסשן: כשאכתוב "סיום", החזר רק את הבלוק הבא ולא שום דבר אחר, בשורות קצרות:');
  L.push('### סיכום סשן');
  L.push('נלמד: ...');
  L.push('קשיים: ...');
  L.push('הצעד הבא: ...');
  L.push('נושאים: נושא = מצב (טרם התחלנו / בתהליך / הוסבר / מתרגלים / מוכן למבחן), מופרדים בנקודה־פסיק');
  L.push('על המרצה: משפטים, שיטות וטעויות שהוא מדגיש, אם למדת משהו חדש מהפתרונות');
  L.push('### סוף');
  L.push('');
  L.push(mode === 'exam' ? 'התחל במיפוי קצר של מבנה המבחן מתוך הקבצים, ואז שאלת התרגול הראשונה.'
    : mode === 'homework' ? 'התחל בזיהוי השאלות במטלה ובנושא של כל אחת. אל תפתור.'
    : mode === 'refresh' ? 'התחל בשאלה אחת שבודקת מה אני זוכר מהנושא הראשון.'
    : 'התחל בנושא הראשון של הקורס.');
  return L.join('\n');
}

// Reads the "### סיכום סשן" block the tutor writes at the end. Tolerates extra text around it.
export function parseSummary(text) {
  // Text copied from the rendered page loses the "###" marks, and a paste of the whole chat also
  // holds the empty template from the opening prompt; the last filled-in block wins.
  const blocks = [...String(text || '').matchAll(/^[ \t]*(?:#{1,4}[ \t]*)?\**[ \t]*סיכום[ \t]*סשן[ \t]*\**[ \t]*:?[ \t]*\n([\s\S]*?)(?=\n[ \t]*(?:#{1,4}[ \t]*)?\**[ \t]*סוף[ \t]*\**[ \t]*(?:\n|$)|\n[ \t]*(?:#{1,4}[ \t]*)?\**[ \t]*סיכום[ \t]*סשן|$(?![\s\S]))/gm)];
  const m = blocks.reverse().find(b => /נלמד/.test(b[1]) && !/נלמד\s*\**\s*:\s*\**\s*\.\.\.\s*$/m.test(b[1]));
  if (!m) return null;
  const out = { learned: '', struggles: '', next: '', topics: [], lecturer: '', review: [], tips: [] };
  const clean = v => v.replace(/^\**\s*/, '').replace(/\s*\**$/, '').trim();
  const label = name => new RegExp(`^\\s*[-*]?\\s*\\**\\s*${name}\\s*\\**\\s*:\\s*\\**\\s*(.+)$`, 'm');
  const field = (name, key) => { const r = m[1].match(label(name)); if (r) out[key] = clean(r[1]); };
  field('נלמד', 'learned'); field('קשיים', 'struggles'); field('הצעד הבא', 'next'); field('על המרצה', 'lecturer');
  const tp = m[1].match(label('דגשים'));
  if (tp) out.tips = clean(tp[1]).split(/[;؛]/).map(x => x.trim()).filter(x => x && !/^(אין|—|-|\.\.\.)$/.test(x));
  const rv = m[1].match(label('לחזרה'));
  if (rv) out.review = clean(rv[1]).split(/[;؛]/).map(x => x.trim()).filter(x => x && !/^(אין|—|-|\.\.\.)$/.test(x));
  const t = m[1].match(label('נושאים'));
  if (t) out.topics = clean(t[1]).split(/[;؛]/).map(x => x.split('=').map(s => s.trim())).filter(([a, b]) => a && b).map(([topic, status]) => ({ topic, status }));
  return out;
}

// Reads the "### העדפות" block written at the end of the getting-to-know conversation. The last filled
// block wins; a block still holding the template ("...") is ignored.
export function parsePrefs(text) {
  const blocks = [...String(text || '').matchAll(/^[ \t]*\**[ \t]*(?:#{1,4}[ \t]*)?\**[ \t]*העדפות[ \t]*\**[ \t]*:?[ \t]*\n([\s\S]*?)(?=\n[ \t]*\**[ \t]*(?:#{1,4}[ \t]*)?\**[ \t]*סוף[ \t]*\**[ \t]*(?:\n|$)|$(?![\s\S]))/gm)];
  const label = name => new RegExp(`^\\s*[-*]?\\s*\\**\\s*${name}\\s*\\**\\s*:\\s*\\**\\s*(.+)$`, 'm');
  const clean = v => v.replace(/^\**\s*/, '').replace(/\s*\**$/, '').trim();
  for (const b of blocks.reverse()) {
    const out = {};
    for (const [heb, key] of [['מטרה', 'goal'], ['רקע', 'background'], ['מבחן', 'exam'], ['הסבר', 'explain'], ['סגנון', 'style'], ['קשיים', 'hard'], ['עוד', 'extra']]) {
      const r = b[1].match(label(heb));
      if (r && !/^\.\.\.$|^…$/.test(clean(r[1]))) out[key] = clean(r[1]);
    }
    // The template in the instructions, if a reply ever repeats it, is not the student's answer.
    if (/פעילה או זורמת|איך אני אוהב שמסבירים לי|מה שאמרתי בשאלה הפתוחה/.test(b[1])) continue;
    if (Object.keys(out).length >= 3) return out;
  }
  return null;
}

// What the preferences mean for the fields the panel shows too ("על הקורס ועליי").
export function prefsToProfile(prefs, profile = {}) {
  const p = { ...profile };
  const st = prefs.style || '';
  if (/זורמ/.test(st)) p.style = 'flow'; else if (/פעיל/.test(st)) p.style = 'active';
  const ex = prefs.exam || '';
  if (/משולב/.test(ex)) p.examFormat = 'mixed'; else if (/אמריקא|רב[\s־-]?ברירה/.test(ex)) p.examFormat = 'mcq'; else if (/פתוח/.test(ex)) p.examFormat = 'open';
  if (/אין\s+דף/.test(ex)) p.formulaSheet = false; else if (/(^|[^א-ת])יש\s+דף/.test(ex)) p.formulaSheet = true;
  return p;
}

// Folds a session summary into the stored learner profile and course knowledge (both plain text,
// shown to and editable by the student). Topics keep their latest status.
export function applySummary(state, summary, when = new Date()) {
  const s = { learner: state.learner || '', topics: { ...(state.topics || {}) }, topicDates: { ...(state.topicDates || {}) }, review: [...(state.review || [])], tips: [...(state.tips || [])], lecturer: state.lecturer || '', sessions: [...(state.sessions || [])] };
  const date = when.toISOString().slice(0, 10);
  for (const { topic, status } of summary.topics) { s.topics[topic] = status; s.topicDates[topic] = date; }
  // Questions to review: the newest first, no repeats, at most 12.
  const fresh = (summary.review || []).filter(t => !s.review.some(r => r.text === t)).map(text => ({ text, date }));
  s.review = [...fresh, ...s.review].slice(0, 12);
  // Points learned from exercises: kept for exam preparation, the newest first, at most 30.
  const tips = (summary.tips || []).filter(t => !s.tips.some(r => r.text === t)).map(text => ({ text, date }));
  s.tips = [...tips, ...s.tips].slice(0, 30);
  if (summary.lecturer && !s.lecturer.includes(summary.lecturer)) s.lecturer = [s.lecturer, summary.lecturer].filter(Boolean).join('\n');
  s.sessions.unshift({ date, learned: summary.learned, struggles: summary.struggles, next: summary.next });
  s.sessions = s.sessions.slice(0, 20);
  const last = s.sessions.slice(0, 3).map(x => `- ${x.date}: נלמד ${x.learned || '—'}. קשיים: ${x.struggles || '—'}. הצעד הבא: ${x.next || '—'}`);
  const topics = Object.entries(s.topics).map(([k, v]) => `${k} = ${v}`).join('; ');
  s.learner = [last.join('\n'), topics ? `מצב הנושאים: ${topics}` : ''].filter(Boolean).join('\n');
  return s;
}
