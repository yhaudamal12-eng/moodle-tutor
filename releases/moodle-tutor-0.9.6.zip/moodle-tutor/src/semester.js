// Which semester a course belongs to.
// HUJI keeps it in a course field named "semester" (the "Semester 1 / Semester 2 / Semester 1 Or 2"
// grouping on the Moodle dashboard): 1 = A, 2 = B, 3 = either. That field wins. Course dates at HUJI
// are not reliable (checked 15.10.2026: every course starts 10.06.2026 and has no end), so dates are
// used only when they look like real semester dates. Names count too: "סמסטר ב", "Semester B", "שנתי".

const DAY = 86400;
const LABEL = { A: 'סמסטר א', B: 'סמסטר ב', AB: 'סמסטר א או ב', Y: 'שנתי', S: 'סמסטר קיץ', '?': 'סמסטר לא ידוע' };
export const SEMESTER_ORDER = ['A', 'B', 'AB', 'Y', 'S', '?'];
const FIELD = { 1: 'A', 2: 'B', 3: 'AB' };
const mk = key => ({ key, label: LABEL[key] });

function monthIL(sec) {
  return Number(new Intl.DateTimeFormat('en', { timeZone: 'Asia/Jerusalem', month: 'numeric' }).format(new Date(sec * 1000)));
}

export function semesterOf({ semField, start, end, name = '', short = '' } = {}) {
  if (FIELD[semField]) return mk(FIELD[semField]);
  const text = `${name} ${short}`;
  if (/שנתי|yearly|annual/i.test(text)) return mk('Y');
  if (/סמסטר\s*א'?(?![א-ת])|semester\s*(a|1)\b|sem\.?\s*a\b/i.test(text)) return mk('A');
  if (/סמסטר\s*ב'?(?![א-ת])|semester\s*(b|2)\b|sem\.?\s*b\b/i.test(text)) return mk('B');
  if (/קיץ|summer/i.test(text)) return mk('S');
  // Dates only when both ends are set and the span looks like a semester or a year.
  if (!start || !end || end <= start || end - start < 30 * DAY || end - start > 330 * DAY) return mk('?');
  if (end - start > 200 * DAY) return mk('Y');
  const m = monthIL(start);
  if (m >= 9 || m === 1) return mk('A');
  if (m >= 2 && m <= 6) return mk('B');
  return mk('S');
}

// When material counts as "this semester" for a course seen for the first time: from a few weeks
// before its semester starts, since lecturers upload ahead. A date the student set by hand wins.
// year: Moodle site year, "2026-27".
export function currentFrom(course, manualMs = null, year = null) {
  if (manualMs) return manualMs;
  const y = Number(String(year || '').slice(0, 4));
  const key = semesterOf(course || {}).key;
  const at = (yy, m, d) => Date.parse(`${yy}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}T00:00:00+03:00`);
  if (key === '?' || key === 'S') {
    if (course && course.start && course.end && course.end - course.start <= 330 * DAY && course.end > course.start) return (course.start - 21 * DAY) * 1000;
  }
  if (!y) return null;
  if (key === 'B') return at(y + 1, 2, 15);
  if (key === 'S') return at(y + 1, 6, 15);
  return at(y, 9, 20);                     // A, either, yearly, unknown: from the start of the year
}
