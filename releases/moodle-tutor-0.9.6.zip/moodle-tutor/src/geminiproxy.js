// Injected into a notebook.google.com tab (Gemini notebooks, the same notebooks as NotebookLM).
// Calls go out from the page itself, with the student's Google login, like the page's own calls.
// Wire format of the page's batchexecute calls, checked 15.10.2026.
if (!globalThis.__moodleTutorGemini) {
globalThis.__moodleTutorGemini = true;
let tokens = null;
// Which of the Google accounts signed in to Chrome this tab works as (the "authuser" in its address).
// Notebooks work only in personal accounts; a university account is often account 0.
const account = new URLSearchParams(location.search).get('authuser') || '0';

async function loadTokens() {
  const html = await (await fetch(`/?authuser=${account}`, { credentials: 'include' })).text();
  const pick = k => { const m = html.match(new RegExp(`"${k}":"([^"]*)"`)); return m ? m[1] : null; };
  const t = { at: pick('SNlM0e'), bl: pick('cfb2h'), sid: pick('FdrFJe') };
  if (!t.at) throw new Error('login');
  tokens = t;
  return t;
}

// batchexecute answers ")]}'" and then length-prefixed JSON chunks.
function parseBatch(text, id) {
  const out = [];
  for (const line of text.split('\n')) {
    if (!line.startsWith('[')) continue;
    let arr; try { arr = JSON.parse(line); } catch { continue; }
    for (const e of arr) {
      if (Array.isArray(e) && e[0] === 'wrb.fr' && e[1] === id) out.push(e[2] ? JSON.parse(e[2]) : null);
      if (Array.isArray(e) && e[0] === 'er') out.push({ __error: e });
    }
  }
  return out;
}

async function rpc(id, params, path = '/') {
  for (let attempt = 0; attempt < 2; attempt++) {
    const t = tokens || await loadTokens();
    const q = new URLSearchParams({ rpcids: id, 'source-path': path, bl: t.bl || '', 'f.sid': t.sid || '', hl: 'iw', authuser: account, _reqid: String(100000 + Math.floor(Math.random() * 800000)), rt: 'c' });
    const body = 'f.req=' + encodeURIComponent(JSON.stringify([[[id, JSON.stringify(params), null, 'generic']]])) + '&at=' + encodeURIComponent(t.at) + '&';
    const res = await fetch('/_/LabsTailwindUi/data/batchexecute?' + q, { method: 'POST', credentials: 'include', headers: { 'content-type': 'application/x-www-form-urlencoded;charset=UTF-8' }, body });
    if ((res.status === 400 || res.status === 401) && attempt === 0) { tokens = null; continue; }   // stale token
    if (res.status === 401 || res.status === 403) throw new Error('login');
    const text = await res.text();
    return { status: res.status, results: parseBatch(text, id) };
  }
}

async function upload({ notebookId, sourceId, name, mime, b64 }) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const start = await fetch(`/upload/_/?authuser=${account}`, {
    method: 'POST', credentials: 'include',
    headers: { 'content-type': 'application/x-www-form-urlencoded;charset=UTF-8', 'x-goog-authuser': account, 'x-goog-upload-command': 'start',
      'x-goog-upload-header-content-length': String(bytes.length), 'x-goog-upload-header-content-type': mime || 'application/octet-stream', 'x-goog-upload-protocol': 'resumable' },
    body: JSON.stringify({ PROJECT_ID: notebookId, SOURCE_NAME: name, SOURCE_ID: sourceId }),
  });
  const url = start.headers.get('x-goog-upload-url');
  if (!start.ok || !url) return { status: start.status, error: 'upload-start' };
  const put = await fetch(url, { method: 'POST', credentials: 'include',
    headers: { 'content-type': 'application/x-www-form-urlencoded;charset=utf-8', 'x-goog-authuser': account, 'x-goog-upload-command': 'upload, finalize', 'x-goog-upload-offset': '0' }, body: bytes });
  return { status: put.status };
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('gnb-')) return;
  (async () => {
    if (msg.type === 'gnb-ping') return { pong: true, account };
    if (msg.type === 'gnb-rpc') return rpc(msg.id, msg.params, msg.path);
    if (msg.type === 'gnb-upload') return upload(msg);
    return { error: 'unknown' };
  })().then(reply, e => reply({ error: String(e && e.message || e) }));
  return true;
});
}
