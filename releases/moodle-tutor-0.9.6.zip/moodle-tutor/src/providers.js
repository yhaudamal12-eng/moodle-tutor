// The chat services a course project can live in. Each adapter talks to its site through a proxy
// script inside one of that site's tabs (send), and offers the same small set of operations:
//   listProjects, createProject, getProject, setInstructions, listFiles, upload, putDoc, readSummaries
// Errors: LoginRequired (sign in to the site), ProjectMissing (deleted on the site).

import { ClaudeProjects, ClaudeLoginRequired, messageText } from './claudeapi.js';

export class LoginRequired extends Error { constructor(site) { super(`${site}-login`); this.site = site; } }
export class ProjectMissing extends Error { constructor() { super('project-missing'); } }

export const PROVIDERS = {
  claude: {
    id: 'claude', label: 'Claude', host: 'https://claude.ai/*', home: 'https://claude.ai/projects', proxy: 'src/claudeproxy.js', ping: 'claude-ping',
    projectUrl: id => `https://claude.ai/project/${id}`,
    limits: { maxFileBytes: 30 * 1024 * 1024, maxFiles: Infinity },
    readsSummaries: true,
  },
  gemini: {
    id: 'gemini', label: 'Gemini', host: 'https://notebook.google.com/*', home: 'https://notebook.google.com/', proxy: 'src/geminiproxy.js', ping: 'gnb-ping',
    projectUrl: (id, account) => `https://notebook.google.com/notebook/${id}${account ? `?authuser=${account}` : ''}`,
    // The notebook site belongs to one of the Google accounts in Chrome: the extension finds which.
    accounts: true,
    // The Gemini app shows the same notebooks, with a new conversation for every question. Summaries
    // written there are read through a gemini.google.com tab (read only).
    app: { id: 'gemini-app', label: 'Gemini', host: 'https://gemini.google.com/*', proxy: 'src/geminiappproxy.js', ping: 'gapp-ping',
      home: account => `https://gemini.google.com/${account && account !== '0' ? `u/${account}/` : ''}app` },
    // Sources per notebook: 50 on the free plan (more with a subscription); 200 MB per file. The tutor
    // gets the 50 most useful, current material first: more sources only make every answer heavier.
    limits: { maxFileBytes: 200 * 1024 * 1024, maxFiles: 50 },
    readsSummaries: true,
  },
  chatgpt: {
    id: 'chatgpt', label: 'ChatGPT', host: 'https://chatgpt.com/*', home: 'https://chatgpt.com/', proxy: 'src/chatgptproxy.js', ping: 'cgpt-ping',
    projectUrl: id => `https://chatgpt.com/g/${id}/project`,
    // Files per project depend on the plan (5 free, 25 Plus, 40 Pro); the real number is read from the project.
    limits: { maxFileBytes: 512 * 1024 * 1024, maxFiles: 5 },
    readsSummaries: true,
  },
};

// ---------- Claude ----------
export function claudeAdapter(send) {
  const api = new ClaudeProjects(send);
  const wrap = async fn => {
    try { return await fn(); }
    catch (e) { if (e instanceof ClaudeLoginRequired) throw new LoginRequired('claude'); throw e; }
  };
  return {
    meta: PROVIDERS.claude,
    listProjects: () => wrap(async () => ((await api.listProjects()) || []).filter(p => !p.archived_at).map(p => ({ uuid: p.uuid, name: p.name }))),
    createProject: (name, description) => wrap(async () => { const p = await api.createProject(name, description); return { uuid: p.uuid, name: p.name }; }),
    getProject: id => wrap(async () => {
      try { const p = await api.getProject(id); return { uuid: p.uuid, name: p.name, instructions: p.prompt_template || '' }; }
      catch (e) { if (e.status === 404) throw new ProjectMissing(); throw e; }
    }),
    setInstructions: (id, text) => wrap(() => api.setInstructions(id, text)),
    listFiles: id => wrap(async () => (await api.listFiles(id)).map(f => ({ file_uuid: f.file_uuid || f.uuid, file_name: f.file_name, size_bytes: f.size_bytes }))),
    upload: (id, name, mime, b64) => wrap(async () => { const r = await api.upload(id, name, mime, b64); return { file_uuid: r.file_uuid || r.uuid }; }),
    // The two files the extension writes are kept as project text documents, updated in place.
    putDoc: (id, name, content) => wrap(async () => {
      const docs = await api.listDocs(id);
      const d = docs.find(x => x.file_name === name);
      if (!d) return (await api.createDoc(id, name, content)).uuid;
      if ((d.content || '') !== content) await api.updateDoc(id, d.uuid, name, content);
      return d.uuid;
    }),
    // Messages the tutor wrote in this project's chats since the last check.
    readSummaries: (id, since = '') => wrap(async () => {
      const convs = (await api.conversations(id, 20)).filter(c => (c.updated_at || '') > since);
      const messages = [];
      for (const c of convs.sort((a, b) => (a.updated_at || '').localeCompare(b.updated_at || ''))) {
        const full = await api.conversation(c.uuid);
        for (const m of (full && full.chat_messages) || []) if (m.sender === 'assistant') messages.push({ uuid: m.uuid, text: messageText(m), at: m.created_at });
      }
      const last = convs.reduce((mx, c) => (c.updated_at > mx ? c.updated_at : mx), since);
      return { messages, since: last };
    }),
  };
}

// ---------- Gemini notebooks ----------
// Remote procedure ids of notebook.google.com (the same service as NotebookLM).
// CHATS / TURNS: a notebook's conversations and the messages in one (checked 17.10.2026).
export const GNB = { LIST: 'wXbhsf', CREATE: 'CCqFvf', GET: 'rLM1Ne', MUTATE: 's0tc2d', ADD_SOURCE: 'izAoDd', REGISTER_FILE: 'o4cbdc', DELETE_SOURCE: 'tGMBJ', CHATS: 'hPTbtc', TURNS: 'khqZz' };
const OPT = [2, null, null, [1, null, null, null, null, null, null, null, null, null, [1]]];
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function firstUuid(x) {
  if (typeof x === 'string') return UUID.test(x) ? x : null;
  if (Array.isArray(x)) for (const y of x) { const u = firstUuid(y); if (u) return u; }
  return null;
}

// A notebook row: [title, sources, id, ...]; a source: [[id], title, meta, ...].
export function decodeNotebook(row) {
  if (!Array.isArray(row)) return null;
  const sources = (Array.isArray(row[1]) ? row[1] : []).filter(Array.isArray).map(s => ({
    file_uuid: Array.isArray(s[0]) ? s[0][0] : s[0], file_name: s[1], size_bytes: null,
  })).filter(s => s.file_uuid);
  const settings = row[7];
  const custom = Array.isArray(settings) && Array.isArray(settings[0]) && settings[0][0] === 2 ? settings[0][1] || '' : '';
  return { uuid: typeof row[2] === 'string' ? row[2] : firstUuid(row.slice(2)), name: row[0], sources, instructions: custom };
}

export function geminiAdapter(send) {
  const call = async (id, params, path = '/') => {
    const r = await send({ type: 'gnb-rpc', id, params, path });
    if (!r || r.error === 'login') throw new LoginRequired('gemini');
    if (r.error) throw new Error(`gemini ${id}: ${r.error}`);
    if (r.status !== 200) throw Object.assign(new Error(`gemini ${id}: ${r.status}`), { status: r.status });
    const err = (r.results || []).find(x => x && x.__error);
    if (err) throw Object.assign(new Error(`gemini ${id}: ${JSON.stringify(err.__error).slice(0, 120)}`), { rpcError: true });
    return (r.results || [])[0];
  };
  const get = async id => {
    const res = await call(GNB.GET, [id, null, OPT, null, 0], `/notebook/${id}`);
    const nb = decodeNotebook(Array.isArray(res) ? res[0] : null);
    if (!nb) throw new ProjectMissing();
    return nb;
  };
  return {
    meta: PROVIDERS.gemini,
    listProjects: async () => {
      const res = await call(GNB.LIST, [null, 1, null, [2]]);
      return ((res && res[0]) || []).map(decodeNotebook).filter(Boolean).map(n => ({ uuid: n.uuid, name: n.name }));
    },
    createProject: async name => {
      const res = await call(GNB.CREATE, [name, null, null, OPT]);
      const uuid = firstUuid(res);
      if (!uuid) throw new Error('gemini: no notebook id');
      return { uuid, name };
    },
    getProject: async id => {
      try { const n = await get(id); return { uuid: n.uuid || id, name: n.name, instructions: n.instructions }; }
      catch (e) { if (e.rpcError || e.status === 404) throw new ProjectMissing(); throw e; }
    },
    // Custom chat goal of the notebook.
    setInstructions: (id, text) => call(GNB.MUTATE, [id, [[null, null, null, null, null, null, null, [[2, text], [1]]]]], `/notebook/${id}`),
    listFiles: async id => (await get(id)).sources,
    upload: async (id, name, mime, b64) => {
      const res = await call(GNB.REGISTER_FILE, [[[name]], id, OPT], `/notebook/${id}`);
      const sourceId = firstUuid(res);
      if (!sourceId) throw new Error('gemini: file not registered');
      const up = await send({ type: 'gnb-upload', notebookId: id, sourceId, name, mime, b64 });
      if (!up || up.error || up.status >= 300) throw Object.assign(new Error(`gemini upload: ${(up && (up.error || up.status))}`), { status: up && up.status });
      return { file_uuid: sourceId };
    },
    // Text sources cannot be edited: the new version is added, then the extension's own previous one removed.
    putDoc: async (id, name, content, prevId) => {
      const res = await call(GNB.ADD_SOURCE, [[[null, [name, content], null, 2, null, null, null, null, null, null, 1]], id, OPT], `/notebook/${id}`);
      const newId = firstUuid(res);
      if (prevId && newId && prevId !== newId) await call(GNB.DELETE_SOURCE, [[[prevId]]], `/notebook/${id}`).catch(() => {});
      return newId;
    },
    removeFile: (id, sourceId) => call(GNB.DELETE_SOURCE, [[[sourceId]]], `/notebook/${id}`),
    // Conversations: [[id, [created s, ns], [updated s, ns]], ...]. A turn: [id, [s, ns], role (1 me, 2 the tutor),
    // my text, [[the tutor's text, ...]], ...], newest first. "since" is the last update seen, in ms.
    readSummaries: async (id, since = '') => {
      const after = Number(since) || 0;
      const ms = t => Array.isArray(t) ? t[0] * 1000 + Math.floor((t[1] || 0) / 1e6) : 0;
      const chats = (((await call(GNB.CHATS, [[], null, id], `/notebook/${id}`)) || [])[0] || [])
        .filter(c => Array.isArray(c) && typeof c[0] === 'string' && ms(c[2] || c[1]) > after);
      const messages = [];
      let last = after;
      for (const c of chats) {
        last = Math.max(last, ms(c[2] || c[1]));
        const turns = ((await call(GNB.TURNS, [[], null, null, c[0], 50], `/notebook/${id}`)) || [])[0] || [];
        for (const t of turns) {
          if (!Array.isArray(t) || t[2] !== 2) continue;
          const text = Array.isArray(t[4]) && Array.isArray(t[4][0]) ? t[4][0][0] : null;
          if (typeof text === 'string' && text) messages.push({ uuid: t[0], text, at: new Date(ms(t[1])).toISOString() });
        }
      }
      return { messages: messages.sort((a, b) => a.at.localeCompare(b.at)), since: String(last) };
    },
  };
}

// ---------- ChatGPT projects ----------
export function chatgptAdapter(send) {
  const call = async (method, path, json) => {
    const r = await send({ type: 'cgpt-api', method, path, json });
    if (!r || r.error === 'login') throw new LoginRequired('chatgpt');
    if (r.error) throw new Error(`chatgpt: ${r.error}`);
    if (r.status === 404) throw new ProjectMissing();
    if (r.status < 200 || r.status >= 300) throw Object.assign(new Error(`chatgpt ${method} ${path.split('?')[0].replace(/g-p-\w+/, '…')}: ${r.status}`), { status: r.status });
    try { return r.body ? JSON.parse(r.body) : null; } catch { return null; }
  };
  const get = id => call('GET', `/backend-api/gizmos/${id}?include_file_limits=true`);
  const name = g => (g && g.display && g.display.name) || '';
  return {
    meta: PROVIDERS.chatgpt,
    listProjects: async () => {
      const j = await call('GET', '/backend-api/gizmos/snorlax/sidebar?owned_only=true&conversations_per_gizmo=0');
      return ((j && j.items) || []).map(i => i.gizmo && i.gizmo.gizmo).filter(Boolean).map(g => ({ uuid: g.id, name: name(g) }));
    },
    createProject: async projectName => {
      const j = await call('POST', '/backend-api/projects', { name: projectName, instructions: '', emoji: null, theme: null });
      const g = j && j.resource && j.resource.gizmo;
      if (!g || !g.id) throw new Error('chatgpt: no project id');
      return { uuid: g.id, name: name(g) };
    },
    getProject: async id => {
      const j = await get(id);
      const g = j && j.gizmo;
      if (!g) throw new ProjectMissing();
      return { uuid: g.id, name: name(g), instructions: g.instructions || '', maxFiles: j.project_file_limits && j.project_file_limits.max_file_limit };
    },
    setInstructions: async (id, text) => {
      const j = await get(id);
      return call('PATCH', `/backend-api/projects/${id}`, { name: name(j.gizmo), instructions: text, emoji: j.gizmo.display.emoji || null, theme: j.gizmo.display.theme || null });
    },
    listFiles: async id => ((await get(id)).files || []).map(f => ({ file_uuid: f.file_id, file_name: f.name, size_bytes: f.size })),
    upload: async (id, fileName, mime, b64) => {
      const r = await send({ type: 'cgpt-upload', projectId: id, name: fileName, mime, b64 });
      if (!r || r.error === 'login') throw new LoginRequired('chatgpt');
      if (r.error || r.status !== 200) throw Object.assign(new Error(`chatgpt upload: ${r.error || r.status}`), { status: r.status });
      return { file_uuid: r.file_id };
    },
    // The extension's own text files: the new version is added, then its previous one removed.
    putDoc: async (id, fileName, content, prevId) => {
      const b64 = btoa(String.fromCharCode(...new TextEncoder().encode(content)));
      const r = await send({ type: 'cgpt-upload', projectId: id, name: fileName, mime: 'text/markdown', b64 });
      if (!r || r.error || r.status !== 200) throw new Error(`chatgpt doc: ${(r && (r.error || r.status))}`);
      if (prevId && prevId !== r.file_id) await call('DELETE', `/backend-api/projects/${id}/files/${prevId}`).catch(() => {});
      return r.file_id;
    },
    removeFile: (id, fileId) => call('DELETE', `/backend-api/projects/${id}/files/${fileId}`),
    readSummaries: async (id, since = '') => {
      const j = await call('GET', `/backend-api/gizmos/${id}/conversations?limit=20&owned_only=true`);
      const convs = ((j && j.items) || []).filter(c => (c.update_time || '') > since);
      const messages = [];
      for (const c of convs.sort((a, b) => String(a.update_time).localeCompare(String(b.update_time)))) {
        const full = await call('GET', `/backend-api/conversation/${c.id}`);
        for (const node of Object.values((full && full.mapping) || {})) {
          const m = node && node.message;
          if (!m || !m.author || m.author.role !== 'assistant' || !m.content) continue;
          const text = (m.content.parts || []).filter(p => typeof p === 'string').join('\n');
          if (text) messages.push({ uuid: m.id, text, at: m.create_time ? new Date(m.create_time * 1000).toISOString() : null });
        }
      }
      const last = convs.reduce((mx, c) => (String(c.update_time) > mx ? String(c.update_time) : mx), since);
      return { messages, since: last };
    },
  };
}

// The Gemini app (gemini.google.com): the conversations of one notebook, checked 21.10.2026.
// LIST [10, null, [null, null, 1, "notebooks/<id>", 1]] → [null, null, [[convId, title, …, [updated s, ns], …], …]]
// READ [convId, 10, null, 1, [1], [4], null, 1] → [[turn, …]] newest first; a turn:
// [[convId, responseId], …, [[my text, …], …], [[[replyId, [the tutor's text], …]], …], [s, ns], …]
export const GAPP = { LIST: 'MaZiqc', READ: 'hNvQHb' };
export async function readAppSummaries(send, notebookId, since = '') {
  const call = async (id, params) => {
    const r = await send({ type: 'gapp-rpc', id, params, path: `/notebook/${notebookId}` });
    if (!r || r.error === 'login') throw new LoginRequired('gemini');
    if (r.error || r.status !== 200) throw new Error(`gemini app ${id}: ${r.error || r.status}`);
    return (r.results || [])[0];
  };
  const after = Number(since) || 0;
  const ms = t => Array.isArray(t) ? t[0] * 1000 + Math.floor((t[1] || 0) / 1e6) : 0;
  const list = await call(GAPP.LIST, [10, null, [null, null, 1, `notebooks/${notebookId}`, 1]]);
  const convs = ((Array.isArray(list) && list[2]) || []).filter(c => Array.isArray(c) && typeof c[0] === 'string' && ms(c[5]) > after);
  const messages = [];
  let last = after;
  for (const c of convs) {
    last = Math.max(last, ms(c[5]));
    const res = await call(GAPP.READ, [c[0], 10, null, 1, [1], [4], null, 1]);
    for (const t of ((Array.isArray(res) && res[0]) || [])) {
      const reply = Array.isArray(t) && Array.isArray(t[3]) && Array.isArray(t[3][0]) ? t[3][0][0] : null;
      const text = Array.isArray(reply) && Array.isArray(reply[1]) ? reply[1][0] : null;
      if (Array.isArray(reply) && typeof reply[0] === 'string' && typeof text === 'string' && text) messages.push({ uuid: reply[0], text, at: new Date(ms(t[4])).toISOString() });
    }
  }
  return { messages: messages.sort((a, b) => a.at.localeCompare(b.at)), since: String(last) };
}

export function adapterFor(provider, send) {
  return provider === 'gemini' ? geminiAdapter(send) : provider === 'chatgpt' ? chatgptAdapter(send) : claudeAdapter(send);
}
