// Where a course file is saved under the Downloads folder: Moodle/<year>/<course>/<section>/<file>.
// Chrome's downloads API can only write inside the browser's download folder.

const RESERVED = /^(con|prn|aux|nul|com\d|lpt\d)$/i;

export function safeName(s, max = 80) {
  let out = String(s || '')
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[. ]+$/, '');
  if (!out) out = '_';
  if (RESERVED.test(out)) out = `_${out}`;
  if (out.length > max) {
    const dot = out.lastIndexOf('.');
    const ext = dot > 0 && out.length - dot <= 8 ? out.slice(dot) : '';
    out = out.slice(0, max - ext.length).trim() + ext;
  }
  return out;
}

// Course "52325 - Statistical Inference" -> "52325 הסקה סטטיסטית ושימושיה" when a Hebrew short name exists.
export function courseFolder(course) {
  const short = (course.short || '').replace(/^(\d+(?:_\d+)?)-/, '$1 ');
  return safeName(short || course.name, 60);
}

// Moodle course categories at HUJI come in English; common ones get their Hebrew name.
const DEPARTMENTS = {
  statistics: 'סטטיסטיקה', economics: 'כלכלה', mathematics: 'מתמטיקה', 'computer science': 'מדעי המחשב',
  psychology: 'פסיכולוגיה', 'political science': 'מדע המדינה', sociology: 'סוציולוגיה', law: 'משפטים',
  'business administration': 'מנהל עסקים', physics: 'פיזיקה', 'international relations': 'יחסים בינלאומיים',
};

export function departmentFolder(course) {
  const cat = String(course.category || '').trim();
  if (!cat) return 'כללי';
  return safeName(DEPARTMENTS[cat.toLowerCase()] || cat, 40);
}

export function rootName(root) { return safeName(root || 'Moodle', 40); }

export function downloadPath({ year, course, sectionTitle, itemName, filename, multiFile, root }) {
  const parts = [rootName(root), year, departmentFolder(course), courseFolder(course), safeName(sectionTitle || 'כללי', 50)];
  if (multiFile) parts.push(safeName(itemName, 50));
  parts.push(safeName(filename, 100));
  return parts.join('/');
}

// Plain fallback path, used only if Chrome refuses the regular one.
export function fallbackPath({ year, course, filename, root }) {
  const num = ((course.short || course.name || '').match(/^\d+(?:_\d+)?/) || ['course'])[0];
  const ascii = String(filename || 'file').normalize('NFKD').replace(/[^\w.\- ]+/g, '_').replace(/_+/g, '_').trim() || 'file';
  return [rootName(root).normalize('NFKD').replace(/[^\w.\- ]+/g, '_') || 'Moodle', year, num, safeName(ascii, 100)].join('/');
}

// The course's folder, relative to the Downloads folder.
export function courseDir({ year, course, root }) {
  return [rootName(root), year, departmentFolder(course), courseFolder(course)].join('/');
}
