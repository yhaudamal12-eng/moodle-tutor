// New versions for friends who installed from a zip: Chrome updates only store extensions, so the
// extension looks for a newer release itself, downloads it, and reloads once its files are replaced.

// Where versions are published: a public GitHub repository holding latest.json and the zips.
// latest.json: { "version": "0.9.2", "file": "releases/moodle-tutor-0.9.2.zip", "notes": "..." }
export const REPO_RAW = 'https://raw.githubusercontent.com/yhaudamal12-eng/moodle-tutor/main/';
export const LATEST_URL = REPO_RAW + 'latest.json';

// "0.10.0" > "0.9.3": compared part by part, as numbers.
export function newer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (Number.isNaN(x) || Number.isNaN(y)) return false;
    if (x !== y) return x > y;
  }
  return false;
}

// From latest.json: the version and the zip to download, when newer than ours. The zip must sit in
// the same repository, so a broken or tampered file cannot send the student elsewhere.
export function pickUpdate(latest, current) {
  if (!latest || typeof latest !== 'object') return null;
  const version = String(latest.version || '');
  const file = String(latest.file || '');
  if (!/^\d+(\.\d+)*$/.test(version) || !/^[\w./-]+\.zip$/.test(file) || file.includes('..') || !newer(version, current)) return null;
  return { version, url: REPO_RAW + file, notes: String(latest.notes || '').slice(0, 600) };
}

// The one PowerShell line that puts the new files where the install guide put the old ones:
// the zip holds a "moodle-tutor" folder, and Documents is found even when OneDrive moved it.
export function extractCommand(zipPath) {
  const p = String(zipPath).replace(/"/g, '');
  return `Expand-Archive -Path "${p}" -DestinationPath ([Environment]::GetFolderPath('MyDocuments')) -Force`;
}
