import { isLoginUrl } from './sites.js';
// Download queue: one file at a time, survives Chrome restarts, detects Chrome's
// "ask where to save each file" setting, and can be stopped.
//
// Everything Chrome-specific is injected, so the logic runs in tests:
//   api   = { download(opts) -> id, search({id}) -> [item], cancel(id), removeFile(id), erase({id}) }
//   store = { load() -> state, save(state) }
//   later = (fn, ms) => void            (a timer)

const PROMPT_CHECK_MS = 4000;
const MAX_ATTEMPTS = 3;

export function looksLikeLoginPage(item, job) {
  if (item.finalUrl && isLoginUrl(item.finalUrl)) return true;
  const wantedHtml = job && /\.html?$/i.test(job.filename);
  return !wantedHtml && /^text\/html/i.test(item.mime || '');
}

export function emptyState() {
  return { queue: {}, order: [], inFlight: null, paused: false, blocked: null, saved: {}, failed: {}, skipped: {}, held: {}, renamed: {}, done: 0 };
}

const norm = p => String(p || '').replace(/\\/g, '/').normalize('NFC').toLowerCase();
const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
// Chrome reports the full path on disk; we asked for a path relative to the Downloads folder.
export const samePath = (full, rel) => { const f = norm(full), r = norm(rel); return f === r || f.endsWith('/' + r); };
const FROM_MOODLE = /^https:\/\/[^/]+\/.*pluginfile\.php\//;   // a file from a Moodle site

const VIDEO = /\.(mp4|m4v|mov|mkv|avi|webm|wmv|flv|mpe?g)$/i;

// Which files wait for the student's explicit OK instead of downloading on their own.
export function holdReason(job, { maxBytes = 50 * 1024 * 1024, skipVideos = true } = {}) {
  if (job.force) return null;
  if (skipVideos && (VIDEO.test(job.filename || '') || /^video\//i.test(job.type || ''))) return 'video';
  if (maxBytes && job.size && job.size > maxBytes) return 'too-large';
  return null;
}

export class DownloadQueue {
  // gap: the pause between one finished download and the next, random so the traffic looks like
  // a person clicking through files rather than a burst.
  constructor({ api, store, later = (fn, ms) => setTimeout(fn, ms), policy = async () => ({}), wait = ms => new Promise(r => setTimeout(r, ms)), gap = () => 1000 + Math.random() * 2000 }) {
    this.api = api; this.store = store; this.later = later; this.policy = policy; this.wait = wait; this.gap = gap;
    this.lock = Promise.resolve();
  }

  // All state changes run one after another, so two events never overwrite each other.
  run(fn) {
    const next = this.lock.then(async () => {
      const st = { ...emptyState(), ...(await this.store.load()) };
      const out = await fn(st);
      await this.store.save(st);
      return out;
    });
    this.lock = next.catch(() => {});
    return next;
  }

  enqueue(jobs) {
    return this.run(async st => {
      const opts = await this.policy();
      for (const j of jobs) {
        if (st.saved[j.sig] || st.skipped[j.sig] || st.held[j.sig]) continue;
        if (st.queue[j.sig]) { Object.assign(st.queue[j.sig], { size: j.size ?? st.queue[j.sig].size, type: j.type ?? st.queue[j.sig].type }); continue; }
        const job = { url: j.url, filename: j.filename, fallback: j.fallback || null, size: j.size || null, type: j.type || null, attempts: 0 };
        const why = holdReason(job, opts);
        if (why) { st.held[j.sig] = { ...job, reason: why }; continue; }
        st.queue[j.sig] = job;
        st.order.push(j.sig);
      }
    }).then(() => this.pump());
  }

  // Start the next download if nothing is running.
  pump() {
    return this.run(async st => {
      if (st.paused || st.blocked || st.inFlight) return;
      // Large files and videos wait in "held" until the student asks for them.
      const opts = await this.policy();
      let sig;
      for (;;) {
        sig = st.order.find(s => st.queue[s]);
        if (!sig) break;
        const why = holdReason(st.queue[sig], opts);
        if (!why) break;
        st.held[sig] = { ...st.queue[sig], reason: why };
        delete st.queue[sig];
      }
      st.order = st.order.filter(s => st.queue[s]);
      if (!sig) return;
      const job = st.queue[sig];
      let id;
      try {
        // A file already at that path is replaced only if it is an earlier download of a Moodle file.
        // Anything else there (the student's own notes, a file from elsewhere) is kept, and the new
        // file is saved next to it as "name (1).pdf".
        const conflictAction = (await this.ownsPath(job.filename)) ? 'overwrite' : 'uniquify';
        id = await this.api.download({ url: job.url, filename: job.filename, conflictAction, saveAs: false });
      } catch (e) {
        // Chrome refused the path (e.g. characters the disk cannot store): retry once with a plain path.
        if (/invalid filename/i.test(String(e && e.message)) && job.fallback && job.filename !== job.fallback) {
          job.filename = job.fallback;
          this.later(() => this.pump(), 0);
          return;
        }
        job.attempts++;
        if (job.attempts >= MAX_ATTEMPTS) { st.failed[sig] = { filename: job.filename, error: String(e && e.message || e) }; delete st.queue[sig]; }
        else { st.order = st.order.filter(s => s !== sig).concat(sig); }
        this.later(() => this.pump(), 0);
        return;
      }
      st.inFlight = { id, sig, startedAt: Date.now() };
      this.later(() => this.checkPrompt(id), PROMPT_CHECK_MS);
    });
  }

  async ownsPath(rel) {
    const base = rel.split('/').pop();
    let items = [];
    try { items = await this.api.search({ filenameRegex: escRe(base) + '$', exists: true }); } catch { return false; }
    return items.some(i => i.exists !== false && i.state === 'complete' && samePath(i.filename, rel) && FROM_MOODLE.test(i.finalUrl || i.url || ''));
  }

  // While Chrome shows its "Save as" window, the download has no file name yet.
  // If that is still so after a few seconds, the setting is on: stop and tell the student.
  checkPrompt(id) {
    return this.run(async st => {
      if (!st.inFlight || st.inFlight.id !== id) return;
      const [item] = await this.api.search({ id });
      if (item && item.state === 'in_progress' && !item.filename) {
        st.blocked = 'ask-where-to-save';
        st.inFlight.cancelledByUs = true;
        await this.api.cancel(id);
      }
    });
  }

  // Chrome's downloads.onChanged.
  onChanged(delta) {
    if (!delta.state) return Promise.resolve();
    return this.run(async st => {
      if (!st.inFlight || st.inFlight.id !== delta.id) return;
      const { sig, cancelledByUs } = st.inFlight;
      const job = st.queue[sig];
      if (delta.state.current === 'complete') {
        // Not logged in, Moodle answers a file request with the login page. Chrome then "completes"
        // a download of that page. Throw it away, keep the file queued, and ask for a login.
        const [item] = await this.api.search({ id: delta.id }).catch(() => []);
        if (item && looksLikeLoginPage(item, job)) {
          await this.api.removeFile(delta.id).catch(() => {});
          await this.api.erase({ id: delta.id }).catch(() => {});
          st.blocked = 'login-required';
        } else {
          st.saved[sig] = { at: Date.now(), id: delta.id, path: job && job.filename, url: job && job.url };
          if (item && item.filename && job && !samePath(item.filename, job.filename)) st.renamed[sig] = { wanted: job.filename, got: item.filename };
          else delete st.renamed[sig];
          st.done++;
          delete st.queue[sig];
        }
      } else if (delta.state.current === 'interrupted') {
        const reason = delta.error && delta.error.current;
        // Cancelled while it still had no file name = the "Save as" window was closed:
        // that is Chrome's ask-where-to-save setting, not the student skipping this file.
        let noName = false;
        if (reason === 'USER_CANCELED' && !cancelledByUs) {
          const [item] = await this.api.search({ id: delta.id }).catch(() => []);
          noName = !!item && !item.filename;
        }
        if (cancelledByUs) { /* stays queued */ }
        else if (noName) { st.blocked = 'ask-where-to-save'; }
        else if (reason === 'USER_CANCELED') { st.skipped[sig] = { filename: job && job.filename }; delete st.queue[sig]; }
        else if (job) {
          job.attempts++;
          if (job.attempts >= MAX_ATTEMPTS) { st.failed[sig] = { filename: job.filename, error: reason || 'interrupted' }; delete st.queue[sig]; }
          else st.order = st.order.filter(s => s !== sig).concat(sig);
        }
      } else return false;
      const finished = st.inFlight;
      st.inFlight = null;
      return !!finished;
    }).then(next => { if (next) this.later(() => this.pump(), this.gap()); });
  }

  // When the extension wakes up (including after Chrome restarts): a download Chrome no longer
  // runs is queued again; one that finished while we were away is recorded; one still running is left alone.
  startup() {
    return this.run(async st => {
      if (!st.inFlight) return;
      const [item] = await this.api.search({ id: st.inFlight.id }).catch(() => []);
      if (item && item.state === 'in_progress' && item.filename && !item.paused) return;
      if (item && item.state === 'complete') { const j = st.queue[st.inFlight.sig] || {}; st.saved[st.inFlight.sig] = { at: Date.now(), id: item.id, path: j.filename, url: j.url }; delete st.queue[st.inFlight.sig]; st.done++; }
      st.inFlight = null;
    }).then(() => this.pump());
  }

  stop() {
    return this.run(async st => {
      st.paused = true;
      if (st.inFlight) { st.inFlight.cancelledByUs = true; await this.api.cancel(st.inFlight.id).catch(() => {}); }
    });
  }

  resume() {
    return this.run(st => { st.paused = false; st.blocked = null; }).then(() => this.pump());
  }

  // The student asked for a held file (or all of them): download it despite its size or type.
  release(sigs) {
    return this.run(st => {
      for (const sig of (sigs === 'all' ? Object.keys(st.held) : sigs)) {
        const h = st.held[sig];
        if (!h) continue;
        const { reason, ...job } = h;
        st.queue[sig] = { ...job, force: true, attempts: 0 };
        st.order.push(sig);
        delete st.held[sig];
      }
    }).then(() => this.pump());
  }

  // Files this extension saved that are no longer on disk (deleted or moved by the student).
  // Chrome re-checks whether downloaded files still exist only when the downloads list is searched,
  // at most once every 10 seconds, and answers from its old record meanwhile. So keep asking for a
  // little over 10 seconds: one of these asks is sure to start a fresh check, and the last reads it.
  async missing() {
    const { saved } = await this.run(st => ({ saved: { ...st.saved } }));
    const ids = Object.entries(saved).filter(([, v]) => v && typeof v === 'object' && v.id);
    const gone = new Set();
    for (const pause of [0, 1000, 1500, 2500, 3000, 3000, 1500]) {
      if (pause) await this.wait(pause);
      for (const [sig, v] of ids) {
        if (gone.has(sig)) continue;
        const [item] = await this.api.search({ id: v.id }).catch(() => []);
        if (item && item.exists === false) gone.add(sig);
      }
    }
    return ids.filter(([sig]) => gone.has(sig)).map(([sig, v]) => ({ sig, path: v.path }));
  }

  // Download again files the student lost.
  redownload(sigs) {
    return this.run(st => {
      for (const sig of sigs) {
        const v = st.saved[sig];
        if (!v || !v.url || !v.path) continue;
        delete st.saved[sig];
        st.queue[sig] = { url: v.url, filename: v.path, fallback: null, size: null, type: null, attempts: 0, force: true };
        st.order.push(sig);
      }
    }).then(() => this.pump());
  }

  resumeIfBlockedBy(reason) {
    return this.run(st => { if (st.blocked === reason) st.blocked = null; }).then(() => this.pump());
  }

  reset() {
    return this.run(async st => {
      if (st.inFlight) await this.api.cancel(st.inFlight.id).catch(() => {});
      Object.assign(st, emptyState());
    });
  }

  summary() {
    return this.run(st => ({
      waiting: Object.keys(st.queue).length,
      running: st.inFlight ? st.queue[st.inFlight.sig] && st.queue[st.inFlight.sig].filename : null,
      done: st.done, failed: Object.values(st.failed), skipped: Object.keys(st.skipped).length,
      held: Object.entries(st.held).map(([sig, h]) => ({ sig, name: h.filename.split('/').pop(), size: h.size, reason: h.reason })),
      paused: st.paused, blocked: st.blocked,
      renamed: Object.values(st.renamed || {}).map(r => ({ wanted: r.wanted.split('/').pop(), got: String(r.got).split(/[\\/]/).pop() })),
    }));
  }
}
