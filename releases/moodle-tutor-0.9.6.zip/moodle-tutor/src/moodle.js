// Moodle client (the Hebrew University's by default, or any Moodle site). Runs in the extension's service worker, which has no
// DOMParser, so HTML is read with small, targeted regular expressions.
// Every request uses the student's existing browser session; no password is ever stored.

export class LoginRequired extends Error {
  constructor(msg = 'login-required') { super(msg); this.code = 'login-required'; }
}

import { rootFor, isLoginUrl } from './sites.js';

export function yearRoot(year, site = null) { return rootFor(site, year); }

// "2026-27" for an academic year that starts in autumn 2026.
export function academicYearFor(date = new Date()) {
  const y = date.getUTCFullYear(), m = date.getUTCMonth() + 1;
  const start = m >= 8 ? y : y - 1;
  return `${start}-${String((start + 1) % 100).padStart(2, '0')}`;
}
export function nextYear(year) {
  const s = Number(year.slice(0, 4)) + 1;
  return `${s}-${String((s + 1) % 100).padStart(2, '0')}`;
}
export function prevYear(year) {
  const s = Number(year.slice(0, 4)) - 1;
  return `${s}-${String((s + 1) % 100).padStart(2, '0')}`;
}

export function isLoginResponse(res, body = '', site = null) {
  if (res.url && isLoginUrl(res.url, site)) return true;
  return /loginuserpass\.php|SAMLRequest/.test(body);
}

const decode = s => s.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');

// pluginfile links that belong to course content (not user avatars, theme images, etc.).
export function extractContentFiles(html) {
  const out = new Map();
  const re = /(?:href|src|data)\s*=\s*"([^"]*\/pluginfile\.php\/[^"]*\/mod_(?:resource|folder|page|assign|label)\/[^"]*)"/g;
  let m;
  while ((m = re.exec(html))) {
    const url = decode(m[1]).replace(/[?&]forcedownload=1/, '').replace(/\?$/, '');
    const filename = decodeURIComponent(url.split('?')[0].split('/').pop());
    if (!out.has(url)) out.set(url, { url, filename });
  }
  return [...out.values()];
}

export function extractEmbeds(html) {
  const out = [];
  const re = /<iframe[^>]+src\s*=\s*"([^"]+)"/g;
  let m;
  while ((m = re.exec(html))) out.push(decode(m[1]));
  return out;
}

export function extractUrlTarget(html) {
  const m = html.match(/class="urlworkaround"[\s\S]*?href="([^"]+)"/) || html.match(/<div[^>]+role="main"[\s\S]*?<a[^>]+href="(https?:\/\/(?![^"\/]*moodle[^"\/]*\/)[^"]+)"/);
  return m ? decode(m[1]) : null;
}

export function extractMainText(html) {
  const start = html.indexOf('role="main"');
  const body = start >= 0 ? html.slice(start) : html;
  return decode(body.replace(/<script[\s\S]*?<\/script>/g, ' ').replace(/<style[\s\S]*?<\/style>/g, ' ').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
}

export class MoodleClient {
  constructor(year, { fetchImpl = (...args) => fetch(...args), delayMs = 300, site = null } = {}) {
    this.year = year;
    this.site = site;
    this.root = yearRoot(year, site);
    this.fetch = fetchImpl;
    this.delayMs = delayMs;
    this.sesskey = null;
  }

  async pause() {
    const ms = typeof this.delayMs === 'function' ? this.delayMs() : this.delayMs;
    if (ms) await new Promise(r => setTimeout(r, ms));
  }

  async getHtml(path) {
    const res = await this.fetch(`${this.root}${path}`, { credentials: 'include' });
    const body = await res.text();
    if (isLoginResponse(res, body, this.site)) throw new LoginRequired();
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${path}`);
    return { body, url: res.url };
  }

  async ensureSession() {
    if (this.sesskey) return;
    // Logged out, Moodle redirects to the university login site. The extension has no access to
    // that site, so following the redirect would fail as a vague network error. Stop at the
    // redirect instead and report it as "login required".
    let res;
    try {
      res = await this.fetch(`${this.root}/my/`, { credentials: 'include', redirect: 'manual' });
    } catch (e) {
      const err = new Error('network'); err.code = 'network'; err.detail = String(e && e.message || e); throw err;
    }
    if (res.type === 'opaqueredirect' || (res.status >= 300 && res.status < 400)) throw new LoginRequired('redirect-to-login');
    const body = await res.text();
    if (isLoginResponse(res, body, this.site)) throw new LoginRequired();
    if (!res.ok) throw new Error(`HTTP ${res.status} for /my/`);
    const m = body.match(/"sesskey":"([^"]+)"/);
    if (!m) throw new LoginRequired('no-sesskey');
    this.sesskey = m[1];
  }

  async ajax(methodname, args, retried = false) {
    await this.ensureSession();
    const res = await this.fetch(`${this.root}/lib/ajax/service.php?sesskey=${this.sesskey}`, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify([{ index: 0, methodname, args }]),
    });
    const text = await res.text();
    if (isLoginResponse(res, text, this.site)) throw new LoginRequired();
    const date = res.headers && res.headers.get && res.headers.get('date');
    if (date && !Number.isNaN(Date.parse(date))) this.serverDate = Date.parse(date);
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`Bad response from ${methodname}`); }
    const r = Array.isArray(data) ? data[0] : data;
    if (r && r.error) {
      const code = r.exception && r.exception.errorcode;
      if (code === 'servicerequireslogin') throw new LoginRequired();
      if (code === 'invalidsesskey' && !retried) { this.sesskey = null; return this.ajax(methodname, args, true); }
      const err = new Error(`${methodname}: ${code || 'error'}`); err.code = code; throw err;
    }
    return r.data;
  }

  async listCourses() {
    const d = await this.ajax('core_course_get_enrolled_courses_by_timeline_classification',
      { offset: 0, limit: 0, classification: 'all', sort: 'fullname' });
    const list = d.courses.map(c => ({ id: String(c.id), name: c.fullname.trim(), short: c.shortname.trim(), category: c.coursecategory, url: c.viewurl, start: c.startdate || 0, end: c.enddate || 0, semField: null }));
    // The semester, as the Moodle dashboard groups it ("Semester 1 / 2 / 1 Or 2"): a course field.
    const byId = new Map(list.map(c => [c.id, c]));
    for (const v of ['1', '2', '3']) {
      try {
        const g = await this.ajax('core_course_get_enrolled_courses_by_timeline_classification',
          { offset: 0, limit: 0, classification: 'customfield', sort: 'fullname', customfieldname: 'semester', customfieldvalue: v });
        for (const c of g.courses || []) { const x = byId.get(String(c.id)); if (x) x.semField = v; }
      } catch (e) {
        if (e instanceof LoginRequired) throw e;
        break;                              // a Moodle without this field: dates and names decide
      }
    }
    return list;
  }

  // Course structure. Does not open any item, so it marks nothing as viewed.
  async courseState(courseId) {
    const raw = await this.ajax('core_courseformat_get_state', { courseid: Number(courseId) });
    const s = typeof raw === 'string' ? JSON.parse(raw) : raw;
    const sectionOf = new Map();
    const sections = s.section.map(sec => {
      const title = decode(sec.title || '').trim();
      for (const cmid of sec.cmlist || []) sectionOf.set(String(cmid), { id: String(sec.id), title });
      return { id: String(sec.id), title, number: sec.number };
    });
    const titleById = new Map(sections.map(x => [x.id, x.title]));
    const cms = s.cm.map(c => {
      const sid = c.sectionid != null ? String(c.sectionid) : null;
      const sec = sid ? { id: sid, title: titleById.get(sid) || '' } : (sectionOf.get(String(c.id)) || { id: '', title: '' });
      return { cmid: String(c.id), kind: c.module, name: decode(c.name || '').trim(), url: c.url || null,
        sectionId: sec.id, sectionTitle: sec.title, visible: c.uservisible !== false };
    });
    return { sections, cms };
  }

  // Opens the item's own page. Moodle logs this as a view, so the scanner calls it only for
  // new items, or on the slow folder recheck.
  async resolveItem(cm) {
    switch (cm.kind) {
      case 'resource': {
        // Many resources skip their page and send the file straight away (all the slides in a
        // real course did). A light HEAD request shows where it lands: on the file itself, or
        // on a page that links to it. HEAD also returns the size and signature without downloading.
        // One request with "peek": if Moodle answers with the file itself, the download is cut off
        // right after the headers; if it answers with a page, the page is read. Either way the item
        // is opened (and logged as viewed) exactly once.
        const res = await this.fetch(`${this.root}/mod/resource/view.php?id=${cm.cmid}&redirect=0`, { credentials: 'include', peek: true });
        if (/\/pluginfile\.php\//.test(res.url || '')) {
          const url = res.url.replace(/[?&]forcedownload=1/, '').replace(/\?$/, '');
          const filename = decodeURIComponent(url.split('?')[0].split('/').pop());
          return { files: [{ url, filename, head: {
            etag: (res.headers.get('etag') || '').replace(/"/g, '') || null,
            size: Number(res.headers.get('content-length')) || null,
            mtime: res.headers.get('last-modified') || null,
            type: res.headers.get('content-type') || null } }] };
        }
        const body = await res.text();
        if (isLoginResponse(res, body, this.site)) throw new LoginRequired();
        return { files: extractContentFiles(body) };
      }
      case 'folder': {
        const { body } = await this.getHtml(`/mod/folder/view.php?id=${cm.cmid}`);
        return { files: extractContentFiles(body) };
      }
      case 'page': {
        const { body } = await this.getHtml(`/mod/page/view.php?id=${cm.cmid}`);
        return { files: extractContentFiles(body), embeds: extractEmbeds(body), text: extractMainText(body).slice(0, 20000) };
      }
      case 'url': {
        const { body } = await this.getHtml(`/mod/url/view.php?id=${cm.cmid}&redirect=0`);
        return { files: [], target: extractUrlTarget(body) };
      }
      case 'assign': {
        const { body } = await this.getHtml(`/mod/assign/view.php?id=${cm.cmid}`);
        return { files: extractContentFiles(body), text: extractMainText(body).slice(0, 20000) };
      }
      default:
        return { files: [] };
    }
  }

  // Size, date and content signature of a file, without downloading it and without a view log.
  async headFile(url) {
    const res = await this.fetch(url, { method: 'HEAD', credentials: 'include' });
    if (isLoginResponse(res, "", this.site)) throw new LoginRequired();
    if (!res.ok) return { missing: true, status: res.status };
    return {
      etag: (res.headers.get('etag') || '').replace(/"/g, '') || null,
      size: Number(res.headers.get('content-length')) || null,
      mtime: res.headers.get('last-modified') || null,
      type: res.headers.get('content-type') || null,
    };
  }

  // Which items changed since a time, and in which area ("contentfiles", "configuration", ...).
  // Silent: opens nothing and logs no view. Returns Map(cmid -> [area names]).
  async updatesSince(courseId, sinceMs) {
    const d = await this.ajax('core_course_get_updates_since', { courseid: Number(courseId), since: Math.floor(sinceMs / 1000) });
    const out = new Map();
    for (const inst of d.instances || []) {
      if (inst.contextlevel !== 'module') continue;
      out.set(String(inst.id), (inst.updates || []).map(u => u.name));
    }
    return out;
  }

  // Recordings listed in the course's Panopto block (title + viewer link). Silent.
  async panoptoRecordings(courseId) {
    let html;
    try { html = await this.ajax('block_panopto_get_content', { courseid: Number(courseId) }); }
    catch (e) { if (e instanceof LoginRequired) throw e; return []; }
    if (typeof html === 'string' && html.trim().startsWith('{')) { try { html = JSON.parse(html); } catch { /* keep as is */ } }
    if (typeof html !== 'string') html = (html && (html.data || html.html)) || '';
    const out = [];
    const re = /<a[^>]+href='(https:\/\/[^']*panopto[^']*Viewer\.aspx\?id=([0-9a-f-]{36})[^']*)'[^>]*>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m = re.exec(html))) out.push({ id: m[2], url: decode(m[1]), title: decode(m[3].replace(/<[^>]+>/g, '')).trim() });
    return out;
  }

  // What the student still has to do, as on the Moodle dashboard's timeline: submissions, quizzes and
  // the like, from two weeks back (overdue ones stay until submitted) on. Moodle drops an item once done.
  async upcomingDeadlines(now = Date.now()) {
    const d = await this.ajax('core_calendar_get_action_events_by_timesort',
      { timesortfrom: Math.floor(now / 1000) - 14 * 86400, limitnum: 50 });
    return (d.events || []).map(e => ({
      id: String(e.id), courseId: String(e.course && e.course.id), name: decode(e.activityname || e.name || ''),
      cmid: String(e.coursemoduleid || ''), due: e.timesort * 1000, kind: e.modulename || '',
      url: (e.action && e.action.url) || e.url || '', overdue: !!e.overdue,
    }));
  }

  // 404 means the site for that year does not exist yet.
  async yearExists(year) {
    const res = await this.fetch(`${yearRoot(year, this.site)}/`, { method: 'HEAD', credentials: 'include' });
    return res.status !== 404;
  }
}
