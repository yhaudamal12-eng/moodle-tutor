import { currentFrom } from './semester.js';
// Runs one scan of all courses and returns the new snapshot plus the change events.
// The Moodle client is injected, so tests run against a fake.

import { diffCourse, mergeCourse } from './diff.js';
import { guessCategory, guessMaterial, sourceYear } from './classify.js';
import { LoginRequired } from './moodle.js';

// Thrown when the student presses "stop". Handled like an interrupted scan: nothing is lost.
export class Stopped extends Error { constructor() { super('stopped'); this.code = 'stopped'; } }

export function decideMaterial(item, old, touchedThisSemester, academicYearStart) {
  if (old && old.material) return old.material;            // decided once; a student's correction is kept in merge
  if (sourceYear(`${item.name} ${item.sectionTitle}`, academicYearStart) !== null) return 'support';
  if (touchedThisSemester) return touchedThisSemester.has(item.cmid) ? 'current' : 'support';
  return guessMaterial(item, academicYearStart);           // an item added later in the semester: current unless named otherwise
}

// Item kinds whose content is worth opening. Forums, attendance and labels carry no files.
const RESOLVER_VERSION = 2;
const RESOLVABLE = new Set(['resource', 'folder', 'page', 'url', 'assign']);

// semesterStart (ms): items not created or changed since then are reference ("support")
// material carried over from earlier years; anything touched or added after it is current.
// courseChoice(courseId) -> 'on' (scan fully), 'off' (skip), 'pending' (not decided yet: read the
// structure only and report how many items would be opened, so the student can approve first).
export async function scanAll(client, prevSnapshot, { now = Date.now(), onProgress = () => {}, semesterStart = null,
  courseChoice = () => 'on', shouldStop = () => false } = {}) {
  const prev = prevSnapshot || { courses: {} };
  const academicYearStart = Number(client.year.slice(0, 4));
  const result = {
    year: client.year,
    scannedAt: now,
    status: 'ok',
    courses: {},
    courseList: prev.courseList || [],
    events: [],
    opened: 0,
    errors: [],
    plan: [],          // courses waiting for the student's approval
  };

  let courses;
  try {
    courses = await client.listCourses();
    result.courseList = courses;
    // Moodle's own clock at the start of the scan. The next scan asks "what changed since then",
    // so a difference between the computer's clock and Moodle's cannot hide or repeat a change.
    result.serverTime = client.serverDate || now;
  } catch (e) {
    result.status = e instanceof LoginRequired ? 'login-required' : 'error';
    result.errors.push(String(e.message || e));
    result.courses = prev.courses;
    return result;
  }

  for (let i = 0; i < courses.length; i++) {
    const course = courses[i];
    const prevCourse = prev.courses[course.id];
    onProgress({ index: i, total: courses.length, course });

    if (result.status === 'login-required' || result.status === 'stopped') {
      // Keep what we had; never treat an unscanned course as emptied.
      if (prevCourse) result.courses[course.id] = prevCourse;
      continue;
    }

    const choice = courseChoice(course.id);
    if (choice === 'off') { if (prevCourse) result.courses[course.id] = prevCourse; continue; }

    try {
      if (shouldStop()) throw new Stopped();
      if (choice === 'pending') {
        const state = await client.courseState(course.id);
        const toOpen = state.cms.filter(cm => RESOLVABLE.has(cm.kind) && cm.visible).length;
        result.plan.push({ id: course.id, name: course.name, short: course.short, category: course.category, items: state.cms.length, toOpen });
        if (prevCourse) result.courses[course.id] = prevCourse;
        continue;
      }
      const next = await scanCourse(client, course, prevCourse, { now, academicYearStart, semesterStart, shouldStop, serverTime: result.serverTime });
      result.opened += next.opened;
      const events = diffCourse(prevCourse, next).map(ev => ({ ...ev, courseId: course.id, courseName: course.name }));
      result.events.push(...events);
      result.courses[course.id] = mergeCourse(prevCourse, next);
      result.courses[course.id].recordings = next.recordings;
      result.courses[course.id].serverTime = next.serverTime;
    } catch (e) {
      if (e instanceof LoginRequired) {
        result.status = 'login-required';
      } else if (e instanceof Stopped) {
        result.status = 'stopped';
      } else {
        result.errors.push(`${course.name}: ${e.message || e}`);
        if (result.status === 'ok') result.status = 'partial';
      }
      if (prevCourse) result.courses[course.id] = prevCourse;
    }
  }
  return result;
}

export async function scanCourse(client, course, prevCourse, { now, academicYearStart, semesterStart = null, shouldStop = () => false, serverTime = now }) {
  const state = await client.courseState(course.id);
  const prevItems = (prevCourse && prevCourse.items) || {};

  // Silent change report since the last complete scan of this course.
  let changed = new Map();
  if (prevCourse && (prevCourse.serverTime || prevCourse.scannedAt)) {
    changed = await client.updatesSince(course.id, prevCourse.serverTime || prevCourse.scannedAt - 60 * 1000);
  }
  // First scan of a course: which items were touched since the semester began.
  let touchedThisSemester = null;
  const cutoff = currentFrom(course, semesterStart, client.year);
  if (!prevCourse && cutoff) {
    touchedThisSemester = await client.updatesSince(course.id, cutoff);
  }

  const items = {};
  let opened = 0;
  for (const cm of state.cms) {
    const base = {
      cmid: cm.cmid, kind: cm.kind, name: cm.name, url: cm.url,
      sectionId: cm.sectionId, sectionTitle: cm.sectionTitle, visible: cm.visible,
    };
    base.category = guessCategory(base);
    const old = prevItems[cm.cmid];
    base.material = decideMaterial(base, old, touchedThisSemester, academicYearStart);

    const areas = changed.get(cm.cmid) || [];
    const contentChanged = areas.includes('contentfiles') || areas.includes('configuration');
    // Earlier versions missed files of resources that redirect straight to the file; such items
    // were stored with no files. Open them once more with the current method.
    const missedByOldVersion = old && cm.kind === 'resource' && Array.isArray(old.files) && old.files.length === 0 && (old.resolver || 1) < RESOLVER_VERSION;
    const needsOpen = RESOLVABLE.has(cm.kind) && cm.visible &&
      (!old || old.files === undefined || contentChanged || (!old.visible && cm.visible) || missedByOldVersion);

    if (needsOpen) {
      if (shouldStop()) throw new Stopped();
      await client.pause();
      const info = await client.resolveItem(cm);
      opened++;
      const files = [];
      for (const f of info.files || []) {
        let head = f.head;
        if (!head) { await client.pause(); head = await client.headFile(f.url); }
        if (head.missing) continue;
        const { head: _h, ...file } = f;
        files.push({ ...file, etag: head.etag, size: head.size, mtime: head.mtime, type: head.type });
      }
      items[cm.cmid] = { ...base, files, embeds: info.embeds, target: info.target, text: info.text, resolver: RESOLVER_VERSION };
    } else {
      // Not opened: carry over what we know (files: undefined tells the diff "not checked").
      items[cm.cmid] = { ...base, files: undefined, embeds: old && old.embeds, target: old && old.target, text: old && old.text, resolver: old && old.resolver };
    }
  }

  let recordings = (prevCourse && prevCourse.recordings) || [];
  try { recordings = await client.panoptoRecordings(course.id); } catch (e) { if (e instanceof LoginRequired) throw e; }

  return { complete: true, scannedAt: now, serverTime, items, opened, recordings };
}
