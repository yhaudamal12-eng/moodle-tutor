// Guesses what a course item is, from its name, section and file name.
// Only a first guess: the student can correct it, and a correction is kept across scans.

// "פתרון", "פיתרון", "פתור", "פתרונות" (spellings seen in real HUJI courses), and English.
const SOLUTION = /פי?תרו(?:ן|נות)|פתור|solution|\bsol\b|answers?\b|with\s*solution/i;
const EXAM = /מבחן|מבחנים|בוחן|בחני|מועד\s*['׳]?\s*[אבג]|exam|midterm|quiz/i;

const CATEGORY_RULES = [
  ['exam', EXAM],
  ['assignment', /תרגיל(?!\s*כיתה)|שיעורי\s*בית|ש\.?ב\.?\b|מטלה|מטלות|homework|hw\s*\d|assignment|problem\s*set|\bps\s*\d/i],
  ['tutorial', /תרגול|tirgul|tutorial|recitation/i],
  ['recording', /הקלטה|הקלטות|recording|video/i],
  ['syllabus', /סילבוס|syllabus|תכנון\s*קורס|נושאי\s*הקורס|נושאים\s*ונהלים|נהלי|topics[_\s]*structure|course\s*outline/i],
  ['slides', /מצגת|מצגות|slides?|presentation|\.pptx?$/i],
  ['summary', /סיכו[םמ]|רשימות|lecture\s*notes|notes|summary/i],
  ['lecture', /הרצאה|הרצאות|שיעור|lecture|lesson/i],
];

export function guessCategory({ name = '', sectionTitle = '', kind = '', filename = '' }) {
  if (kind === 'forum') return 'forum';
  const text = `${name} ${filename}`;
  const solved = SOLUTION.test(text);
  if (solved && EXAM.test(text)) return 'exam-solution';
  if (solved) return 'solution';
  if (kind === 'assign') return 'assignment';
  for (const [cat, re] of CATEGORY_RULES) if (re.test(text)) return cat;
  for (const [cat, re] of CATEGORY_RULES) if (re.test(sectionTitle)) return cat;
  return 'other';
}

// Hebrew calendar years as written in course files: תשפ"ו, תשפו, תשפ״ד ...
// Returns the Gregorian year the academic year starts in (תשפ"ו -> 2025).
const GEMATRIA = { א: 1, ב: 2, ג: 3, ד: 4, ה: 5, ו: 6, ז: 7, ח: 8, ט: 9, י: 10, כ: 20, ל: 30, מ: 40, נ: 50, ס: 60, ע: 70, פ: 80, צ: 90, ק: 100, ר: 200, ש: 300, ת: 400 };
export function hebrewYearStart(text) {
  const m = String(text).match(/(?:^|[^֐-׿])(ת[ש-ת][א-ת]?["'״׳]?[א-ט]?)(?=$|[^֐-׿])/);
  if (!m) return null;
  const letters = m[1].replace(/["'״׳]/g, '');
  if (letters.length < 3) return null;
  const value = [...letters].reduce((n, c) => n + (GEMATRIA[c] || 0), 0);
  if (value < 760 || value > 860) return null;      // 5760..5860: years 1999..2100
  return 5000 + value - 3761;
}

// "Support" = reference material the lecturer put up at the start (old exams, past-year notes,
// recordings from earlier years). "Current" = material of this semester.
export function sourceYear(text, academicYearStart) {
  const m = text.match(/(20\d\d)\s*[\/\-]\s*(\d\d)\b/) || text.match(/\b(20\d\d)\b/);
  const y = m ? Number(m[1]) : hebrewYearStart(text);
  if (y === null || y === undefined) return null;
  return y < academicYearStart ? y : null;
}

export function guessMaterial({ name = '', sectionTitle = '', filename = '' }, academicYearStart) {
  const text = `${name} ${filename} ${sectionTitle}`;
  if (sourceYear(text, academicYearStart) !== null) return 'support';
  if (/שנים\s*קודמות|שנה\s*שעברה|previous\s*years?|past\s*exams?|additional\s*material|חומר\s*עזר|חומרי\s*עזר/i.test(text)) return 'support';
  return 'current';
}
