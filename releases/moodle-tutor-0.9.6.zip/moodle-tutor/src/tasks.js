// The task list: Moodle's timeline items (what is due), with the student's own "done" ticks.

const DAY = 86400000;
export const URGENT_MS = 48 * 3600000;

// done: { [taskId]: when ticked }. Items Moodle no longer lists are dropped from "done" too.
export function pruneDone(done, tasks) {
  const ids = new Set(tasks.map(t => t.id));
  return Object.fromEntries(Object.entries(done || {}).filter(([id]) => ids.has(id)));
}

export function urgentCount(tasks, done = {}, now = Date.now()) {
  return tasks.filter(t => !done[t.id] && t.due - now < URGENT_MS).length;
}

function dayStart(ms) { const d = new Date(ms); d.setHours(0, 0, 0, 0); return d.getTime(); }

// Groups for the list: overdue, today, the next 7 days, later; done ones apart.
export function groupTasks(tasks, done = {}, now = Date.now()) {
  const g = { overdue: [], today: [], week: [], later: [], done: [] };
  const today = dayStart(now);
  for (const t of [...tasks].sort((a, b) => a.due - b.due)) {
    if (done[t.id]) g.done.push(t);
    else if (t.due < now) g.overdue.push(t);
    else if (t.due < today + DAY) g.today.push(t);
    else if (t.due < today + 8 * DAY) g.week.push(t);
    else g.later.push(t);
  }
  return g;
}

// "בעוד 3 שעות", "מחר ב־23:59", "בעוד 5 ימים", "באיחור של יומיים".
export function dueText(due, now = Date.now()) {
  const time = new Date(due).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' });
  const days = Math.round((dayStart(due) - dayStart(now)) / DAY);
  if (due < now) {
    const late = Math.floor((now - due) / DAY);
    return late < 1 ? 'עבר המועד היום' : late === 1 ? 'באיחור של יום' : late === 2 ? 'באיחור של יומיים' : `באיחור של ${late} ימים`;
  }
  if (days === 0) { const h = Math.max(1, Math.round((due - now) / 3600000)); return h <= 6 ? `בעוד ${h === 1 ? 'שעה' : `${h} שעות`}` : `היום ב־${time}`; }
  if (days === 1) return `מחר ב־${time}`;
  if (days === 2) return `מחרתיים ב־${time}`;
  return `בעוד ${days} ימים`;
}
