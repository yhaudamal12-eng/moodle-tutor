// Claude's web app, as the claude.ai page itself talks to it (checked 15.10.2026).
// send(msg) delivers a message to the proxy inside a claude.ai tab.

export class ClaudeLoginRequired extends Error { constructor() { super('claude-login'); } }
export class ClaudeError extends Error {
  constructor(what, status, body) { super(`${what}: ${status} ${String(body || '').slice(0, 200)}`); this.status = status; }
}

export class ClaudeProjects {
  constructor(send) { this.send = send; this.org = null; }

  async call(method, path, json) {
    const r = await this.send({ type: 'claude-fetch', method, path, json });
    if (!r || r.error) throw new ClaudeError(path, 0, r && r.error);
    if (r.status === 401 || r.status === 403) throw new ClaudeLoginRequired();
    if (r.status < 200 || r.status >= 300) throw new ClaudeError(`${method} ${path.replace(/[0-9a-f-]{36}/g, '…')}`, r.status, r.body);
    try { return r.body ? JSON.parse(r.body) : null; } catch { return r.body; }
  }

  async orgId() {
    if (this.org) return this.org;
    const orgs = await this.call('GET', '/api/organizations');
    const o = (orgs || []).find(x => (x.capabilities || []).includes('chat')) || (orgs || [])[0];
    if (!o) throw new ClaudeLoginRequired();
    this.org = o.uuid;
    return this.org;
  }
  async base(projectId) { return `/api/organizations/${await this.orgId()}/projects${projectId ? '/' + projectId : ''}`; }

  async listProjects() { return this.call('GET', await this.base()); }
  async getProject(id) { return this.call('GET', await this.base(id)); }
  async createProject(name, description) { return this.call('POST', await this.base(), { name, description, is_private: true }); }
  async setInstructions(id, text) { return this.call('PUT', await this.base(id), { prompt_template: text }); }
  async listFiles(id) { return this.call('GET', `${await this.base(id)}/files`); }
  async listDocs(id) { return this.call('GET', `${await this.base(id)}/docs`); }
  async createDoc(id, name, content) { return this.call('POST', `${await this.base(id)}/docs`, { file_name: name, content }); }
  async updateDoc(id, docId, name, content) { return this.call('PATCH', `${await this.base(id)}/docs/${docId}`, { file_name: name, content }); }
  async upload(id, name, mime, b64) {
    const r = await this.send({ type: 'claude-upload', path: `${await this.base(id)}/upload`, name, mime, b64 });
    if (!r || r.error) throw new ClaudeError('upload', 0, r && r.error);
    if (r.status === 401 || r.status === 403) throw new ClaudeLoginRequired();
    let j = null; try { j = JSON.parse(r.body); } catch { /* not json */ }
    if (r.status < 200 || r.status >= 300 || !j || j.success === false) throw new ClaudeError('upload', r.status, r.body);
    return j;
  }
  async conversations(id, limit = 20) {
    const j = await this.call('GET', `${await this.base(id)}/conversations_v2?limit=${limit}&offset=0`);
    return (j && j.data) || (Array.isArray(j) ? j : []);
  }
  async conversation(convId) {
    return this.call('GET', `/api/organizations/${await this.orgId()}/chat_conversations/${convId}?tree=True&rendering_mode=messages&render_all_tools=true`);
  }
}

// The text of a message, from either of the two shapes Claude returns.
export function messageText(m) {
  if (!m) return '';
  if (m.text) return m.text;
  return (m.content || []).filter(c => c.type === 'text').map(c => c.text || '').join('\n');
}
