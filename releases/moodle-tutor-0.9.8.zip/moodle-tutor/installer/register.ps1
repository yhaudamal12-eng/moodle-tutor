# Registers the updater with Chrome for the current Windows user (no administrator rights needed).
# Run by install.ps1 after the extension's files are in place. -HostsDir is for tests on Linux.
param([Parameter(Mandatory = $true)][string]$ExtensionDir, [string]$HostsDir = '', [string]$Shell = '')
$ErrorActionPreference = 'Stop'
$Name = 'com.moodle_tutor.updater'
$Id = 'inkfcoaabennkdaopkkdpklojandmppo'          # fixed by the "key" in manifest.json
$updater = Join-Path (Join-Path $ExtensionDir 'installer') 'updater.ps1'
$utf8 = New-Object Text.UTF8Encoding $false

# The updater lives in its own folder with a note of where the extension is. The launcher refers to it
# by its own location (%~dp0), so no path is written into it: Hebrew folder names (OneDrive Documents in Hebrew, a
# Hebrew user name) stay out of the batch file, which cannot hold them.
if ($HostsDir) { $home2 = $HostsDir } else { $home2 = Join-Path $env:LOCALAPPDATA 'MoodleTutor' }
New-Item -ItemType Directory -Force -Path $home2 | Out-Null
Copy-Item -LiteralPath $updater -Destination (Join-Path $home2 'updater.ps1') -Force
[IO.File]::WriteAllText((Join-Path $home2 'config.json'), (@{ extDir = $ExtensionDir } | ConvertTo-Json), $utf8)
if ($HostsDir) {
  # Linux / tests: a shell launcher.
  $launcher = Join-Path $home2 "$Name.sh"
  [IO.File]::WriteAllText($launcher, "#!/bin/sh`nexec `"$Shell`" -NoProfile -File `"`$(dirname `"`$0`")/updater.ps1`"`n", $utf8)
  chmod +x $launcher
} else {
  $launcher = Join-Path $home2 'updater.cmd'
  [IO.File]::WriteAllText($launcher, "@echo off`r`npowershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0updater.ps1`"`r`n", (New-Object Text.ASCIIEncoding))
}
$manifestPath = Join-Path $home2 "$Name.json"
$hostManifest = @{ name = $Name; description = 'Moodle Tutor updater'; path = $launcher; type = 'stdio'; allowed_origins = @("chrome-extension://$Id/") }
# UTF-8 without a byte-order mark: Chrome reads this file strictly.
[IO.File]::WriteAllText($manifestPath, ($hostManifest | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
if (-not $HostsDir) {
  $key = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$Name"
  New-Item -Path $key -Force | Out-Null
  Set-ItemProperty -Path $key -Name '(default)' -Value $manifestPath
}
Write-Host "Updater registered: $manifestPath"
