# Moodle Tutor updater: a Chrome "native messaging" host. Chrome starts it when the extension asks
# for an update; it reads one message, replaces the extension's files with the new version, answers, ends.
# It accepts downloads only from the extension's own public repository.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Repo = 'https://raw.githubusercontent.com/yhaudamal12-eng/moodle-tutor/main/'
$UpdaterVersion = '1'
# Where the extension is: noted at install time next to this file (or, in the old layout, this file's parent).
$cfg = Join-Path $PSScriptRoot 'config.json'
if (Test-Path -LiteralPath $cfg) { $ExtDir = (Get-Content -Raw -Encoding UTF8 -LiteralPath $cfg | ConvertFrom-Json).extDir }
else { $ExtDir = Split-Path -Parent $PSScriptRoot }

function Read-Message {
  $in = [Console]::OpenStandardInput()
  $head = New-Object byte[] 4
  $n = 0; while ($n -lt 4) { $r = $in.Read($head, $n, 4 - $n); if ($r -le 0) { return $null }; $n += $r }
  $len = [BitConverter]::ToInt32($head, 0)
  $buf = New-Object byte[] $len
  $n = 0; while ($n -lt $len) { $r = $in.Read($buf, $n, $len - $n); if ($r -le 0) { break }; $n += $r }
  return ([Text.Encoding]::UTF8.GetString($buf, 0, $n) | ConvertFrom-Json)
}

function Send-Message($obj) {
  $bytes = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress))
  $out = [Console]::OpenStandardOutput()
  $out.Write([BitConverter]::GetBytes([int]$bytes.Length), 0, 4)
  $out.Write($bytes, 0, $bytes.Length)
  $out.Flush()
}

try {
  $msg = Read-Message
  if (-not $msg) { exit 0 }
  if ($msg.action -eq 'ping') { Send-Message @{ ok = $true; updater = $UpdaterVersion; dir = $ExtDir }; exit 0 }
  if ($msg.action -ne 'update') { Send-Message @{ ok = $false; error = 'unknown action' }; exit 0 }
  $url = [string]$msg.url
  if (-not $url.StartsWith($Repo) -or -not $url.EndsWith('.zip') -or $url.Contains('..')) { Send-Message @{ ok = $false; error = 'bad url' }; exit 0 }

  $work = Join-Path ([IO.Path]::GetTempPath()) ('moodle-tutor-update-' + [Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $work | Out-Null
  $zip = Join-Path $work 'update.zip'
  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
  $unpacked = Join-Path $work 'x'
  Expand-Archive -Path $zip -DestinationPath $unpacked -Force
  $src = Join-Path $unpacked 'moodle-tutor'
  if (-not (Test-Path (Join-Path $src 'manifest.json'))) { Send-Message @{ ok = $false; error = 'not an extension zip' }; exit 0 }
  # Copy over the extension's own folder, wherever it is installed. Files are replaced, nothing is deleted.
  # File by file, so PowerShell 5 and 7 behave the same (no nested folders).
  $root = (Resolve-Path $src).Path
  foreach ($f in Get-ChildItem -Path $root -Recurse -File) {
    $rel = $f.FullName.Substring($root.Length).TrimStart('\', '/')
    $dest = Join-Path $ExtDir $rel
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest) | Out-Null
    Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
  }
  $version = (Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $ExtDir 'manifest.json') | ConvertFrom-Json).version
  # Keep this updater current too: the new version may bring a newer one.
  $fresh = Join-Path (Join-Path $ExtDir 'installer') 'updater.ps1'
  if ((Test-Path -LiteralPath $fresh) -and ((Resolve-Path -LiteralPath $fresh).Path -ne $PSCommandPath)) { Copy-Item -LiteralPath $fresh -Destination $PSCommandPath -Force -ErrorAction SilentlyContinue }
  Remove-Item -Recurse -Force $work -ErrorAction SilentlyContinue
  Send-Message @{ ok = $true; version = $version }
} catch {
  Send-Message @{ ok = $false; error = $_.Exception.Message }
}
