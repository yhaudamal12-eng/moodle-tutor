import { extractCommand } from '../src/update.js';
import { departmentFolder } from '../src/files.js';
import { semesterOf, SEMESTER_ORDER } from '../src/semester.js';
import { groupTasks, dueText } from '../src/tasks.js';
import { S } from './strings.js';
import { KNOWN, siteFrom, changesYearly } from '../src/sites.js';

const $ = s => document.querySelector(s);
const send = msg => chrome.runtime.sendMessage(msg);

const HIDE_KINDS = new Set(['attendance', 'label']);
// The chats a course tutor can live in. "thing" is what the chat calls a course space.
const CHATS = [
  { id: 'claude', label: 'Claude', thing: 'פרויקט', origin: 'https://claude.ai/*', url: id => `https://claude.ai/project/${id}` },
  // The notebook opens in the Gemini app (a new conversation for every question), in the Google account
  // the extension found it in (often not the first account in Chrome). The app is reached for reading too.
  { id: 'gemini', label: 'Gemini', thing: 'מחברת', origin: 'https://notebook.google.com/*', origins: ['https://notebook.google.com/*', 'https://gemini.google.com/*'],
    url: id => { const a = ui.st && ui.st.accounts && ui.st.accounts.gemini; return `https://gemini.google.com/${a && a !== '0' ? `u/${a}/` : ''}notebook/${id}`; } },
  { id: 'chatgpt', label: 'ChatGPT', thing: 'פרויקט', origin: 'https://chatgpt.com/*', url: id => `https://chatgpt.com/g/${id}/project` },
];

// Wrap any text that may start with Latin letters so a Hebrew line never flips direction.
const bidi = s => { const b = document.createElement('bdi'); b.textContent = s; return b; };
const el = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) k === 'class' ? (e.className = v) : e.setAttribute(k, v);
  for (const k of kids) if (k !== '' && k != null && k !== false) e.append(k);
  return e;
};
const button = (text, cls, onClick) => { const b = el('button', cls ? { class: cls } : {}, text); if (onClick) b.onclick = onClick; return b; };
const when = ms => ms ? new Date(ms).toLocaleString('he-IL', { day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
const rl = p => `${p.label}\u200F`;   // an English name inside a Hebrew sentence
const courseLabel = c => (c.short ? c.short.replace(/^\d+(_\d+)?-/, '') : c.name);
const store = { get: k => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* private window */ } } };

const ui = { open: new Set(), notes: {}, linking: {}, sem: store.get('sem'), tab: store.get('tab'), granted: {}, showDone: false, st: null };
let planChoices = {};

// ---------- Static texts ----------
for (const e of document.querySelectorAll('[data-s]')) e.textContent = S[e.dataset.s];
for (const e of document.querySelectorAll('[data-s-aria]')) { e.setAttribute('aria-label', S[e.dataset.sAria]); e.title = S[e.dataset.sAria]; }
for (const [v, t] of Object.entries(S.every)) $('#scanEveryHours').append(el('option', { value: v }, t));
$('#help-body').replaceChildren(...S.helpSections.map(([h, lines]) => el('section', {}, el('h3', {}, h),
  el('ul', { class: Array.isArray(lines[0]) ? 'faq' : '' }, ...lines.map(l => Array.isArray(l) ? el('li', {}, el('strong', {}, l[0]), el('span', { class: 'answer' }, l[1])) : el('li', {}, l))))));

// ---------- Tabs ----------
function showTab(name) {
  ui.tab = name; store.set('tab', name);
  for (const b of document.querySelectorAll('.tabs [role="tab"]')) b.setAttribute('aria-selected', String(b.dataset.tab === name));
  for (const t of document.querySelectorAll('.tab')) t.hidden = t.id !== `tab-${name}`;
}
for (const b of document.querySelectorAll('.tabs [role="tab"]')) b.onclick = () => showTab(b.dataset.tab);

// ---------- Help ----------
const help = $('#help');
$('#help-btn').onclick = () => help.showModal();
$('#help-close').onclick = () => help.close();
help.addEventListener('close', () => send({ type: 'help-seen' }));

// ---------- Consent ----------
// Shown once, before anything else: the panel stays behind it until the student accepts.
$('#consent-items').append(...S.consentItems.map(([q, a], i) => el('div', {}, el('dt', {}, q), el('dd', {}, a,
  ...(i === S.consentItems.length - 1 ? [el('span', { class: 'consent-links' }, ...S.consentLinks.map(([name, url]) => button(name, 'link', () => chrome.tabs.create({ url }))))] : [])))));
$('#consent-check').onchange = e => { $('#consent-go').disabled = !e.target.checked; };
$('#consent-go').onclick = async () => { await send({ type: 'consent' }); render(); };

// ---------- Render ----------
async function render() {
  const st = await send({ type: 'state' });
  if (!st || st.error) { $('#statusline').textContent = S.noReply; return; }
  ui.st = st;
  document.body.classList.toggle('gate', !st.consent);
  $('#consent').hidden = !!st.consent;
  if (!st.consent) return;
  for (const c of CHATS) ui.granted[c.id] = await chrome.permissions.contains({ origins: c.origins || [c.origin] }).catch(() => false);
  const { snapshot, status } = st;
  const scanning = status && status.state === 'scanning';
  renderHeader(st, scanning);
  renderBanners(st);
  const plan = (status && status.plan) || [];
  const fresh = !snapshot && !plan.length && !scanning;
  $('#onboard').hidden = !fresh && !!st.settings.chats;
  $('#onboard .steps').hidden = !fresh;
  renderChatChips($('#ob-chats'), st.settings);
  for (const box of document.querySelectorAll('[data-site-picker]')) if (!box.contains(document.activeElement)) renderSitePicker(box, st);
  renderPlan(plan, scanning);
  // Do not rebuild a list under the student's hands while they edit in it.
  const a = document.activeElement;
  const editing = box => a && box.contains(a) && /^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName);
  renderTutors(st);
  renderTasks(st);
  renderNew(st);
  if (!editing($('#courses'))) renderCourses(st);
  renderSettings(st);
  // First visit: the explanation. Later: the tutors, once there is anything to show.
  if (!ui.tab) ui.tab = snapshot ? 'tutors' : 'courses';
  showTab(ui.tab);
  if (!st.helpSeen && !help.open && !ui.helpShown) { ui.helpShown = true; help.showModal(); }
}

function renderHeader({ snapshot, status, year, downloads }, scanning) {
  let line = S.year(year) + ' · ';
  if (scanning) line += S.scanning(status.progress);
  else if (snapshot && snapshot.scannedAt) line += S.lastScan(when(snapshot.scannedAt));
  else line += S.notScanned;
  $('#statusline').textContent = line;
  const dl = downloads || {};
  const parts = [];
  if (dl.waiting) parts.push(S.dlWaiting(dl.waiting));
  if (dl.paused && dl.waiting) parts.push(S.dlPaused);
  $('#dlline').textContent = parts.join(' · ');
  $('#scan').disabled = scanning;
  $('#stop').hidden = !(scanning || (dl.waiting && !dl.paused && !dl.blocked));
}

function renderBanners({ status, downloads, year, settings }) {
  const box = $('#banners'); box.replaceChildren();
  const banner = (cls, text, actions = [], detail) => {
    const b = el('div', { class: `banner ${cls}` }, el('div', {}, text));
    if (actions.length) b.append(el('div', { class: 'actions' }, ...actions));
    if (detail) b.append(el('details', { class: 'detail' }, el('summary', {}, 'פרטים'), bidi(detail)));
    box.append(b);
  };
  const openMoodle = () => button(S.openMoodle, '', () => chrome.tabs.create({ url: `${ui.st.moodleRoot}/my/` }));
  const resume = text => button(text, 'primary', async () => { await send({ type: 'resume-downloads' }); render(); });
  const dl = downloads || {};
  // A newer version: download, put the files in place with one pasted line, reload.
  const up = ui.st && ui.st.update;
  if (up) {
    const u = ui.upd || {};
    const acts = [button(u.path ? S.updDownloadAgain : S.updDownload, u.path ? 'quiet' : 'primary', async () => {
      ui.upd = { busy: true }; render();
      const r = await send({ type: 'update-download' });
      ui.upd = r.ok ? { path: r.path } : { error: S.updFailed }; render();
    })];
    if (u.path) {
      acts.push(button(S.updCopy, 'primary', async () => {
        try { await navigator.clipboard.writeText(extractCommand(u.path)); ui.upd = { ...u, copied: true }; } catch { ui.upd = { ...u, copyFailed: true }; }
        render();
      }));
      acts.push(button(S.updReload, '', async () => {
        // The files on disk tell whether the new version is in place; only then reload.
        const disk = await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' }).then(r => r.json()).catch(() => ({}));
        if (disk.version === up.version) chrome.runtime.reload();
        else { ui.upd = { ...u, notReplaced: disk.version || '?' }; render(); }
      }));
    }
    const lines = [u.busy ? S.updBusy : u.error ? u.error : u.notReplaced ? S.updNotReplaced(u.notReplaced) : u.copied ? S.updCopied : u.copyFailed ? S.updCopyFailed : u.path ? S.updSteps : S.updNew(up.version, ui.st.version)];
    banner('info', lines.join(' '), acts, u.path ? extractCommand(u.path) : undefined);
  }
  if (status && status.state === 'login-required') banner('', S.bLogin, [openMoodle()]);
  if (status && status.state === 'error') banner('', S.bError, [openMoodle()], (status.errors || []).join(' · '));
  if (status && status.state === 'stopped') banner('info', S.bStopped);
  if (status && status.state === 'partial') banner('', S.bPartial(status.errors.length), [], status.errors.join(' · '));
  if (dl.blocked === 'ask-where-to-save') banner('', S.bAskSave, [button(S.openDlSettings, '', () => chrome.tabs.create({ url: 'chrome://settings/downloads' })), resume(S.resume)]);
  else if (dl.blocked === 'login-required') banner('', S.bDlLogin(dl.waiting), [openMoodle()]);
  else if (dl.paused && dl.waiting) banner('info', S.bDlPaused(dl.waiting), [resume(S.resumeDl)]);
  if (dl.failed && dl.failed.length) banner('', S.bDlFailed(dl.failed.length), [], dl.failed.map(f => f.filename.split('/').pop()).join(' · '));
  if (status && status.nextYearOpen && !settings.year) banner('info', S.bNextYear(status.nextYear));
}

function renderPlan(plan, scanning) {
  $('#plan').hidden = !plan.length || scanning;
  if (!plan.length) return;
  const list = $('#plan-list'); list.replaceChildren();
  const sorted = [...plan].sort((a, b) => departmentFolder(a).localeCompare(departmentFolder(b), 'he'));
  let lastDept = null;
  const updateSum = () => {
    const on = plan.filter(p => planChoices[p.id] !== 'off');
    $('#plan-sum').textContent = S.planSum(on.length, on.reduce((n, p) => n + p.toOpen, 0));
  };
  for (const p of sorted) {
    if (planChoices[p.id] === undefined) planChoices[p.id] = p.toOpen > 0 ? 'on' : 'off';
    const dept = departmentFolder(p);
    if (dept !== lastDept) { list.append(el('div', { class: 'dept' }, bidi(dept))); lastDept = dept; }
    const cb = el('input', { type: 'checkbox', id: `plan-${p.id}` });
    cb.checked = planChoices[p.id] === 'on';
    cb.onchange = () => { planChoices[p.id] = cb.checked ? 'on' : 'off'; updateSum(); };
    list.append(el('label', { class: 'plan-row', for: `plan-${p.id}` }, cb, el('span', { class: 'nm' }, bidi(courseLabel(p))),
      el('span', { class: 'counts' }, `${semesterOf(p).label} · ${p.toOpen ? S.items(p.toOpen) : S.emptyNow}`)));
  }
  updateSum();
}

// ---------- Which Moodle ----------
const sitePattern = host => /^moodle\d{2}\./.test(host) ? `https://*.${host.replace(/^moodle\d{2}\./, '')}/*` : `https://${host}/*`;

function renderSitePicker(box, st) {
  const cur = st.settings.site;
  const known = KNOWN.find(k => cur ? (k.url && new URL(k.url).host.replace(/^moodle\d{2}\./, '') === cur.host.replace(/^moodle\d{2}\./, '')) : k.id === 'huji');
  const sel = el('select', { 'aria-label': S.whichUni });
  for (const k of KNOWN) sel.append(el('option', { value: k.id }, k.name));
  sel.append(el('option', { value: 'other' }, S.otherUni));
  sel.value = box.dataset.choice || (known ? known.id : 'other');
  const input = el('input', { type: 'url', class: 'wide', placeholder: S.siteUrlPh, dir: 'ltr' });
  const pick = KNOWN.find(k => k.id === sel.value);
  input.value = box.dataset.url || (sel.value === (known && known.id) && cur ? cur.root : (pick && pick.url) || '');
  const msg = el('p', { class: 'hint' }, box.dataset.msg || (cur ? S.siteNow(cur.host) + (changesYearly(cur) ? ` ${S.siteYearly}` : '') : S.siteNow('moodle.huji.ac.il')));
  const go = button(S.connect, 'primary', async () => {
    if (sel.value === 'huji') { await send({ type: 'set-site', site: null }); box.dataset.msg = S.siteOk('moodle.huji.ac.il'); delete box.dataset.choice; render(); return; }
    let u;
    try { u = new URL(/^https?:\/\//.test(input.value.trim()) ? input.value.trim() : `https://${input.value.trim()}`); } catch { msg.textContent = S.siteBadUrl; return; }
    // Chrome asks the student for access to the site; it has to happen right on the click.
    const ok = await chrome.permissions.request({ origins: [sitePattern(u.host)] }).catch(() => false);
    if (!ok) { msg.textContent = S.siteNoAccess; return; }
    msg.textContent = S.connecting;
    const r = await send({ type: 'connect-site', url: u.href });
    if (r && r.ok) {
      await send({ type: 'set-site', site: r.site });
      box.dataset.msg = S.siteOk(r.site.host); delete box.dataset.choice; delete box.dataset.url; render();
    } else msg.textContent = r && r.reason === 'login' ? S.siteLogin : r && r.reason === 'not-moodle' ? S.siteNotMoodle : r && r.reason === 'bad-url' ? S.siteBadUrl : S.siteNoAccess;
  });
  sel.onchange = () => { box.dataset.choice = sel.value; const k = KNOWN.find(x => x.id === sel.value); box.dataset.url = (k && k.url) || ''; delete box.dataset.msg; renderSitePicker(box, st); };
  input.oninput = () => { box.dataset.url = input.value; };
  const showUrl = sel.value !== 'huji';
  box.replaceChildren(el('div', { class: 'row' }, sel, go), showUrl ? input : '', showUrl ? el('p', { class: 'hint' }, S.siteHint) : '', msg,
    cur && box.dataset.sitePicker === 'settings' ? el('p', { class: 'hint' }, S.siteChangeWarn) : '');
}

// ---------- Which chats ----------
const myChats = settings => settings.chats || ['claude'];

function renderChatChips(box, settings) {
  box.replaceChildren();
  const mine = new Set(myChats(settings));
  for (const c of CHATS) {
    const on = mine.has(c.id) && (settings.chats ? true : c.id === 'claude');
    const b = el('button', { class: 'chip', role: 'checkbox', 'aria-checked': String(!!on), 'data-chat': c.id }, bidi(c.label));
    b.onclick = async () => {
      const next = new Set(myChats(settings));
      if (next.has(c.id) && settings.chats) next.delete(c.id);
      else {
        // Chrome asks the student for access to the site; it must happen right on the click.
        if (!ui.granted[c.id]) { const ok = await chrome.permissions.request({ origins: c.origins || [c.origin] }).catch(() => false); if (!ok) return; }
        next.add(c.id);
      }
      await send({ type: 'settings', patch: { chats: CHATS.map(x => x.id).filter(id => next.has(id)) } });
      render();
    };
    box.append(b);
  }
}

// ---------- Semester filter (shared by the tutors and the courses lists) ----------
function semesterFilter(box, courses) {
  box.replaceChildren();
  const sems = new Map();
  for (const c of courses) { const s = semesterOf(c); sems.set(s.key, s.label); }
  if (!ui.sem || (ui.sem !== 'all' && !sems.has(ui.sem))) {
    const m = new Date().getMonth() + 1;
    const nowKey = (m >= 9 || m === 1) ? 'A' : (m >= 2 && m <= 7) ? 'B' : null;
    ui.sem = sems.size > 1 && nowKey && courses.some(c => semesterOf(c).key === nowKey) ? nowKey : 'all';
  }
  if (sems.size > 1) {
    for (const [k, label] of [['all', S.all], ...SEMESTER_ORDER.filter(k => sems.has(k)).map(k => [k, sems.get(k)])]) {
      const b = el('button', { role: 'radio', 'aria-checked': String(ui.sem === k), 'data-sem': k }, label);
      b.onclick = () => { ui.sem = k; store.set('sem', k); render(); };
      box.append(b);
    }
  }
  // A course of "semester A or B" belongs under both.
  return c => { if (sems.size < 2 || ui.sem === 'all') return true; const key = semesterOf(c).key; return key === ui.sem || (key === 'AB' && (ui.sem === 'A' || ui.sem === 'B')); };
}

const scannedCourses = snapshot => snapshot ? (snapshot.courseList || []).filter(c => snapshot.courses && snapshot.courses[c.id]) : [];
const byName = (a, b) => courseLabel(a).localeCompare(courseLabel(b), 'he');

// ---------- Tutors: straight into each course's chat ----------
function renderTutors(st) {
  const { snapshot, projects = {}, tutors = {}, settings } = st;
  const box = $('#tutors'); box.replaceChildren();
  const courses = scannedCourses(snapshot);
  const show = semesterFilter($('[data-filter="tutors"]'), courses);
  if (!courses.length) { box.append(el('p', { class: 'empty' }, S.tutorsEmpty)); return; }
  const chats = CHATS.filter(c => myChats(settings).includes(c.id));
  if (!chats.length) { box.append(el('p', { class: 'empty' }, S.tutorsNoChats)); return; }
  const list = courses.filter(show).sort(byName);
  if (!Object.keys(projects).length) box.append(el('p', { class: 'hint lead' }, S.tutorsNone));
  else {
    // Bring every tutor up to date now: instructions, summaries and new material, without a Moodle scan.
    // The usual refresh mark; it turns while the tutors are being updated.
    const busy = (st.syncing || []).length > 0;
    const r = el('button', { class: `icon refresh${busy ? ' spinning' : ''}`, id: 'refresh-tutors', 'aria-label': S.refreshAll, title: `${S.refreshAll}: ${S.refreshHint}` }, '↻');
    r.onclick = async () => { r.disabled = true; r.classList.add('spinning'); await send({ type: 'project-sync' }); };
    r.disabled = busy;
    box.append(el('div', { class: 'tutors-head' }, el('span', { class: 'hint' }, busy ? S.refreshing : S.refreshAll), r));
  }
  for (const c of list) {
    const projs = projects[c.id] || {};
    const btns = el('span', { class: 'tbtns' });
    for (const ch of chats) {
      const pr = projs[ch.id];
      if (pr && pr.projectId) btns.append(el('a', { class: `chatbtn ${pr.lastError ? 'warn' : ''}`, href: ch.url(pr.projectId), target: '_blank', 'data-chat': ch.id }, bidi(ch.label)));
      else btns.append(button(`+ ${ch.label}`, 'chatbtn ghost', () => { ui.open.add(c.id); ui.sem = 'all'; showTab('courses'); render().then(() => { const d = document.querySelector(`#courses details[data-course="${c.id}"]`); if (d) { d.open = true; d.scrollIntoView({ block: 'start' }); } }); }));
    }
    const last = ((tutors[c.id] || {}).sessions || [])[0];
    box.append(el('div', { class: 'tutor', 'data-course': c.id },
      el('div', { class: 'thead' }, el('span', { class: 'cname' }, bidi(courseLabel(c))), btns),
      last ? el('div', { class: 'tnext' }, S.nextStep, bidi(last.next || '—')) : ''));
  }
}

// ---------- Tasks ----------
function renderTasks({ tasks = [], tasksDone = {}, tasksAt }) {
  const box = $('#tasks'); box.replaceChildren();
  const now = Date.now();
  const g = groupTasks(tasks, tasksDone, now);
  const open = g.overdue.length + g.today.length + g.week.length + g.later.length;
  const urgent = tasks.filter(t => !tasksDone[t.id] && t.due - now < 48 * 3600000).length;
  $('#tasks-count').hidden = !urgent; $('#tasks-count').textContent = String(urgent);
  $('#tasks-at').textContent = tasksAt ? S.tasksUpdated(when(tasksAt)) : '';
  if (!open && !g.done.length) { box.append(el('p', { class: 'empty' }, S.tasksEmpty)); return; }
  const row = (t, isDone) => {
    const cb = el('input', { type: 'checkbox', 'aria-label': isDone ? S.markUndone : S.markDone });
    cb.checked = isDone;
    cb.onchange = async () => { await send({ type: 'task-done', id: t.id, done: cb.checked }); render(); };
    const name = t.url ? el('a', { href: t.url, target: '_blank' }, bidi(t.name)) : bidi(t.name);
    return el('label', { class: `task ${isDone ? 'done' : ''} ${t.due < now && !isDone ? 'late' : ''}`, 'data-task': t.id }, cb,
      el('span', { class: 'tbody' }, el('span', { class: 'tname' }, name), el('span', { class: 'tmeta' }, bidi(t.course || ''), ' · ', dueText(t.due, now))));
  };
  for (const [key, title] of [['overdue', S.tasksOverdue], ['today', S.tasksToday], ['week', S.tasksWeek], ['later', S.tasksLater]]) {
    if (!g[key].length) continue;
    box.append(el('h3', { class: `tgroup ${key}` }, title), ...g[key].map(t => row(t, false)));
  }
  if (!open) box.append(el('p', { class: 'empty' }, S.tasksEmpty));
  if (g.done.length) {
    box.append(button(ui.showDone ? S.hideDone : S.showDone(g.done.length), 'link', () => { ui.showDone = !ui.showDone; render(); }));
    if (ui.showDone) box.append(el('h3', { class: 'tgroup' }, S.tasksDone), ...g.done.map(t => row(t, true)));
  }
}

// ---------- New material ----------
function renderNew({ events, downloads, snapshot }) {
  const dl = downloads || {};
  const fresh = events.filter(e => !e.seen && S.event[e.type]);
  const held = dl.held || [];
  const total = fresh.length + held.length;
  $('#new-count').hidden = !total; $('#new-count').textContent = String(total);
  $('#new-sum').hidden = !total; $('#new-sum').textContent = String(total);
  $('#new-box').hidden = !snapshot;

  $('#held').hidden = !held.length;
  $('#held-list').replaceChildren(...held.slice(0, 100).map(h => {
    const btn = button(S.download, '', async () => { btn.disabled = true; await send({ type: 'release', sigs: [h.sig] }); render(); });
    return el('div', { class: 'plan-row' }, el('span', { class: 'nm' }, bidi(h.name)),
      el('span', { class: 'counts' }, (h.reason === 'video' ? S.video : S.bigFile) + (h.size ? S.mb(Math.round(h.size / 1048576)) : '')), btn);
  }));
  const renamed = dl.renamed || [];
  $('#renamed').hidden = !renamed.length;
  $('#renamed-list').replaceChildren(...renamed.map(r => el('div', { class: 'plan-row' }, el('span', { class: 'nm' }, bidi(r.got)), el('span', { class: 'counts' }, S.instead, bidi(r.wanted)))));

  const list = $('#new-list'); list.replaceChildren();
  $('#seen-all').hidden = !fresh.length;
  if (!fresh.length && !held.length) list.append(el('div', { class: 'empty' }, snapshot ? S.newEmpty : S.newBefore));
  for (const e of fresh.slice(0, 80)) {
    list.append(el('div', { class: 'ev' },
      el('div', {}, el('span', { class: 'nm' }, bidi((e.file ? e.file.filename : e.name) || ''))),
      el('div', { class: 'what' }, `${S.event[e.type]} · `, bidi(e.courseName || ''), e.sectionTitle ? ' · ' : '', e.sectionTitle ? bidi(e.sectionTitle) : '')));
  }
}

// ---------- Courses ----------
function renderCourses(st) {
  const { snapshot, status, events, projects = {}, tutors = {}, syncing = [], settings } = st;
  const box = $('#courses'); box.replaceChildren();
  const courses = scannedCourses(snapshot);
  const show = semesterFilter($('[data-filter="courses"]'), courses);
  const plan = (status && status.plan) || [];
  if (!courses.length) { box.append(el('div', { class: 'empty' }, plan.length ? S.coursesPlan : S.coursesEmpty)); return; }
  const fresh = new Map();
  for (const e of events) if (!e.seen && S.event[e.type]) fresh.set(e.courseId, (fresh.get(e.courseId) || 0) + 1);
  const shown = courses.filter(show).sort((a, b) => departmentFolder(a).localeCompare(departmentFolder(b), 'he') || byName(a, b));
  const chats = CHATS.filter(c => myChats(settings).includes(c.id) || Object.values(projects).some(p => p[c.id]));
  let lastDept = null;
  for (const c of shown) {
    const dept = departmentFolder(c);
    if (dept !== lastDept) { box.append(el('div', { class: 'dept' }, bidi(dept))); lastDept = dept; }
    box.append(courseRow(c, snapshot.courses[c.id], projects[c.id] || {}, tutors[c.id] || {}, syncing, fresh.get(c.id) || 0, st.year, chats));
  }
}

function courseRow(c, cs, projs, t, syncing, freshCount, year, chats) {
  const id = c.id;
  const items = Object.values(cs.items).filter(i => !i.removed && !HIDE_KINDS.has(i.kind) && i.kind !== 'forum');
  const files = items.reduce((n, i) => n + ((i.files || []).length), 0);
  const badges = el('span', { class: 'badges' });
  if (freshCount) badges.append(el('span', { class: 'badge new' }, S.newCount(freshCount)));
  for (const p of CHATS) {
    const pr = projs[p.id];
    if (!pr) continue;
    const busy = syncing.includes(`${p.id}:${id}`);
    badges.append(el('span', { class: `badge ${pr.lastError && !busy ? 'warn' : 'ok'}` }, bidi(p.label), busy ? ` · ${S.syncing}` : pr.lastError ? ` · ${S.needsCare}` : ''));
  }
  const recs = (cs.recordings || []).length;
  const det = el('details', { class: 'course', 'data-course': id },
    el('summary', {}, el('span', { class: 'head' }, el('div', { class: 'cname' }, bidi(courseLabel(c))),
      el('div', { class: 'cmeta' }, `${semesterOf(c).label} · ${S.files(files)}${recs ? ` · ${S.recordings(recs)}` : ''}`)), badges));
  det.open = ui.open.has(id);
  det.ontoggle = () => { det.open ? ui.open.add(id) : ui.open.delete(id); };
  const body = el('div', { class: 'cbody' });
  det.append(body);

  const tb = el('div', { class: 'block' });
  for (const p of chats) tb.append(providerRow(p, id, projs[p.id], syncing.includes(`${p.id}:${id}`)));
  const last = (t.sessions || [])[0];
  const topics = Object.keys(t.topics || {}).length;
  if (last || topics) {
    tb.append(el('div', { class: 'progress' }, el('h4', {}, S.whereWeStopped),
      last ? el('div', {}, S.lastLesson(last.date), bidi(last.learned || '—')) : '',
      last ? el('div', { class: 'next' }, S.nextStep, bidi(last.next || '—')) : '',
      topics ? el('div', { class: 'next' }, S.topics(topics)) : ''));
  } else if (Object.keys(projs).length) tb.append(el('p', { class: 'hint' }, S.endHint));
  body.append(tb);
  body.append(el('div', { class: 'block row-actions' },
    button(S.openFolder, 'quiet', () => send({ type: 'open-folder', courseId: id })),
    el('a', { class: 'textlink', href: `${ui.st.moodleRoot}/course/view.php?id=${id}`, target: '_blank' }, S.inMoodle)));

  // Everything else, folded away.
  const more = el('details', { class: 'inner more' }, el('summary', {}, S.moreOptions));
  more.open = ui.open.has(`${id}:more`);
  more.ontoggle = () => { more.open ? ui.open.add(`${id}:more`) : ui.open.delete(`${id}:more`); };
  more.append(profileBlock(id, t, projs), materialBlock(id, items));
  const unlinks = CHATS.filter(p => projs[p.id]).map(p => unlinkButton(p, id));
  if (unlinks.length) more.append(el('div', { class: 'row-actions' }, ...unlinks));
  body.append(more);
  return det;
}

function providerRow(p, courseId, pr, busy) {
  const row = el('div', { class: 'provider', 'data-provider': p.id });
  const key = `${p.id}:${courseId}`;
  const note = ui.notes[key];
  const btns = el('span', { class: 'pbtns' });
  row.append(el('span', { class: 'pname' }, bidi(p.label)), btns);
  const grant = async () => { const ok = await chrome.permissions.request({ origins: p.origins || [p.origin] }).catch(() => false); if (ok) render(); };
  if (!ui.granted[p.id] && !pr) {
    btns.append(button(S.grant, 'quiet', grant));
    row.append(el('span', { class: 'pstate' }, S.grantHint(rl(p))));
    return row;
  }
  // A tutor made before the extension needed one more site (the Gemini app): ask once, here.
  if (!ui.granted[p.id] && pr) row.append(el('span', { class: 'pstate' }, S.grantMore, ' ', button(S.grant, 'link', grant)));
  const run = async (msg, pendingText) => {
    ui.notes[key] = { cls: 'info', text: pendingText }; render();
    const r = await send(msg);
    ui.notes[key] = resultNote(r, p); render();
  };
  if (!pr) {
    const doCreate = () => run({ type: 'project-create', provider: p.id, courseId }, S.creating(p.thing));
    const prof = ((ui.st.tutors || {})[courseId] || {}).profile || {};
    // The first tutor of a course asks how to teach; later ones (another chat) use the same answer.
    const create = button(S.createThing(p.thing), 'primary', () => { if (prof.style) doCreate(); else { ui.styleFor = key; render(); } });
    const link = button(S.link, 'quiet', async () => {
      ui.linking[key] = { loading: true }; render();
      const r = await send({ type: 'site-projects', provider: p.id });
      ui.linking[key] = r.ok ? { list: r.projects } : { error: resultNote(r, p).text }; render();
    });
    create.disabled = link.disabled = busy;
    btns.append(create, link);
    if (ui.styleFor === key && !prof.style) {
      const pick = style => async () => {
        ui.styleFor = null;
        await send({ type: 'tutor-save', courseId, patch: { profile: { ...prof, style } } });
        doCreate();
      };
      row.append(el('div', { class: 'style-pick' }, el('strong', {}, S.styleQ),
        ...Object.entries(S.styles).map(([id, [label, desc]]) => el('div', { class: 'style-opt' }, button(label, id === 'active' ? 'primary' : '', pick(id)), el('span', { class: 'hint' }, desc))),
        el('p', { class: 'hint' }, S.styleHint)));
    }
    const L = ui.linking[key];
    if (L && L.loading) row.append(el('span', { class: 'pstate' }, S.loading));
    if (L && L.error) row.append(el('span', { class: 'pstate failed' }, L.error));
    if (L && L.list) {
      const sel = el('select', { 'aria-label': S.existingThing(p.thing) });
      sel.append(el('option', { value: '' }, S.chooseThing(p.thing)));
      for (const x of L.list) sel.append(el('option', { value: x.uuid }, x.name));
      const go = button(S.linkGo, '', () => { if (!sel.value) return; delete ui.linking[key]; run({ type: 'project-link', provider: p.id, courseId, projectId: sel.value }, S.linking); });
      row.append(el('span', { class: 'linkrow' }, sel, go));
    }
  } else {
    const sync = button(S.sync, 'quiet', () => run({ type: 'project-sync', provider: p.id, courseId }, S.syncingNow));
    sync.disabled = busy;
    btns.append(el('a', { class: 'btnlink', href: p.url(pr.projectId), target: '_blank' }, S.open), sync);
    const k = pr.counts || {};
    const lines = [];
    if (busy) lines.push(S.syncingNow);
    else if (pr.lastSync) lines.push(S.synced(when(pr.lastSync), k.inProject || 0, p.thing));
    if (k.overflow) lines.push(S.overflow(k.overflow, rl(p)));
    if (k.later) lines.push(S.later(k.later));
    if (k.skipped) lines.push(S.skipped(k.skipped));
    if (k.failed) lines.push(S.failedUp(k.failed));
    if (k.superseded) lines.push(S.superseded(k.superseded, rl(p)));
    for (const l of lines) row.append(el('span', { class: 'pstate' }, l));
    if (pr.lastError && !busy) {
      const text = pr.needsLogin ? S.needLogin(rl(p)) : pr.missing ? S.missingThing(p.thing, rl(p)) : S.syncFailed;
      row.append(el('div', { class: 'note banner' }, el('div', {}, text), !pr.needsLogin && !pr.missing ? el('details', { class: 'detail' }, el('summary', {}, 'פרטים'), bidi(String(pr.lastError).slice(0, 200))) : ''));
    }
  }
  if (note) row.append(el('div', { class: `note banner ${note.cls || ''}` }, el('div', {}, note.text)));
  return row;
}

function unlinkButton(p, courseId) {
  const key = `${p.id}:${courseId}`;
  const un = button(S.unlink(rl(p)), 'link', async () => {
    if (un.dataset.armed) { await send({ type: 'project-unlink', provider: p.id, courseId }); ui.notes[key] = { cls: 'info', text: S.unlinked(p.thing, rl(p)) }; render(); return; }
    un.dataset.armed = '1'; un.textContent = S.unlinkConfirm(p.thing);
    setTimeout(() => { delete un.dataset.armed; un.textContent = S.unlink(rl(p)); }, 5000);
  });
  return un;
}

function resultNote(r, p) {
  if (r && r.ok) {
    const parts = [];
    if (r.uploaded) parts.push(S.uploadedN(r.uploaded));
    if (r.failed) parts.push(S.failedN(r.failed));
    if (r.newSummaries) parts.push(S.summariesN(r.newSummaries));
    return { cls: 'info', text: S.done(parts) };
  }
  const reason = r && r.reason;
  return { cls: '', text: reason === 'site-login' ? S.rLogin(rl(p)) : reason === 'no-permission' ? S.rPerm(rl(p))
    : reason === 'no-site-tab' ? S.rNoTab(rl(p)) : reason === 'no-account' ? S.rNoAccount : reason === 'project-missing' ? S.rMissing(p.thing, rl(p)) : S.rError(r && r.error) };
}

function profileBlock(id, t, projs) {
  const prof = t.profile || {};
  const pd = el('details', { class: 'inner' }, el('summary', {}, S.aboutCourse));
  pd.open = ui.open.has(`${id}:profile`);
  pd.ontoggle = () => { pd.open ? ui.open.add(`${id}:profile`) : ui.open.delete(`${id}:profile`); };
  pd.append(el('p', { class: 'hint' }, S.aboutHint));
  const sels = {};
  for (const [key, [label, opts]] of Object.entries(S.profile)) {
    const s = el('select', { 'aria-label': label });
    for (const [v, txt] of Object.entries(opts)) s.append(el('option', { value: v }, txt));
    s.value = key === 'style' ? (prof.style || 'active') : key === 'formulaSheet' ? (prof.formulaSheet === true ? 'yes' : prof.formulaSheet === false ? 'no' : '') : (prof[key] || '');
    sels[key] = s;
    pd.append(el('label', { class: 'row' }, label, s));
  }
  const notes = el('textarea', { rows: '2', placeholder: S.notesPh });
  notes.value = prof.notes || '';
  pd.append(el('label', { class: 'col' }, S.notes, notes));
  const msg = el('span', { class: 'hint' });
  const save = button(S.save, '', async () => {
    const v = Object.fromEntries(Object.entries(sels).map(([k, s]) => [k, s.value]));
    const profile = JSON.parse(JSON.stringify({ style: v.style || undefined, kind: v.kind || undefined, examFormat: v.examFormat || undefined, background: v.background || undefined,
      formulaSheet: v.formulaSheet === 'yes' ? true : v.formulaSheet === 'no' ? false : undefined, notes: notes.value.trim() || undefined }));
    await send({ type: 'tutor-save', courseId: id, patch: { profile } });
    msg.textContent = Object.keys(projs).length ? S.savedSync : S.saved;
    for (const p of Object.keys(projs)) send({ type: 'project-sync', provider: p, courseId: id });
  });
  pd.append(el('div', { class: 'row-actions' }, save, msg));
  return pd;
}

function materialBlock(id, items) {
  const md = el('details', { class: 'inner' }, el('summary', {}, S.material(items.length)));
  // Built only when opened: a course can hold a hundred items.
  const fill = () => {
    if (md.dataset.filled) return;
    md.dataset.filled = '1';
    md.append(el('p', { class: 'hint' }, S.materialHint));
    const bySection = new Map();
    for (const i of items) { if (!bySection.has(i.sectionTitle)) bySection.set(i.sectionTitle, []); bySection.get(i.sectionTitle).push(i); }
    for (const [sec, its] of bySection) {
      md.append(el('div', { class: 'sect' }, bidi(sec || S.general)));
      for (const i of its) md.append(itemRow(id, i));
    }
  };
  md.open = ui.open.has(`${id}:material`);
  if (md.open) fill();
  md.ontoggle = () => { md.open ? ui.open.add(`${id}:material`) : ui.open.delete(`${id}:material`); if (md.open) fill(); };
  return md;
}

function itemRow(courseId, i) {
  const cat = el('select', { 'aria-label': 'סוג החומר' });
  for (const [k, v] of Object.entries(S.category)) cat.append(el('option', { value: k }, v));
  cat.value = S.category[i.category] ? i.category : 'other';
  cat.onchange = () => send({ type: 'classify', courseId, cmid: i.cmid, category: cat.value });
  const mat = el('select', { 'aria-label': 'שוטף או עזר' });
  for (const [k, v] of Object.entries(S.materialKind)) mat.append(el('option', { value: k }, v));
  mat.value = i.material || 'current';
  mat.onchange = () => send({ type: 'classify', courseId, cmid: i.cmid, material: mat.value });
  const n = (i.files || []).length;
  return el('div', { class: 'item' }, el('span', { class: 'nm' }, bidi(i.name), n > 1 ? el('span', { class: 'counts' }, ` · ${S.files(n)}`) : ''), cat, mat);
}

// ---------- Settings ----------
function renderSettings({ settings, snapshot }) {
  const setIf = (sel, prop, v) => { const e = $(sel); if (document.activeElement !== e) e[prop] = v; };
  renderChatChips($('#chats'), settings);
  setIf('#scanEveryHours', 'value', String(settings.scanEveryHours));
  setIf('#semesterStart', 'value', settings.semesterStart || '');
  setIf('#saveFiles', 'checked', !!settings.saveFiles);
  setIf('#rootFolder', 'value', settings.rootFolder || 'Moodle');
  setIf('#maxFileMB', 'value', String(settings.maxFileMB ?? 50));
  setIf('#skipVideos', 'checked', settings.skipVideos !== false);
  const choices = $('#choices');
  if (choices.contains(document.activeElement)) return;
  choices.replaceChildren();
  const all = (snapshot && snapshot.courseList) || [];
  if (!all.length) choices.append(el('div', { class: 'empty' }, S.firstScan));
  for (const c of [...all].sort(byName)) {
    const cb = el('input', { type: 'checkbox', id: `choice-${c.id}` });
    cb.checked = settings.courseChoice[c.id] === 'on';
    cb.onchange = () => send({ type: 'settings', patch: { courseChoice: { ...settings.courseChoice, [c.id]: cb.checked ? 'on' : 'off' } } }).then(render);
    choices.append(el('label', { class: 'choice', for: `choice-${c.id}` }, cb, el('span', { class: 'nm' }, bidi(courseLabel(c))), el('span', { class: 'counts' }, semesterOf(c).label)));
  }
}

$('#scan').onclick = () => { $('#scan').disabled = true; send({ type: 'scan' }); setTimeout(render, 300); };
$('#stop').onclick = async () => { await send({ type: 'stop' }); render(); };
$('#approve').onclick = async () => { await send({ type: 'approve', choices: planChoices }); planChoices = {}; setTimeout(render, 300); };
$('#seen-all').onclick = async () => { await send({ type: 'seen' }); render(); };
$('#ob-moodle').onclick = async () => { const st = await send({ type: 'state' }); chrome.tabs.create({ url: `${st.moodleRoot}/my/` }); };
$('#semesterStart').onchange = e => send({ type: 'settings', patch: { semesterStart: e.target.value || null } });
$('#scanEveryHours').onchange = e => send({ type: 'settings', patch: { scanEveryHours: Number(e.target.value) } });
$('#saveFiles').onchange = e => send({ type: 'settings', patch: { saveFiles: e.target.checked } });
$('#rootFolder').onchange = e => send({ type: 'settings', patch: { rootFolder: e.target.value.trim() || 'Moodle' } });
$('#maxFileMB').onchange = e => send({ type: 'settings', patch: { maxFileMB: Math.max(0, Number(e.target.value) || 0) } });
$('#skipVideos').onchange = e => send({ type: 'settings', patch: { skipVideos: e.target.checked } });
$('#release-all').onclick = async () => { await send({ type: 'release', sigs: 'all' }); render(); };

$('#check-missing').onclick = async () => {
  const box = $('#missing-result');
  box.replaceChildren(el('p', { class: 'hint' }, S.checking));
  const { missing = [] } = await send({ type: 'missing-files' });
  if (!missing.length) { box.replaceChildren(el('p', { class: 'hint' }, S.noneMissing)); return; }
  const again = button(S.redownload(missing.length), 'primary', async () => {
    again.disabled = true;
    await send({ type: 'redownload', sigs: missing.map(m => m.sig) });
    box.replaceChildren(el('p', { class: 'hint' }, S.queued));
  });
  box.replaceChildren(el('p', { class: 'hint' }, S.missingN(missing.length)),
    ...missing.slice(0, 30).map(m => el('div', { class: 'plan-row' }, el('span', { class: 'nm' }, bidi(String(m.path || '').split('/').pop())))),
    el('div', { class: 'row-actions' }, again));
};

// Report by mail: the mail app opens with the technical details (no content, no passwords) already
// in it; the full details also go to the clipboard, in case the mail link opens nothing.
$('#diag-mail').onclick = async () => {
  const d = await send({ type: 'diagnostics' });
  const full = JSON.stringify(d, null, 1);
  try { await navigator.clipboard.writeText(full); } catch { /* the mail still carries the short form */ }
  const short = JSON.stringify(d);
  const body = S.mailIntro + (short.length > 1500 ? short.slice(0, 1500) + ' …' : short);
  const url = `mailto:${S.reportTo}?subject=${encodeURIComponent(S.mailSubject(chrome.runtime.getManifest().version))}&body=${encodeURIComponent(body)}`;
  chrome.tabs.create({ url }).catch(() => {});
  $('#diag-result').textContent = S.diagMailed(S.reportTo);
};
$('#diag').onclick = async () => {
  const d = await send({ type: 'diagnostics' });
  try { await navigator.clipboard.writeText(JSON.stringify(d, null, 1)); $('#diag-result').textContent = S.diagCopied; }
  catch { $('#diag-result').textContent = S.diagFailed; }
};

$('#export').onclick = async () => {
  const data = await send({ type: 'export' });
  const a = el('a', { href: URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' })), download: `moodle-tutor-backup-${new Date().toISOString().slice(0, 10)}.json` });
  document.body.append(a); a.click(); a.remove();
  $('#backup-result').textContent = S.backupSaved;
};
$('#import').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  let backup = null;
  try { backup = JSON.parse(await f.text()); } catch { /* not json */ }
  const r = await send({ type: 'import', backup });
  $('#backup-result').textContent = r && r.ok ? S.backupLoaded : S.notBackup;
  e.target.value = ''; render();
};

// Two-step reset: the first click asks, the second within 5 seconds does it.
let resetArmed = null;
$('#reset').onclick = async () => {
  const b = $('#reset');
  if (!resetArmed) {
    b.textContent = S.resetSure;
    resetArmed = setTimeout(() => { resetArmed = null; b.textContent = S.reset; }, 5000);
    return;
  }
  clearTimeout(resetArmed); resetArmed = null; b.textContent = S.reset;
  await send({ type: 'reset' }); planChoices = {}; render();
};

let pendingRender = null;
chrome.storage.onChanged.addListener(() => { clearTimeout(pendingRender); pendingRender = setTimeout(render, 150); });
render();
