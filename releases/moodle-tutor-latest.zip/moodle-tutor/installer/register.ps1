# Registers the updater with Chrome for the current Windows user (no administrator rights needed).
# Run by install.ps1 after the extension's files are in place. -HostsDir is for tests on Linux.
param([Parameter(Mandatory = $true)][string]$ExtensionDir, [string]$HostsDir = '', [string]$Shell = '')
$ErrorActionPreference = 'Stop'
$Name = 'com.moodle_tutor.updater'
$Id = 'inkfcoaabennkdaopkkdpklojandmppo'          # fixed by the "key" in manifest.json
$updater = Join-Path (Join-Path $ExtensionDir 'installer') 'updater.ps1'

if ($HostsDir) {
  # Linux / tests: a shell wrapper next to the host manifest.
  New-Item -ItemType Directory -Force -Path $HostsDir | Out-Null
  $launcher = Join-Path $HostsDir "$Name.sh"
  Set-Content -Path $launcher -Value "#!/bin/sh`nexec `"$Shell`" -NoProfile -File `"$updater`"`n" -Encoding ascii
  chmod +x $launcher
  $manifestPath = Join-Path $HostsDir "$Name.json"
} else {
  $home2 = Join-Path $env:LOCALAPPDATA 'MoodleTutor'
  New-Item -ItemType Directory -Force -Path $home2 | Out-Null
  $launcher = Join-Path $home2 'updater.cmd'
  Set-Content -Path $launcher -Value "@echo off`r`npowershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$updater`"`r`n" -Encoding ascii
  $manifestPath = Join-Path $home2 "$Name.json"
}
$hostManifest = @{ name = $Name; description = 'Moodle Tutor updater'; path = $launcher; type = 'stdio'; allowed_origins = @("chrome-extension://$Id/") }
# UTF-8 without a byte-order mark: Chrome reads this file strictly.
[IO.File]::WriteAllText($manifestPath, ($hostManifest | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
if (-not $HostsDir) {
  $key = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$Name"
  New-Item -Path $key -Force | Out-Null
  Set-ItemProperty -Path $key -Name '(default)' -Value $manifestPath
}
Write-Host "Updater registered: $manifestPath"
