// Service worker: schedules scans, stores the snapshot, saves new files, answers the side panel.

import { MoodleClient, academicYearFor, nextYear } from './moodle.js';
import { scanAll } from './scanner.js';
import { DownloadQueue } from './queue.js';
import { downloadPath, fallbackPath, courseDir } from './files.js';
import { makeTabFetch } from './tabfetch.js';
import { siteFrom, rootFor, tabPattern, changesYearly } from './sites.js';
import { urgentCount, pruneDone } from './tasks.js';
import { parseSummary, applySummary, parsePrefs, prefsToProfile } from './session.js';
import { readAppSummaries } from './providers.js';
import { LATEST_URL, pickUpdate } from './update.js';
import { planSync, recordUploads, courseMap, projectInstructions, updateInstructions, progressDoc, MAP_NAME, PROGRESS_NAME, MAX_FILE_BYTES } from './project.js';
import { PROVIDERS, adapterFor, LoginRequired, ProjectMissing } from './providers.js';

// Requests go out from inside a Moodle tab, where the student's login always applies.
// Uses an open Moodle tab if there is one; otherwise opens one in the background and closes it after.
async function moodleTab(year, site = null) {
  if (site === null) site = (await settings()).site || null;
  const root = rootFor(site, year);
  const origin = new URL(root).origin;
  const open = (await chrome.tabs.query({ url: tabPattern(site) })).filter(t => t.url && t.url.startsWith(origin));
  let tab = open.find(t => t.status === 'complete') || open[0];
  let opened = false;
  if (!tab) {
    tab = await chrome.tabs.create({ url: `${root}/my/`, active: false });
    opened = true;
    tab = await waitForLoad(tab.id);
  }
  if (!tab || !tab.url || !tab.url.startsWith(origin)) {
    // The tab ended up on the university login page: not logged in.
    if (opened && tab) await chrome.tabs.remove(tab.id).catch(() => {});
    return { loginNeeded: true };
  }
  if (!(await ping(tab.id))) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['src/content.js'] }); } catch { /* no access yet */ }
    if (!(await ping(tab.id))) { if (opened) chrome.tabs.remove(tab.id).catch(() => {}); throw new Error('לא ניתן להתחבר ללשונית המודל'); }
  }
  const send = msg => chrome.tabs.sendMessage(tab.id, msg);
  return { tabId: tab.id, fetchImpl: makeTabFetch(send), close: opened ? () => chrome.tabs.remove(tab.id).catch(() => {}) : () => {} };
}

// Connects another university's Moodle: opens the address the student gave, and reads the site's
// own address from the page (Moodle keeps it in M.cfg.wwwroot). Not logged in: the tab stays open.
async function connectSite(url) {
  let u;
  try { u = new URL(/^https?:\/\//.test(url) ? url : `https://${url}`); } catch { return { ok: false, reason: 'bad-url' }; }
  const tab = await chrome.tabs.create({ url: u.href, active: false });
  const done = await waitForLoad(tab.id);
  let cfg = null;
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN',
      func: () => (window.M && M.cfg ? { wwwroot: M.cfg.wwwroot, sesskey: !!M.cfg.sesskey, loggedIn: !!document.querySelector('.usermenu .userbutton, #user-menu-toggle, [data-region="user-menu"]') } : null) });
    cfg = r && r.result;
  } catch (e) { return { ok: false, reason: 'no-access', error: String(e.message || e), tabId: tab.id }; }
  if (!cfg || !cfg.wwwroot) {
    // A sign-in page, or not a Moodle site at all.
    chrome.tabs.update(tab.id, { active: true });
    return { ok: false, reason: done && done.url && !done.url.startsWith(u.origin) ? 'login' : 'not-moodle', tabId: tab.id };
  }
  const site = siteFrom(cfg.wwwroot);
  if (!cfg.sesskey || !cfg.loggedIn) { chrome.tabs.update(tab.id, { active: true }); return { ok: false, reason: 'login', site, tabId: tab.id }; }
  chrome.tabs.remove(tab.id).catch(() => {});
  return { ok: true, site };
}

async function setSite(site) {
  const s = await settings();
  const same = JSON.stringify(s.site || null) === JSON.stringify(site || null);
  await set({ settings: { ...s, site: site || null, courseChoice: same ? s.courseChoice : {} } });
  if (!same) {
    // Another university: what was scanned belongs to the old site.
    await queue.reset();
    const all = await chrome.storage.local.get(null);
    await chrome.storage.local.remove(Object.keys(all).filter(k => k.startsWith('snapshot:') || k.startsWith('events:') || k.startsWith('tasks:') || k === 'status'));
  }
  await updateBadge();
  return { ok: true };
}

async function ping(tabId) {
  try { const r = await chrome.tabs.sendMessage(tabId, { type: 'proxy-ping' }); return !!(r && r.pong); }
  catch { return false; }
}

function waitForLoad(tabId, timeoutMs = 30000) {
  return new Promise(resolve => {
    const done = async () => { chrome.tabs.onUpdated.removeListener(listener); clearTimeout(timer); resolve(await chrome.tabs.get(tabId).catch(() => null)); };
    const listener = (id, info) => { if (id === tabId && info.status === 'complete') done(); };
    const timer = setTimeout(done, timeoutMs);
    chrome.tabs.onUpdated.addListener(listener);
  });
}

const DEFAULTS = {
  year: null,                    // null = follow the calendar
  semesterStart: null,           // null = from each course's start date in Moodle; a date set by hand wins
  scanEveryHours: 3,
  saveFiles: true,               // save new and changed files under Downloads/Moodle/...
  maxFileMB: 50,                 // larger files wait for an explicit OK
  skipVideos: true,              // videos wait for an explicit OK
  courseChoice: {},              // courseId -> 'on' | 'off'; missing = not decided yet
  lang: 'he',                    // the tutor's language
  chats: null,                   // the chats the student has: ['claude', 'gemini', 'chatgpt']; null = not asked yet
  rootFolder: 'Moodle',          // top folder under Downloads
  site: null,                    // another university's Moodle ({root, origin, host, style, base}); null = the Hebrew University
};
const MAX_EVENTS = 1000;

const get = keys => chrome.storage.local.get(keys);
const set = obj => chrome.storage.local.set(obj);

async function settings() {
  const { settings: s } = await get('settings');
  return { ...DEFAULTS, ...(s || {}), courseChoice: { ...((s && s.courseChoice) || {}) } };
}
const yearOf = s => s.year || academicYearFor(new Date());

const queue = new DownloadQueue({
  api: {
    download: o => chrome.downloads.download(o),
    search: q => chrome.downloads.search(q),
    cancel: id => chrome.downloads.cancel(id),
    removeFile: id => chrome.downloads.removeFile(id),
    erase: q => chrome.downloads.erase(q),
  },
  store: { load: async () => (await get('dl')).dl || {}, save: st => set({ dl: st }) },
  policy: async () => { const s = await settings(); return { maxBytes: (s.maxFileMB || 0) * 1024 * 1024, skipVideos: !!s.skipVideos }; },
});
chrome.downloads.onChanged.addListener(d => { queue.onChanged(d).then(updateBadge); });
// Every time the extension wakes up, pick up downloads that Chrome dropped (e.g. Chrome was closed mid-download).
queue.startup().catch(() => {});

let running = null;
let stopRequested = false;

// The terms the student accepted in the panel. A new version of the terms asks again.
const CONSENT_VERSION = 1;
const consented = async () => { const { consent } = await get('consent'); return !!consent && consent.v >= CONSENT_VERSION; };

async function runScan(reason = 'manual') {
  if (running) return running;
  // Nothing touches Moodle or a chat before the student has read and accepted the terms.
  if (!(await consented())) return { state: 'needs-consent' };
  stopRequested = false;
  let tab = null;
  running = (async () => {
    const s = await settings();
    const year = yearOf(s);
    const key = `snapshot:${year}`;
    const { [key]: prev, [`events:${year}`]: oldEvents = [] } = await get([key, `events:${year}`]);
    await set({ status: { state: 'scanning', reason, year, startedAt: Date.now() } });

    tab = await moodleTab(year);
    if (tab.loginNeeded) {
      await set({ status: { state: 'login-required', year, finishedAt: Date.now(), errors: [] } });
      await updateBadge();
      return 'login-required';
    }
    const client = new MoodleClient(year, { delayMs: () => 500 + Math.random() * 500, fetchImpl: tab.fetchImpl, site: s.site || null });
    const result = await scanAll(client, prev, {
      now: Date.now(),
      semesterStart: s.semesterStart ? Date.parse(`${s.semesterStart}T00:00:00+03:00`) : null,
      courseChoice: id => s.courseChoice[id] || 'pending',
      shouldStop: () => stopRequested,
      onProgress: p => set({ status: { state: 'scanning', reason, year, progress: `${p.index + 1}/${p.total}`, course: p.course.name } }),
    });

    // A scan that could not even list the courses changes nothing that was stored before.
    const failed = result.status === 'error' || (result.status === 'login-required' && !result.courseList.length);
    const interrupted = result.status === 'login-required' || result.status === 'stopped';
    const snapshot = failed ? (prev || null)
      : { year, scannedAt: interrupted ? (prev && prev.scannedAt) : result.scannedAt, courseList: result.courseList, courses: result.courses };

    // The first scan of a course is its baseline: its items are not "new".
    const known = new Set(Object.keys((prev && prev.courses) || {}));
    const stamped = result.events.map(e => ({ ...slimEvent(e), at: result.scannedAt, seen: !known.has(e.courseId) }));
    const events = [...stamped, ...oldEvents].slice(0, MAX_EVENTS);

    let nextYearOpen = false;
    if (changesYearly(s.site || null)) { try { nextYearOpen = await client.yearExists(nextYear(year)); } catch { /* offline */ } }
    // What is due, for the task list. A failure here never fails the scan.
    if (!failed && result.status !== 'login-required') {
      try {
        const names = new Map((result.courseList || []).map(c => [c.id, c.short ? c.short.replace(/^\d+(_\d+)?-/, '') : c.name]));
        const list = (await client.upcomingDeadlines()).map(t => ({ ...t, course: names.get(t.courseId) || '' }));
        const { tasksDone = {} } = await get('tasksDone');
        await set({ [`tasks:${year}`]: { list, at: Date.now() }, tasksDone: pruneDone(tasksDone, list) });
      } catch (e) { console.warn('tasks', e); }
    }
    tab.close();

    const state = result.status === 'ok' && result.plan.length ? 'awaiting-approval' : result.status;
    await set({
      ...(snapshot ? { [key]: snapshot } : {}),
      [`events:${year}`]: events,
      status: { state, year, finishedAt: Date.now(), opened: result.opened, errors: result.errors, plan: result.plan,
        newEvents: stamped.filter(e => !e.seen).length, nextYearOpen, nextYear: nextYear(year) },
    });

    // A scan the student started by hand also resumes downloads they paused with "stop".
    // Downloads run on their own; the scan never waits for them.
    if (s.saveFiles && !failed) {
      const jobs = filesToSave(year, result, s.rootFolder);
      // A successful scan proves the login works again, so downloads held for a login continue too.
      const go = (reason === 'manual' || reason === 'approved') ? queue.resume().then(() => queue.enqueue(jobs))
        : queue.resumeIfBlockedBy('login-required').then(() => queue.enqueue(jobs));
      go.then(updateBadge).catch(e => console.warn('queue', e));
    }
    await updateBadge();
    // Courses with a Claude project get the new material there too.
    if (!failed && result.status !== 'login-required') syncAllProjects().catch(e => console.warn('projects', e));
    return state;
  })().catch(async e => {
    if (tab && tab.close) tab.close();
    await set({ status: { state: 'error', finishedAt: Date.now(), errors: [String(e && e.message || e)] } });
    await updateBadge();
    return 'error';
  }).finally(() => { running = null; });
  return running;
}

function slimEvent(e) {
  const it = e.item || {};
  return { type: e.type, courseId: e.courseId, courseName: e.courseName, cmid: e.cmid, name: it.name, kind: it.kind, sectionTitle: it.sectionTitle,
    material: it.material, category: it.category, file: e.file ? { filename: e.file.filename, url: e.file.url } : null, from: e.from, to: e.to };
}

function filesToSave(year, result, root) {
  const byId = new Map((result.courseList || []).map(c => [c.id, c]));
  const jobs = [];
  for (const e of result.events) {
    const course = byId.get(e.courseId);
    if (!course) continue;
    let files = [];
    if (e.type === 'added' && e.item.files) files = e.item.files;
    else if ((e.type === 'file-added' || e.type === 'file-updated') && e.file) files = [e.file];
    for (const f of files) {
      jobs.push({ sig: `${f.url}|${f.etag || f.size}`, url: f.url, size: f.size || null, type: f.type || null, fallback: fallbackPath({ year, course, filename: f.filename, root }),
        filename: downloadPath({ year, course, sectionTitle: e.item.sectionTitle, itemName: e.item.name, filename: f.filename, multiFile: (e.item.kind === 'folder'), root }) });
    }
  }
  return jobs;
}

async function updateBadge() {
  const s = await settings();
  const y = yearOf(s);
  const { [`events:${y}`]: events = [], [`tasks:${y}`]: tasks, tasksDone = {}, status, dl } = await get([`events:${y}`, `tasks:${y}`, 'tasksDone', 'status', 'dl']);
  const unseen = events.filter(e => !e.seen && ['added', 'file-added', 'file-updated', 'unlocked'].includes(e.type)).length;
  const urgent = urgentCount((tasks && tasks.list) || [], tasksDone);
  const attention = (status && ['login-required', 'awaiting-approval', 'error'].includes(status.state)) || (dl && dl.blocked);
  // One signal at a time: something needs fixing, then something due within two days, then new material.
  if (attention) {
    await chrome.action.setBadgeText({ text: '!' });
    await chrome.action.setBadgeBackgroundColor({ color: '#a4621a' });
  } else if (urgent) {
    await chrome.action.setBadgeText({ text: String(Math.min(urgent, 99)) });
    await chrome.action.setBadgeBackgroundColor({ color: '#b3261e' });
  } else {
    await chrome.action.setBadgeText({ text: unseen ? String(Math.min(unseen, 99)) : '' });
    await chrome.action.setBadgeBackgroundColor({ color: '#1f6f5c' });
  }
}

// Hebrew instructions in the chat sites' editors: a stylesheet that sets each paragraph's direction by
// its first letter. Registered for the chat sites the student allowed; renewed when that changes.
const RTL_SITES = ['https://claude.ai/*', 'https://chatgpt.com/*', 'https://notebook.google.com/*', 'https://gemini.google.com/*'];
async function registerRtl() {
  try {
    const allowed = [];
    for (const o of RTL_SITES) if (await chrome.permissions.contains({ origins: [o] }).catch(() => false)) allowed.push(o);
    await chrome.scripting.unregisterContentScripts({ ids: ['rtl'] }).catch(() => {});
    if (allowed.length) await chrome.scripting.registerContentScripts([{ id: 'rtl', matches: allowed, css: ['src/rtl.css'], runAt: 'document_start', allFrames: true, persistAcrossSessions: true }]);
  } catch { /* not essential */ }
}
chrome.permissions.onAdded.addListener(registerRtl);
chrome.permissions.onRemoved.addListener(registerRtl);

async function schedule() {
  const s = await settings();
  await chrome.alarms.clear('scan');
  await chrome.alarms.create('scan', { periodInMinutes: Math.max(30, s.scanEveryHours * 60), delayInMinutes: 1 });
  if (!(await chrome.alarms.get('summaries'))) await chrome.alarms.create('summaries', { periodInMinutes: 15 });
  if (!(await chrome.alarms.get('update-check'))) await chrome.alarms.create('update-check', { periodInMinutes: 12 * 60, delayInMinutes: 2 });
}

// A newer published version? Kept in storage for the panel; nothing is downloaded until the student asks.
async function checkUpdate() {
  try {
    const r = await fetch(LATEST_URL, { cache: 'no-store' });
    if (!r.ok) return (await get('update')).update || null;
    const update = pickUpdate(await r.json(), chrome.runtime.getManifest().version);
    await set({ update, updateCheckedAt: Date.now() });
    return update;
  } catch { return (await get('update')).update || null; }
}

// One-click update through the small updater the installer registered (a native messaging host).
// Answers { ok, version } once the new files are on disk; the panel then reloads the extension.
const UPDATER = 'com.moodle_tutor.updater';
async function updaterPresent() {
  try { const r = await chrome.runtime.sendNativeMessage(UPDATER, { action: 'ping' }); return !!(r && r.ok); }
  catch { return false; }
}
async function updateWithUpdater() {
  const { update } = await get('update');
  if (!update) return { ok: false, reason: 'none' };
  let r;
  try { r = await chrome.runtime.sendNativeMessage(UPDATER, { action: 'update', url: update.url, version: update.version }); }
  catch (e) { return { ok: false, reason: 'no-updater', error: String(e && e.message || e) }; }
  if (!r || !r.ok) return { ok: false, reason: 'failed', error: r && r.error };
  return { ok: true, version: r.version };
}

// Downloads the new version's zip and waits for it; answers with where Chrome saved it.
async function downloadUpdate() {
  const { update } = await get('update');
  if (!update) return { ok: false, reason: 'none' };
  let id;
  try { id = await chrome.downloads.download({ url: update.url, filename: 'moodle-tutor-update.zip', conflictAction: 'overwrite', saveAs: false }); }
  catch (e) { return { ok: false, reason: 'error', error: String(e && e.message || e) }; }
  for (let i = 0; i < 240; i++) {
    const [item] = await chrome.downloads.search({ id });
    if (item && item.state === 'complete') return { ok: true, path: item.filename, version: update.version };
    if (item && item.state === 'interrupted') return { ok: false, reason: 'interrupted', error: item.error };
    await new Promise(r => setTimeout(r, 500));
  }
  return { ok: false, reason: 'timeout' };
}

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  await schedule();
  checkUpdate();
  registerRtl();
});
chrome.runtime.onStartup.addListener(async () => { await schedule(); runScan('startup'); checkUpdate(); registerRtl(); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'scan') runScan('scheduled'); if (a.name === 'sync-more') syncAllProjects(); if (a.name === 'summaries') checkSummaries(); if (a.name === 'update-check') checkUpdate(); });

// After the student logs in again, scan right away instead of waiting for the next alarm.
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== 'complete' || !tab.url) return;
  const s = await settings();
  if (!tab.url.startsWith(new URL(rootFor(s.site || null, yearOf(s))).origin)) return;
  const { status } = await get('status');
  if (status && status.state === 'login-required') runScan('after-login');
});

async function resetAll() {
  stopRequested = true;
  await queue.reset();
  const all = await chrome.storage.local.get(null);
  const drop = Object.keys(all).filter(k => k.startsWith('snapshot:') || k.startsWith('events:') || k === 'status' || k === 'saved' || k === 'saveQueue' || k === 'inFlight');
  await chrome.storage.local.remove(drop);
  const s = await settings();
  await set({ settings: { ...s, courseChoice: {} } });
  await updateBadge();
}

// ---------- Course projects in a chat service (Claude projects, Gemini notebooks) ----------

const tutorKey = id => `tutor:${id}`;
const projKey = (provider, id) => `proj:${provider}:${id}`;

async function tutorOf(courseId) { const k = tutorKey(courseId); return (await get(k))[k] || {}; }
async function projOf(provider, courseId) { const k = projKey(provider, courseId); return (await get(k))[k] || null; }

// Version 0.3 kept one Claude project per course under "project:<course>".
async function migrateProjects() {
  const all = await chrome.storage.local.get(null);
  const old = Object.keys(all).filter(k => /^project:\d+$/.test(k));
  if (!old.length) return;
  const out = {};
  for (const k of old) out[projKey('claude', k.slice(8))] = all[k];
  await set(out);
  await chrome.storage.local.remove(old);
}
const migrated = migrateProjects().catch(() => {});

async function courseData(courseId) {
  const s = await settings(); const year = yearOf(s);
  const { [`snapshot:${year}`]: snap } = await get(`snapshot:${year}`);
  const cs = snap && snap.courses && snap.courses[courseId];
  if (!cs) throw new Error('הקורס עוד לא נסרק');
  const meta = (snap.courseList || []).find(c => c.id === courseId) || {};
  return { s, year, course: { ...meta, items: cs.items }, recordings: cs.recordings || [] };
}

async function sendTo(tabId, msg) {
  try { return await chrome.tabs.sendMessage(tabId, msg); } catch (e) { return { error: String(e && e.message || e) }; }
}

// A tab of the chat site to talk through: an open one, or one opened in the background and closed after.
// A site that works in only some of the Google accounts in Chrome (notebooks: personal accounts only).
// Try the account that worked last, then accounts 0 to 4, until the site itself opens rather than a
// "service not allowed" page or a sign-in page. The one that worked is remembered.
const accountKey = meta => `account:${meta.id}`;
async function rememberAccount(meta, account) {
  const k = accountKey(meta);
  if ((await get(k))[k] !== String(account)) await set({ [k]: String(account) });
}
async function openWithAccount(meta) {
  const known = (await get(accountKey(meta)))[accountKey(meta)];
  const order = [...new Set([known, '0', '1', '2', '3', '4'].filter(x => x != null))];
  const host = new URL(meta.home).host;
  let tab = null;
  for (const n of order) {
    const url = `${meta.home}?authuser=${n}`;
    tab = tab ? await chrome.tabs.update(tab.id, { url }).catch(() => null) : await chrome.tabs.create({ url, active: false });
    if (!tab) break;
    tab = await waitForLoad(tab.id);
    if (!tab) break;
    let at = ''; try { at = new URL(tab.url).host; } catch { /* no address yet */ }
    if (at === host) { await rememberAccount(meta, n); return { tab }; }
  }
  if (tab) await chrome.tabs.remove(tab.id).catch(() => {});
  return { error: 'no-account' };
}

// The Gemini app tab, in the Google account where the notebooks are. Read only. openOnly as below.
async function appTab(meta, { openOnly = false } = {}) {
  const app = meta.app;
  const none = { close: () => {} };
  if (!(await chrome.permissions.contains({ origins: [app.host] }).catch(() => false))) return { ...none, error: 'no-permission' };
  const acct = (await get(accountKey(meta)))[accountKey(meta)] || '0';
  const acctOf = t => { try { return (new URL(t.url).pathname.match(/^\/u\/(\d+)\//) || [])[1] || '0'; } catch { return null; } };
  let tab = (await chrome.tabs.query({ url: app.host })).find(t => acctOf(t) === acct);
  let opened = false;
  if (!tab) {
    if (openOnly) return { ...none, error: 'no-open-tab' };
    tab = await chrome.tabs.create({ url: app.home(acct), active: false });
    opened = true;
    tab = await waitForLoad(tab.id);
  }
  const close = opened && tab ? () => chrome.tabs.remove(tab.id).catch(() => {}) : () => {};
  let host = ''; try { host = new URL(tab.url).host; } catch { /* none */ }
  if (!tab || host !== 'gemini.google.com') { close(); return { ...none, error: 'no-tab' }; }
  for (let i = 0; i < 20; i++) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: [app.proxy] }); } catch { /* not ready */ }
    const p = await sendTo(tab.id, { type: app.ping });
    if (p && p.pong) return { send: m => sendTo(tab.id, m), close };
    await new Promise(r => setTimeout(r, 500));
  }
  close();
  return { ...none, error: 'no-proxy' };
}

// openOnly: use a tab only if (a background check never opens tabs).
async function siteTab(meta, { openOnly = false } = {}) {
  const open = await chrome.tabs.query({ url: meta.host });
  let tab = open.find(t => t.status === 'complete') || open[0];
  let opened = false;
  if (!tab && openOnly) return { error: 'no-open-tab', close: () => {} };
  if (!tab && meta.accounts) {
    const r = await openWithAccount(meta);
    if (r.error) return { error: r.error, close: () => {} };
    tab = r.tab; opened = true;
  } else if (!tab) {
    tab = await chrome.tabs.create({ url: meta.home, active: false });
    opened = true;
    tab = await waitForLoad(tab.id);
  }
  const close = opened ? () => chrome.tabs.remove(tab.id).catch(() => {}) : () => {};
  if (!tab) return { error: 'no-tab', close };
  let lastErr = '';
  for (let i = 0; i < 20; i++) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: [meta.proxy] }); } catch (e) { lastErr = String(e && e.message || e); }
    const p = await sendTo(tab.id, { type: meta.ping });
    if (p && p.pong) {
      if (meta.accounts && p.account !== undefined) await rememberAccount(meta, p.account);
      return { send: m => sendTo(tab.id, m), close };
    }
    await new Promise(r => setTimeout(r, 500));
  }
  close();
  return { error: 'no-proxy', detail: `${lastErr} ${tab && tab.url}`, close: () => {} };
}

const hash = s => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return String(h >>> 0); };
const syncing = new Set();
let syncChain = Promise.resolve();

// Brings one course's project up to date. opts: { create: true } or { link: projectId }.
function syncProject(provider, courseId, opts = {}) {
  const job = syncChain.then(() => migrated).then(() => doSync(provider, courseId, opts));
  syncChain = job.catch(() => {});
  return job;
}

async function doSync(provider, courseId, opts) {
  if (!(await consented())) return { ok: false, error: 'needs-consent' };
  const meta = PROVIDERS[provider];
  if (!meta) return { ok: false, reason: 'error', error: 'unknown provider' };
  const k = projKey(provider, courseId);
  const busyKey = `${provider}:${courseId}`;
  let proj = await projOf(provider, courseId);
  if (!proj && !opts.create && !opts.link) return { ok: false, reason: 'no-project' };
  // The quick summary check runs quietly: no "syncing" badge every 15 minutes.
  const quiet = !!opts.summariesOnly;
  if (!quiet) { syncing.add(busyKey); await set({ syncing: [...syncing] }); }
  let st = null, mt = null;
  const save = async patch => { proj = { ...(proj || {}), ...patch }; await set({ [k]: proj }); };
  try {
    const { year, course, recordings } = await courseData(courseId);
    const granted = await chrome.permissions.contains({ origins: [meta.host] }).catch(() => true);
    if (!granted) return { ok: false, reason: 'no-permission' };
    st = await siteTab(meta, { openOnly: !!opts.summariesOnly && !opts.openNotebook });
    if (st.error && opts.summariesOnly) return { ok: false, reason: 'quiet' };
    if (st.error === 'no-account') {
      if (proj) await save({ lastError: 'לא מצאתי חשבון גוגל פרטי מחובר בכרום. המחברות עובדות רק בחשבון פרטי.', lastErrorAt: Date.now() });
      return { ok: false, reason: 'no-account', site: meta.label };
    }
    if (st.error) { if (proj) await save({ lastError: `לא הצלחתי לפתוח את ${meta.label}`, lastErrorAt: Date.now() }); return { ok: false, reason: 'no-site-tab', error: st.detail || st.error }; }
    const api = adapterFor(provider, st.send);
    const name = (course.short || course.name || '').replace(/^\d+(?:_\d+)?-/, '');

    if (opts.create) {
      const p = await api.createProject(name, `אתר הקורס במודל (${year}), מתעדכן אוטומטית מהתוסף "מורה פרטי למודל".`);
      proj = { projectId: p.uuid, name: p.name, record: {}, created: Date.now(), seen: [] };
      await set({ [k]: proj });
    } else if (opts.link) {
      const p = await api.getProject(opts.link);
      proj = { projectId: p.uuid, name: p.name, record: {}, linked: Date.now(), seen: [] };
      await set({ [k]: proj });
    }
    const pid = proj.projectId;
    let project;
    try { project = await api.getProject(pid); }
    catch (e) { if (e instanceof ProjectMissing) { await save({ lastError: `הפרויקט נמחק ב-${meta.label}`, lastErrorAt: Date.now(), missing: true }); return { ok: false, reason: 'project-missing' }; } throw e; }

    // 1. Instructions: our block, kept up to date, around whatever the student wrote.
    let tutor = await tutorOf(courseId);
    // Lines the student changed inside our block are moved below it, not overwritten; if the student
    // removed the block's marker lines, nothing is written until they choose.
    const ours = projectInstructions(course, tutor.profile || {}, { lang: (await settings()).lang || 'he' });
    const up = updateInstructions(project.instructions, ours, proj.insLast || null, { force: !!opts.forceIns });
    if (up.markersMissing) await save({ notice: { type: 'markers-missing', at: Date.now() } });
    else {
      if (up.text !== (project.instructions || '')) await api.setInstructions(pid, up.text);
      await save({ insLast: ours, notice: up.moved.length ? { type: 'moved', lines: up.moved.length, at: Date.now() } : (proj.notice && proj.notice.type === 'moved' ? proj.notice : null) });
    }

    // 2. Session summaries the tutor wrote since the last check go into the progress file.
    let newSummaries = 0, newPrefs = false;
    if (meta.readsSummaries) {
      const seen = new Set(proj.seen || []);
      const take = messages => {
        for (const m of messages) {
          if (seen.has(m.uuid)) continue;
          seen.add(m.uuid);
          // The getting-to-know conversation's answers: kept for every chat of the course.
          const prefs = parsePrefs(m.text);
          if (prefs) {
            const date = new Date(m.at || Date.now()).toISOString().slice(0, 10);
            tutor = { ...tutor, prefs: { ...prefs, date }, profile: { ...prefsToProfile(prefs, tutor.profile || {}), prefs } };
            newPrefs = true;
          }
          const sum = parseSummary(m.text);
          if (!sum) continue;
          tutor = { ...tutor, ...applySummary(tutor, sum, new Date(m.at || Date.now())) };
          newSummaries++;
        }
      };
      const { messages, since } = await api.readSummaries(pid, proj.convCheckedAt || '');
      take(messages);
      const patch = { convCheckedAt: since };
      // Gemini: the conversations opened in the Gemini app too. A problem there never stops the sync.
      if (meta.app) {
        const at = await appTab(meta, { openOnly: !!opts.summariesOnly });
        if (!at.error) {
          try { const r = await readAppSummaries(at.send, pid, proj.appCheckedAt || ''); take(r.messages); patch.appCheckedAt = r.since; }
          catch { /* read next time */ }
          finally { at.close(); }
        }
      }
      if (newSummaries || newPrefs) await set({ [tutorKey(courseId)]: tutor });
      // New preferences change the instructions right away, not only at the next sync.
      if (newPrefs && !up.markersMissing) {
        const ours2 = projectInstructions(course, tutor.profile || {}, { lang: (await settings()).lang || 'he' });
        const up2 = updateInstructions(up.text, ours2, ours);
        if (!up2.markersMissing && up2.text !== up.text) { await api.setInstructions(pid, up2.text); await save({ insLast: ours2 }); }
      }
      await save({ seen: [...seen].slice(-500), ...patch });
    }

    // The quick check between scans: only the progress file, and only when there is something new.
    if (opts.summariesOnly) {
      if (newSummaries || newPrefs) {
        const docs = { ...((proj.record && proj.record.docs) || {}) };
        const content = progressDoc(course, tutor);
        docs[PROGRESS_NAME] = { id: await api.putDoc(pid, PROGRESS_NAME, content, docs[PROGRESS_NAME] && docs[PROGRESS_NAME].id), hash: hash(content) };
        await save({ record: { ...(proj.record || {}), docs } });
      }
      return { ok: true, projectId: pid, newSummaries, summariesOnly: true };
    }

    // 3. Course files: new ones uploaded, replaced ones uploaded as a dated new version.
    const projectFiles = await api.listFiles(pid);
    // The real file limit when the site tells it (ChatGPT: by plan). Where the extension's own two text
    // files count as files too, they get their places first.
    const maxFiles = project.maxFiles || meta.limits.maxFiles;
    const limits = { ...meta.limits, maxFiles: provider === 'claude' ? maxFiles : Math.max(0, maxFiles - 2) };
    const plan = planSync(course, proj.record, projectFiles.filter(f => ![MAP_NAME, PROGRESS_NAME].includes(f.file_name)), new Date(), limits);
    let record = recordUploads(proj.record, plan.adopt.map(a => ({ key: a.key, uuid: a.uuid, name: a.name, sig: a.sig })));
    const failed = [];
    let uploaded = 0;
    const MAX_UPLOADS_PER_SYNC = 30;    // a big course goes up over a few syncs, not in one burst
    const batch = plan.upload.slice(0, MAX_UPLOADS_PER_SYNC);
    const later = plan.upload.length - batch.length;
    for (const u of batch) {
      if (uploaded) await new Promise(r => setTimeout(r, 400));
      if (!mt) { mt = await moodleTab(year); if (mt.loginNeeded) { failed.push({ key: u.key, why: 'ההתחברות למודל פגה' }); break; } }
      const b = await sendTo(mt.tabId, { type: 'proxy-bytes', url: u.file.url });
      if (!b || !b.ok) { failed.push({ key: u.key, why: b && b.error === 'login' ? 'ההתחברות למודל פגה' : 'לא ירד מהמודל' }); if (b && b.error === 'login') break; continue; }
      if (b.size > meta.limits.maxFileBytes) { failed.push({ key: u.key, why: 'גדול מדי' }); continue; }
      try {
        const r = await api.upload(pid, u.name, b.type || u.file.type, b.b64);
        // Where the site allows it, the lecturer's replaced file takes the old one's place.
        let replaces = u.replaces;
        if (replaces && api.removeFile) { try { await api.removeFile(pid, replaces.uuid); replaces = null; } catch { /* stays, marked as old */ } }
        record = recordUploads(record, [{ ...u, replaces, uuid: r.file_uuid }], []);
        uploaded++;
        await save({ record });
      } catch (e) {
        if (e instanceof LoginRequired) throw e;
        failed.push({ key: u.key, why: `${meta.label} לא קיבל את הקובץ (${e.status || 'שגיאה'})` });
      }
    }
    record = recordUploads(record, [], failed);

    // 4. The two files the extension writes: the course map and the progress file.
    const docs = { ...(record.docs || {}) };
    for (const [fname, content] of [[MAP_NAME, courseMap(course, record, { recordings, year, overflow: plan.overflow })], [PROGRESS_NAME, progressDoc(course, tutor)]]) {
      const h = hash(content);
      if (docs[fname] && docs[fname].hash === h && provider !== 'claude') continue;
      const id = await api.putDoc(pid, fname, content, docs[fname] && docs[fname].id);
      docs[fname] = { id, hash: h };
    }
    record = { ...record, docs };

    // More files than one sync takes: the rest go up in a minute, not at the next scan.
    if (later > 0) chrome.alarms.create('sync-more', { delayInMinutes: 1 });
    const inProject = Object.keys(record.files || {}).length;
    await save({ record, name: project.name, lastSync: Date.now(), lastError: null, missing: false,
      counts: { inProject, uploaded, later, failed: Object.keys(record.failed || {}).length, skipped: plan.skipped.length, overflow: plan.overflow.length, superseded: (record.superseded || []).length, summaries: newSummaries } });
    return { ok: true, projectId: pid, uploaded, failed: failed.length, newSummaries };
  } catch (e) {
    const login = e instanceof LoginRequired;
    if (opts.summariesOnly) return { ok: false, reason: 'quiet', error: String(e.message || e) };
    if (proj) await save({ lastError: login ? `צריך להתחבר ל-${meta.label}` : String(e.message || e), lastErrorAt: Date.now(), needsLogin: login });
    return { ok: false, reason: login ? 'site-login' : 'error', error: String(e.message || e), site: meta.label };
  } finally {
    if (mt && mt.close) mt.close();
    if (st && st.close) st.close();
    if (!quiet) { syncing.delete(busyKey); await set({ syncing: [...syncing] }); }
  }
}

async function syncAllProjects() {
  await migrated;
  const all = await chrome.storage.local.get(null);
  const keys = Object.keys(all).filter(k => k.startsWith('proj:') && all[k] && all[k].projectId && !all[k].missing);
  for (const key of keys) { const [, provider, id] = key.split(':'); await syncProject(provider, id); }
}

// Every 15 minutes: a summary the tutor just wrote reaches the progress file without waiting for a scan.
// Only through a chat tab the student already has open, and only for chats whose summaries can be read.
async function checkSummaries() {
  if (!(await consented())) return;
  await migrated;
  const all = await chrome.storage.local.get(null);
  for (const key of Object.keys(all)) {
    if (!key.startsWith('proj:') || !all[key] || !all[key].projectId || all[key].missing) continue;
    const [, provider, id] = key.split(':');
    const meta = PROVIDERS[provider];
    if (!meta || !meta.readsSummaries) continue;
    const siteOpen = (await chrome.tabs.query({ url: meta.host })).length > 0;
    let openNotebook = false;
    if (!siteOpen) {
      // Gemini: only the app is open. Peek there; open the notebook site (in the background) only
      // when there is a new summary to write into the progress file.
      if (!meta.app) continue;
      const at = await appTab(meta, { openOnly: true });
      if (at.error) continue;
      let fresh = false;
      try {
        const seen = new Set(all[key].seen || []);
        const r = await readAppSummaries(at.send, all[key].projectId, all[key].appCheckedAt || '');
        fresh = r.messages.some(m => !seen.has(m.uuid) && parseSummary(m.text));
      } catch { /* try next time */ } finally { at.close(); }
      if (!fresh) continue;
      openNotebook = true;
    }
    await syncProject(provider, id, { summariesOnly: true, openNotebook }).catch(() => {});
  }
}

async function siteProjects(provider) {
  const meta = PROVIDERS[provider];
  const st = await siteTab(meta);
  if (st.error) return { ok: false, reason: st.error === 'no-account' ? 'no-account' : 'no-site-tab', site: meta.label };
  try { return { ok: true, projects: await adapterFor(provider, st.send).listProjects() }; }
  catch (e) { return { ok: false, reason: e instanceof LoginRequired ? 'site-login' : 'error', error: String(e.message || e), site: meta.label }; }
  finally { st.close(); }
}

// What the student copies to send when something goes wrong. No file contents, no chat content, no
// passwords: the version, the site, the states and the error messages.
async function diagnostics() {
  const s = await settings(); const year = yearOf(s);
  const all = await chrome.storage.local.get(null);
  const snap = all[`snapshot:${year}`];
  const perms = await chrome.permissions.getAll().catch(() => ({}));
  const projects = Object.fromEntries(Object.entries(all).filter(([k]) => k.startsWith('proj:')).map(([k, v]) => [k, { lastSync: v.lastSync && new Date(v.lastSync).toISOString(), lastError: v.lastError || null, needsLogin: !!v.needsLogin, missing: !!v.missing, counts: v.counts }]));
  const dl = await queue.summary();
  return {
    extension: chrome.runtime.getManifest().version, browser: navigator.userAgent, at: new Date().toISOString(),
    site: s.site ? s.site.root : 'huji', year, chats: s.chats, scanEveryHours: s.scanEveryHours, saveFiles: s.saveFiles,
    status: all.status ? { state: all.status.state, errors: all.status.errors, finishedAt: all.status.finishedAt && new Date(all.status.finishedAt).toISOString(), opened: all.status.opened } : null,
    courses: snap ? { listed: (snap.courseList || []).length, scanned: Object.keys(snap.courses || {}).length, scannedAt: snap.scannedAt && new Date(snap.scannedAt).toISOString() } : null,
    downloads: { waiting: dl.waiting, done: dl.done, blocked: dl.blocked, paused: dl.paused, failed: (dl.failed || []).map(f => ({ name: String(f.filename).split('/').pop(), error: f.error })), held: (dl.held || []).length, renamed: (dl.renamed || []).length },
    projects, tasks: ((all[`tasks:${year}`] || {}).list || []).length,
    permissions: perms.origins || [],
  };
}

// Backup: everything the extension keeps, as one file the student saves and can load back.
const BACKUP_KEYS = k => k === 'settings' || k === 'tasksDone' || k === 'dl' || k.startsWith('account:') || k.startsWith('tutor:') || k.startsWith('proj:') || k.startsWith('project:') || k.startsWith('snapshot:') || k.startsWith('events:');
async function exportAll() {
  const all = await chrome.storage.local.get(null);
  return { app: 'moodle-tutor', version: 2, at: new Date().toISOString(), data: Object.fromEntries(Object.entries(all).filter(([k]) => BACKUP_KEYS(k))) };
}
async function importAll(backup) {
  if (!backup || backup.app !== 'moodle-tutor' || typeof backup.data !== 'object') return { ok: false, reason: 'not-a-backup' };
  const data = Object.fromEntries(Object.entries(backup.data).filter(([k]) => BACKUP_KEYS(k)));
  await set(data);
  await schedule();
  return { ok: true, count: Object.keys(data).length };
}

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  (async () => {
    switch (msg.type) {
      case 'scan': return { status: await runScan('manual') };
      case 'stop': {
        stopRequested = true;
        await queue.stop();
        return { ok: true };
      }
      case 'resume-downloads': await queue.resume(); await updateBadge(); return { ok: true };
      case 'release': await queue.release(msg.sigs); return { ok: true };
      case 'approve': {
        const s = await settings();
        await set({ settings: { ...s, courseChoice: { ...s.courseChoice, ...msg.choices } } });
        runScan('approved');
        return { ok: true };
      }
      case 'reset': await resetAll(); return { ok: true };
      case 'state': {
        const s = await settings(); const year = yearOf(s);
        const all = await chrome.storage.local.get(null);
        // projects[courseId][provider] = project state
        const projects = {};
        for (const [k, v] of Object.entries(all)) {
          const m = k.match(/^proj:(\w+):(.+)$/) || k.match(/^project:()(\d+)$/);
          if (!m) continue;
          const provider = m[1] || 'claude';
          (projects[m[2]] = projects[m[2]] || {})[provider] = v;
        }
        const tutors = Object.fromEntries(Object.entries(all).filter(([k]) => k.startsWith('tutor:')).map(([k, v]) => [k.slice(6), v]));
        return { settings: s, year, snapshot: all[`snapshot:${year}`] || null, events: all[`events:${year}`] || [], status: all.status || null,
          moodleRoot: rootFor(s.site || null, year),
          tasks: (all[`tasks:${year}`] && all[`tasks:${year}`].list) || [], tasksAt: all[`tasks:${year}`] && all[`tasks:${year}`].at, tasksDone: all.tasksDone || {}, helpSeen: !!all.helpSeen, update: all.update || null, version: chrome.runtime.getManifest().version, accounts: { gemini: all['account:gemini'] || null }, consent: !!all.consent && all.consent.v >= CONSENT_VERSION,
          projects, tutors, syncing: all.syncing || [],
          downloads: await queue.summary() };
      }
      case 'settings': {
        const s = { ...(await settings()), ...msg.patch };
        await set({ settings: s }); await schedule(); return { settings: s };
      }
      case 'seen': {
        const s = await settings(); const k = `events:${yearOf(s)}`;
        const { [k]: events = [] } = await get(k);
        await set({ [k]: events.map(e => (!msg.courseId || e.courseId === msg.courseId) ? { ...e, seen: true } : e) });
        await updateBadge(); return { ok: true };
      }
      case 'classify': {
        const s = await settings(); const k = `snapshot:${yearOf(s)}`;
        const { [k]: snap } = await get(k);
        const it = snap && snap.courses[msg.courseId] && snap.courses[msg.courseId].items[msg.cmid];
        if (!it) return { ok: false };
        if (msg.category) { it.category = msg.category; it.categoryByUser = true; }
        if (msg.material) { it.material = msg.material; it.materialByUser = true; }
        await set({ [k]: snap }); return { ok: true };
      }
      case 'open-folder': {
        const s = await settings(); const year = yearOf(s);
        const { [`snapshot:${year}`]: snap } = await get(`snapshot:${year}`);
        const course = snap && (snap.courseList || []).find(c => c.id === msg.courseId);
        if (course) {
          const dir = courseDir({ year, course, root: s.rootFolder }).split('/').map(x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('[\\\\/]');
          const items = await chrome.downloads.search({ filenameRegex: dir + '[\\\\/]', exists: true, state: 'complete', orderBy: ['-startTime'], limit: 1 }).catch(() => []);
          if (items[0]) { chrome.downloads.show(items[0].id); return { ok: true }; }
        }
        chrome.downloads.showDefaultFolder();
        return { ok: true, fallback: true };
      }
      case 'task-done': {
        const { tasksDone = {} } = await get('tasksDone');
        if (msg.done) tasksDone[msg.id] = Date.now(); else delete tasksDone[msg.id];
        await set({ tasksDone }); await updateBadge(); return { ok: true };
      }
      case 'update-check': return { update: await checkUpdate() };
      case 'update-download': return downloadUpdate();
      case 'updater-present': return { present: await updaterPresent() };
      case 'update-auto': return updateWithUpdater();
      case 'check-summaries': await checkSummaries(); return { ok: true };
      case 'help-seen': await set({ helpSeen: true }); return { ok: true };
      case 'consent': await set({ consent: { v: CONSENT_VERSION, at: Date.now() } }); return { ok: true };
      case 'diagnostics': return diagnostics();
      case 'connect-site': return connectSite(msg.url);
      case 'set-site': return setSite(msg.site);
      case 'missing-files': return { missing: await queue.missing() };
      case 'redownload': await queue.redownload(msg.sigs); return { ok: true };
      case 'tutor-get': return { tutor: await tutorOf(msg.courseId) };
      case 'tutor-save': { const t = await tutorOf(msg.courseId); const v = { ...t, ...msg.patch }; await set({ [tutorKey(msg.courseId)]: v }); return { tutor: v }; }
      case 'site-projects': return siteProjects(msg.provider);
      case 'project-create': return syncProject(msg.provider || 'claude', msg.courseId, { create: true });
      case 'project-link': return syncProject(msg.provider || 'claude', msg.courseId, { link: msg.projectId });
      case 'project-sync': return msg.courseId ? syncProject(msg.provider || 'claude', msg.courseId, msg.forceIns ? { forceIns: true } : {}) : (syncAllProjects(), { ok: true });
      case 'notice-seen': { const k = projKey(msg.provider, msg.courseId); const p = (await get(k))[k]; if (p) await set({ [k]: { ...p, notice: null } }); return { ok: true }; }
      case 'project-unlink': await chrome.storage.local.remove(projKey(msg.provider || 'claude', msg.courseId)); return { ok: true };
      case 'export': return exportAll();
      case 'import': return importAll(msg.backup);
      default: return { error: 'unknown' };
    }
  })().then(reply, e => reply({ error: String(e && e.message || e) }));
  return true;
});
