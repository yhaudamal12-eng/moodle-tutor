// The booklets page: both course booklets, laid out for printing. Opened from the side panel with
// ?course=<id>. The browser's own print dialog makes the PDF.
import { S } from '../sidepanel/strings.js';
import { BOOKS, ISSUE_LABEL } from '../src/booklet.js';
import { renderChapter, splitAnswers } from '../src/render.js';
import { drawGraph } from '../src/graph.js';

const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const courseId = new URLSearchParams(location.search).get('course');
const ui = { which: 'both', booklet: null, course: null, removing: null };
try { ui.which = localStorage.getItem('booklet-which') || 'both'; } catch { /* default */ }

// output: 'html' for the page (KaTeX fonts), 'mathml' for the saved copy (no fonts needed).
const mathWith = output => (tex, display) => {
  try { return globalThis.katex.renderToString(tex, { displayMode: display, throwOnError: true, output, strict: 'ignore' }); }
  catch { return `<code class="tex-bad" dir="ltr">${esc(tex)}</code>`; }
};
const graph = lines => drawGraph(lines).html;
const dmy = d => (d ? `${d.slice(8, 10)}.${d.slice(5, 7)}.${d.slice(0, 4)}` : '');

function bookHtml(book, chapters, course, math) {
  const info = BOOKS[book];
  const last = chapters.map(c => c.date).sort().at(-1);
  const parts = [];
  parts.push(`<section class="cover"><div class="kicker">${esc(course.name)}</div><h1>${esc(info.label)}</h1>`
    + `<div class="meta">${esc(S.bkChapters(chapters.length))} · ${esc(S.bkUpdated(dmy(last)))}</div><p class="covernote">${esc(S.bkCoverNote)}</p></section>`);
  parts.push(`<nav class="toc"><h2>${esc(S.bkContents)}</h2><ol>${chapters.map((c, i) => `<li><a href="#${book}-${i + 1}">${esc(c.topic)}</a></li>`).join('')}</ol></nav>`);
  const answers = [];
  chapters.forEach((c, i) => {
    const { main, answers: ans } = book === 'study' ? splitAnswers(c.body) : { main: c.body, answers: '' };
    if (ans) answers.push({ n: i + 1, topic: c.topic, html: renderChapter(ans, { math, graph }) });
    parts.push(`<article class="chapter ${book}" id="${book}-${i + 1}"><div class="chnum">${esc(S.bkChapter(i + 1))}</div><h1>${esc(c.topic)}</h1>`
      + (c.sources && c.sources.length ? `<p class="sources">${esc(S.bkSources)}: ${c.sources.map(esc).join(' · ')}</p>` : '')
      + `<div class="body">${renderChapter(main, { math, graph })}</div></article>`);
  });
  if (answers.length) parts.push(`<section class="answers"><h1>${esc(S.bkAnswers)}</h1>${answers.map(a => `<h2>${esc(S.bkChapter(a.n))}: ${esc(a.topic)}</h2>${a.html}`).join('')}</section>`);
  return `<div class="book ${book}">${parts.join('\n')}</div>`;
}

function docHtml(math) {
  const b = ui.booklet || {};
  const books = ui.which === 'both' ? ['study', 'summary'] : [ui.which];
  return books.filter(k => (b[k] || []).length).map(k => bookHtml(k, b[k], ui.course, math)).join('\n');
}

function render() {
  const b = ui.booklet;
  const doc = $('doc');
  if (!ui.course) { doc.innerHTML = `<p class="empty">${esc(S.bkNoCourse)}</p>`; return; }
  document.title = `${S.bkPageTitle}: ${ui.course.name}`;
  const any = b && ((b.study || []).length || (b.summary || []).length);
  doc.innerHTML = any ? docHtml(mathWith('html')) : `<p class="empty">${esc(S.bkEmpty)}</p>`;
  $('note').textContent = b && b.open ? S.bkCut : S.bkPrintHint;
  $('note').classList.toggle('warn', !!(b && b.open));
  renderChecks();
}

function renderChecks() {
  const box = $('checks');
  const b = ui.booklet || {};
  const all = [...(b.study || []).map(c => ['study', c]), ...(b.summary || []).map(c => ['summary', c])];
  const bad = all.filter(([, c]) => (c.issues || []).length);
  $('checks-btn').textContent = `${S.bkChecks} (${bad.length})`;
  box.innerHTML = '';
  const p = document.createElement('p');
  p.textContent = bad.length ? S.bkChecksSome(bad.length) : S.bkChecksNone;
  box.append(p);
  for (const [book, c] of all) {
    const item = document.createElement('div');
    item.className = 'check';
    const h = document.createElement('h3');
    h.textContent = `${BOOKS[book].label}: ${c.topic}`;
    item.append(h);
    if ((c.issues || []).length) {
      const ul = document.createElement('ul');
      for (const i of c.issues) { const li = document.createElement('li'); li.textContent = `${ISSUE_LABEL[i.code] || i.code}${i.line ? ` (${S.bkLine(i.line)})` : ''}: ${i.text}`; ul.append(li); }
      item.append(ul);
    }
    const key = `${book}:${c.topic}`;
    const rm = document.createElement('button');
    rm.className = 'quiet';
    rm.textContent = ui.removing === key ? S.bkRemoveSure : S.bkRemove;
    rm.onclick = async () => {
      if (ui.removing !== key) { ui.removing = key; renderChecks(); return; }
      ui.removing = null;
      await chrome.runtime.sendMessage({ type: 'booklet-remove', courseId, book, topic: c.topic });
      await load();
    };
    item.append(rm);
    box.append(item);
  }
}

async function load() {
  const r = await chrome.runtime.sendMessage({ type: 'booklet', courseId });
  ui.booklet = (r && r.booklet) || null;
  ui.course = (r && r.course) || null;
  render();
}

// A copy next to the course files: the same page, formulas in MathML so it needs no font files.
async function saveCopy() {
  const css = await (await fetch('page.css')).text();
  const html = `<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><title>${esc(document.title)}</title><style>${css.replace(/@font-face\s*{[^}]*}/g, '')}</style></head><body><main id="doc">${docHtml(mathWith('mathml'))}</main></body></html>`;
  const name = ui.which === 'both' ? `חוברות הקורס - ${ui.course.name}` : `${BOOKS[ui.which].file} - ${ui.course.name}`;
  const r = await chrome.runtime.sendMessage({ type: 'booklet-save', courseId, html, name });
  $('note').textContent = r && r.ok ? S.bkSaved : S.bkSaveFailed;
}

function setup() {
  $('which-label').textContent = S.bkWhich;
  const sel = $('which');
  for (const [v, t] of [['both', S.bkBoth], ['study', BOOKS.study.label], ['summary', BOOKS.summary.label]]) { const o = document.createElement('option'); o.value = v; o.textContent = t; sel.append(o); }
  sel.value = ui.which;
  sel.onchange = () => { ui.which = sel.value; try { localStorage.setItem('booklet-which', ui.which); } catch { /* fine */ } render(); };
  $('print').textContent = S.bkPrint;
  $('print').onclick = () => window.print();
  $('save').textContent = S.bkSave;
  $('save').onclick = saveCopy;
  $('checks-btn').onclick = () => { $('checks').hidden = !$('checks').hidden; };
  // A chapter that arrives while the page is open shows up by itself.
  chrome.storage.onChanged.addListener(ch => { if (ch[`booklet:${courseId}`]) load(); });
}

setup();
load();
