// Graphs for the booklets. The tutor describes a graph in a few Hebrew lines ("עקומה: היצע = 0.3*x + 10");
// this module reads the description and draws it as SVG. Intersections and areas are computed here, so
// a graph is right even when the tutor's arithmetic is not. Formulas are read by a small calculator of
// our own: nothing in the text is ever run as code.

// ---------- The calculator ----------

const FN = Object.assign(Object.create(null), {
  sqrt: Math.sqrt, ln: Math.log, log: Math.log10, exp: Math.exp, abs: Math.abs, sin: Math.sin, cos: Math.cos, tan: Math.tan,
  'שורש': Math.sqrt,
});
// No prototype: a name like "constructor" is not a function or a constant here.
const CONST = Object.assign(Object.create(null), { pi: Math.PI, e: Math.E, 'π': Math.PI });

function tokens(src) {
  const out = [];
  const s = String(src).replace(/[−–]/g, '-').replace(/[×·]/g, '*').replace(/√/g, 'sqrt').replace(/\s+/g, '');
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    const num = s.slice(i).match(/^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i);
    if (num) { out.push({ t: 'n', v: parseFloat(num[0]) }); i += num[0].length; continue; }
    const id = s.slice(i).match(/^([A-Za-z]+|π|שורש)/);
    if (id) { out.push({ t: 'id', v: id[0] }); i += id[0].length; continue; }
    if ('+-*/^(),'.includes(c)) { out.push({ t: c }); i++; continue; }
    throw new Error(`תו לא מוכר בנוסחה: "${c}"`);
  }
  // Implicit multiplication: 0.3x, 2(x+1), (x+1)(x-1), x(1-x).
  const res = [];
  for (const tk of out) {
    const prev = res.at(-1);
    if (prev && (prev.t === 'n' || prev.t === ')' || (prev.t === 'id' && !FN[prev.v])) && (tk.t === 'id' || tk.t === '(' || tk.t === 'n')) {
      if (!(prev.t === 'id' && tk.t === '(' && FN[prev.v])) res.push({ t: '*' });
    }
    res.push(tk);
  }
  return res;
}

// Returns f(x). Throws a Hebrew message for a formula it cannot read.
export function compile(src) {
  const tk = tokens(src);
  let p = 0;
  const peek = () => tk[p], eat = t => { if (tk[p] && tk[p].t === t) return tk[p++]; throw new Error(`חסר "${t}" בנוסחה`); };
  // expr := term (('+'|'-') term)*; term := unary (('*'|'/') unary)*; unary := '-' unary | power; power := atom ('^' unary)?
  const expr = () => { let f = term(); while (peek() && (peek().t === '+' || peek().t === '-')) { const op = tk[p++].t; const a = f, b = term(); f = op === '+' ? x => a(x) + b(x) : x => a(x) - b(x); } return f; };
  const term = () => { let f = unary(); while (peek() && (peek().t === '*' || peek().t === '/')) { const op = tk[p++].t; const a = f, b = unary(); f = op === '*' ? x => a(x) * b(x) : x => a(x) / b(x); } return f; };
  const unary = () => { if (peek() && peek().t === '-') { p++; const a = unary(); return x => -a(x); } if (peek() && peek().t === '+') { p++; return unary(); } return power(); };
  const power = () => { const a = atom(); if (peek() && peek().t === '^') { p++; const b = unary(); return x => Math.pow(a(x), b(x)); } return a; };
  const atom = () => {
    const t = tk[p++];
    if (!t) throw new Error('הנוסחה נגמרה באמצע');
    if (t.t === 'n') return () => t.v;
    if (t.t === '(') { const f = expr(); eat(')'); return f; }
    if (t.t === 'id') {
      if (t.v === 'x' || t.v === 'X') return x => x;
      if (CONST[t.v] !== undefined) return () => CONST[t.v];
      if (FN[t.v]) { eat('('); const a = expr(); eat(')'); const fn = FN[t.v]; return x => fn(a(x)); }
      throw new Error(`לא מכיר את "${t.v}" (המשתנה בגרף הוא x)`);
    }
    throw new Error(`לא ציפיתי ל־"${t.t}" כאן`);
  };
  const f = expr();
  if (p < tk.length) throw new Error(`יש עודף בסוף הנוסחה: "${tk.slice(p).map(t => t.v ?? t.t).join('')}"`);
  return f;
}

// ---------- Distributions ----------

const lgamma = n => { let s = 0; for (let k = 2; k <= n; k++) s += Math.log(k); return s; };
const DIST = Object.assign(Object.create(null), {
  'נורמלית': { n: 2, f: (m, s) => x => Math.exp(-((x - m) ** 2) / (2 * s * s)) / (s * Math.sqrt(2 * Math.PI)), range: (m, s) => [m - 4 * s, m + 4 * s] },
  'מעריכית': { n: 1, f: l => x => (x < 0 ? 0 : l * Math.exp(-l * x)), range: l => [0, 5 / l] },
  'אחידה': { n: 2, f: (a, b) => x => (x >= a && x <= b ? 1 / (b - a) : 0), range: (a, b) => [a - (b - a) * 0.2, b + (b - a) * 0.2] },
  'בינומית': { n: 2, discrete: true, f: (n, q) => k => (k < 0 || k > n || k !== Math.round(k) ? 0 : Math.exp(lgamma(n) - lgamma(k) - lgamma(n - k) + k * Math.log(q) + (n - k) * Math.log(1 - q))), range: n => [0, n] },
  'פואסון': { n: 1, discrete: true, f: l => k => (k < 0 || k !== Math.round(k) ? 0 : Math.exp(-l + k * Math.log(l) - lgamma(k))), range: l => [0, Math.ceil(l + 4 * Math.sqrt(l) + 2)] },
});
DIST['נורמלי'] = DIST['נורמלית']; DIST['פואסונית'] = DIST['פואסון']; DIST['בינומי'] = DIST['בינומית']; DIST['אחיד'] = DIST['אחידה'];

// ---------- Reading the description ----------

const NUM = '(-?\\d+(?:\\.\\d+)?)';
const unprefix = s => s.trim().replace(/^ל[־-]?/, '').replace(/^ה(?=\S)/, m => m);
const clean = s => String(s || '').trim().replace(/^["'״]|["'״]$/g, '');

export function parseGraph(lines) {
  const g = { title: '', x: null, y: null, curves: [], dists: [], bars: [], points: [], hlines: [], vlines: [], areas: [], errors: [], warnings: [] };
  for (const raw of lines) {
    const line = raw.replace(/\*\*/g, '').trim();
    if (!line) continue;
    const m = line.match(/^([^:=]+?)\s*:\s*(.*)$/);
    if (!m) { g.errors.push(`לא הבנתי את השורה: "${line}"`); continue; }
    const kind = m[1].trim(), rest = m[2].trim();
    const named = () => { const k = rest.indexOf('='); return k < 0 ? [null, rest] : [clean(rest.slice(0, k)), rest.slice(k + 1).trim()]; };
    try {
      if (kind === 'כותרת') g.title = rest;
      else if (/^ציר\s+(אופקי|x)$/i.test(kind) || /^ציר\s+(אנכי|y)$/i.test(kind)) {
        const r = rest.match(new RegExp(`^(.*?)[,،]?\\s*(?:מ[־-]?\\s*)?${NUM}\\s*(?:עד|-|–)\\s*${NUM}\\s*$`));
        const axis = r ? { label: clean(r[1].replace(/[,،]\s*$/, '')), min: +r[2], max: +r[3] } : { label: clean(rest), min: null, max: null };
        if (axis.min !== null && !(axis.max > axis.min)) throw new Error(`טווח ציר הפוך או ריק: ${rest}`);
        if (/אופקי|x/i.test(kind)) g.x = axis; else g.y = axis;
      } else if (kind === 'עקומה' || kind === 'קו') {
        const [name, ex] = named();
        g.curves.push({ name: name || `עקומה ${g.curves.length + 1}`, src: ex, f: compile(ex) });
      } else if (kind === 'התפלגות') {
        const [name, ex] = named();
        const d = ex.match(/^([א-ת]+)\s*\(([^)]*)\)\s*$/);
        if (!d || !DIST[d[1]]) throw new Error(`התפלגות לא מוכרת: "${ex}". אפשר: נורמלית, בינומית, פואסון, מעריכית, אחידה`);
        const args = d[2].split(/[,،;]/).map(a => compile(a.trim())(0));
        const D = DIST[d[1]];
        if (args.length !== D.n || args.some(a => !Number.isFinite(a))) throw new Error(`להתפלגות ${d[1]} צריך ${D.n === 1 ? 'מספר אחד' : 'שני מספרים'}: "${ex}"`);
        g.dists.push({ name: name || d[1], kind: d[1], args, f: D.f(...args), discrete: !!D.discrete, range: D.range(...args) });
      } else if (kind === 'עמודות' || kind === 'היסטוגרמה') {
        for (const part of rest.split(/[;؛]/).map(x => x.trim()).filter(Boolean)) {
          const b = part.match(new RegExp(`^(.+?)\\s*=\\s*${NUM}$`));
          if (!b) throw new Error(`עמודה צריכה להיות שם = מספר: "${part}"`);
          g.bars.push({ name: clean(b[1]), value: +b[2] });
        }
      } else if (kind === 'נקודה') {
        const [name, ex] = named();
        const xy = ex.match(new RegExp(`^\\(\\s*${NUM}\\s*[,،]\\s*${NUM}\\s*\\)$`));
        const cut = ex.match(/^חיתוך\s+(.+)$/);
        if (xy) g.points.push({ name: name || '', x: +xy[1], y: +xy[2] });
        else if (cut) g.points.push({ name: name || '', cut: cut[1].trim() });
        else throw new Error(`נקודה היא (x, y) או "חיתוך" של שתי עקומות: "${ex}"`);
      } else if (kind === 'קו אופקי' || kind === 'קו אנכי') {
        const [name, ex] = named();
        const v = compile(ex)(0);
        if (!Number.isFinite(v)) throw new Error(`ערך לא מספרי: "${ex}"`);
        (kind === 'קו אופקי' ? g.hlines : g.vlines).push({ name: name || '', v });
      } else if (kind === 'אזור') {
        const [name, ex] = named();
        g.areas.push({ name: name || '', src: ex });
      } else g.errors.push(`סוג שורה לא מוכר: "${kind}"`);
    } catch (e) { g.errors.push(e.message); }
  }
  if (!g.title) g.warnings.push('לגרף אין כותרת');
  if (!g.bars.length) {
    if (!g.x || !g.x.label) g.warnings.push('לציר האופקי אין שם');
    if (!g.y || !g.y.label) g.warnings.push('לציר האנכי אין שם');
  }
  resolve(g);
  return g;
}

// Names in references: "לביקוש", "וביקוש", "שיווי משקל" — matched against what the graph defines.
function findCurve(g, ref) {
  const want = ref.trim();
  const all = [...g.curves, ...g.dists];
  for (const v of [want, want.replace(/^ל[־-]?/, ''), want.replace(/^ו[־-]?/, ''), want.replace(/^מ[־-]?/, '')]) {
    const c = all.find(c => c.name === v);
    if (c) return c;
  }
  return null;
}
function findLevel(g, ref, kind) {
  const v = ref.trim().replace(/^[לו][־-]?/, '');
  if (/^-?\d+(\.\d+)?$/.test(v)) return +v;
  const list = kind === 'x' ? [...g.vlines.map(l => [l.name, l.v]), ...g.points.filter(p => Number.isFinite(p.x)).map(p => [p.name, p.x])] : [...g.hlines.map(l => [l.name, l.v]), ...g.points.filter(p => Number.isFinite(p.y)).map(p => [p.name, p.y])];
  const hit = list.find(([n]) => n === v || n === ref.trim());
  return hit ? hit[1] : null;
}

function xRange(g) {
  if (g.x && g.x.min !== null) return [g.x.min, g.x.max];
  if (g.dists.length) return [Math.min(...g.dists.map(d => d.range[0])), Math.max(...g.dists.map(d => d.range[1]))];
  const xs = [...g.points.filter(p => Number.isFinite(p.x)).map(p => p.x), ...g.vlines.map(l => l.v)];
  return xs.length ? [Math.min(0, ...xs), Math.max(...xs) * 1.25 || 10] : [0, 10];
}

function root(h, a, b) {
  let fa = h(a);
  for (let i = 0; i < 80; i++) { const m = (a + b) / 2, fm = h(m); if (Math.sign(fm) === Math.sign(fa)) { a = m; fa = fm; } else b = m; }
  return (a + b) / 2;
}

// Intersections and areas, once all names are known.
function resolve(g) {
  const [x0, x1] = xRange(g);
  g.range = [x0, x1];
  for (const p of g.points) {
    if (!p.cut) continue;
    const words = p.cut.split(/\s+/);
    let A = null, B = null;
    for (let k = 1; k < words.length && !(A && B); k++) {
      const a = findCurve(g, words.slice(0, k).join(' ')), b = findCurve(g, words.slice(k).join(' ').replace(/^ו[־-]?/, ''));
      if (a && b) { A = a; B = b; }
    }
    if (!A || !B) { g.errors.push(`לא מצאתי את שתי העקומות של החיתוך "${p.cut}"`); p.bad = true; continue; }
    const h = x => A.f(x) - B.f(x);
    const N = 400; let found = null;
    for (let i = 0; i < N && found === null; i++) {
      const a = x0 + (x1 - x0) * i / N, b = x0 + (x1 - x0) * (i + 1) / N;
      const ha = h(a), hb = h(b);
      if (!Number.isFinite(ha) || !Number.isFinite(hb)) continue;
      if (ha === 0) found = a; else if (Math.sign(ha) !== Math.sign(hb)) found = root(h, a, b);
    }
    if (found === null) { g.errors.push(`"${A.name}" ו"${B.name}" לא נחתכות בטווח של הציר`); p.bad = true; continue; }
    p.x = found; p.y = A.f(found);
  }
  for (const ar of g.areas) {
    const parts = ar.src.split(/[,،]/).map(x => x.trim()).filter(Boolean);
    const main = parts.shift() || '';
    const between = main.match(/^בין\s+(.+?)\s+(ל[־-]?\S.*)$/);
    const under = main.match(/^מתחת\s+(?:ל[־-]?)?(.+)$/);
    let lo, hi;
    if (between) {
      const a = findCurve(g, between[1]) || (findLevel(g, between[1], 'y') !== null && { f: (v => () => v)(findLevel(g, between[1], 'y')) });
      const b = findCurve(g, between[2]) || (findLevel(g, between[2], 'y') !== null && { f: (v => () => v)(findLevel(g, between[2], 'y')) });
      if (!a || !b) { g.errors.push(`לא מצאתי את העקומות של האזור "${ar.src}"`); ar.bad = true; continue; }
      lo = x => Math.min(a.f(x), b.f(x)); hi = x => Math.max(a.f(x), b.f(x));
    } else if (under) {
      const a = findCurve(g, under[1]);
      if (!a) { g.errors.push(`לא מצאתי את העקומה של האזור "${ar.src}"`); ar.bad = true; continue; }
      lo = () => 0; hi = x => a.f(x); ar.dist = g.dists.includes(a) && a.discrete ? a : null;
    } else { g.errors.push(`אזור הוא "בין" שתי עקומות או "מתחת" לעקומה: "${ar.src}"`); ar.bad = true; continue; }
    let from = x0, to = x1, floor = -Infinity, ceil = Infinity;
    for (const c of parts) {
      const span = c.match(/^מ[־-]?\s*(.+?)\s+עד\s+(.+)$/);
      const above = c.match(/^מעל\s+(?:ל[־-]?)?(.+)$/);
      const below = c.match(/^מתחת\s+(?:ל[־-]?)?(.+)$/);
      if (span) {
        const a = findLevel(g, span[1], 'x'), b = findLevel(g, span[2], 'x');
        if (a === null || b === null) { g.errors.push(`לא הבנתי את הגבולות "${c}"`); continue; }
        from = Math.min(a, b); to = Math.max(a, b);
      } else if (above) { const v = findLevel(g, above[1], 'y'); if (v === null) g.errors.push(`לא מצאתי את הקו "${above[1]}"`); else floor = v; }
      else if (below) { const v = findLevel(g, below[1], 'y'); if (v === null) g.errors.push(`לא מצאתי את הקו "${below[1]}"`); else ceil = v; }
      else g.errors.push(`לא הבנתי את ההגבלה "${c}"`);
    }
    ar.lo = x => Math.max(lo(x), floor); ar.hi = x => Math.min(hi(x), ceil); ar.from = from; ar.to = to;
  }
}

// ---------- Drawing ----------

const COLORS = ['#1f5f8b', '#b3261e', '#2e7d32', '#8e44ad', '#c77700', '#00796b'];
const DASH = ['', '7 4', '2 3', '10 3 2 3', '4 4', '1 2'];
const escx = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function ticks(a, b, n = 6) {
  const span = b - a; if (!(span > 0)) return [a];
  const raw = span / n, mag = 10 ** Math.floor(Math.log10(raw)), step = [1, 2, 2.5, 5, 10].map(k => k * mag).find(s => s >= raw) || raw;
  const out = []; for (let v = Math.ceil(a / step) * step; v <= b + step * 1e-9; v += step) out.push(+v.toFixed(10));
  return out;
}
const fmt = v => { const r = Math.abs(v) >= 100 ? v.toFixed(0) : Math.abs(v) >= 10 ? (+v.toFixed(1)).toString() : (+v.toFixed(2)).toString(); return r.replace('-', '−'); };

// Returns { html, errors, warnings }. A graph that cannot be drawn shows its own text, never a broken page.
let seq = 0;
export function drawGraph(lines) {
  const clip = `gclip${++seq}`;
  let g;
  try { g = parseGraph(lines); } catch (e) { g = { errors: [e.message], warnings: [] }; }
  const drawable = g.curves && (g.curves.length || g.dists.length || g.bars.length || g.points.some(p => !p.bad) || g.hlines.length || g.vlines.length);
  if (!drawable) return { html: `<div class="graph-error"><p>הגרף לא צויר: ${escx((g.errors || ['אין בו מה לצייר']).join('; '))}</p><pre>${escx(lines.join('\n'))}</pre></div>`, errors: g.errors.length ? g.errors : ['אין בגרף מה לצייר'], warnings: g.warnings || [] };
  const W = 680, H = 400, L = 58, R = 165, T = 44, B = 52;
  const pw = W - L - R, ph = H - T - B;
  // Bars: categories along the horizontal axis.
  if (g.bars.length) {
    const max = g.y && g.y.max !== null ? g.y.max : Math.max(...g.bars.map(b => b.value)) * 1.15 || 1;
    const min = g.y && g.y.min !== null ? g.y.min : Math.min(0, ...g.bars.map(b => b.value));
    const Y = v => T + ph - (v - min) / (max - min) * ph;
    const bw = pw / g.bars.length;
    const s = [];
    for (const t of ticks(min, max)) s.push(`<line class="grid" x1="${L}" x2="${L + pw}" y1="${Y(t)}" y2="${Y(t)}"/><text class="tick" direction="ltr" x="${L - 6}" y="${Y(t) + 4}" text-anchor="end">${fmt(t)}</text>`);
    g.bars.forEach((b, i) => {
      const x = L + i * bw + bw * 0.15, top = Y(Math.max(b.value, 0)), bot = Y(Math.min(b.value, 0));
      s.push(`<rect x="${x}" y="${top}" width="${bw * 0.7}" height="${Math.max(0, bot - top)}" fill="${COLORS[0]}" fill-opacity="0.75"/>`);
      s.push(`<text class="val" direction="ltr" x="${x + bw * 0.35}" y="${top - 5}" text-anchor="middle">${fmt(b.value)}</text>`);
      s.push(`<text class="lbl" x="${x + bw * 0.35}" y="${T + ph + 18}" text-anchor="middle" direction="rtl">${escx(b.name)}</text>`);
    });
    s.push(`<line class="axis" x1="${L}" x2="${L + pw}" y1="${Y(0)}" y2="${Y(0)}"/><line class="axis" x1="${L}" x2="${L}" y1="${T}" y2="${T + ph}"/>`);
    return wrap(g, s, W, H, L, T, pw, ph);
  }
  const [x0, x1] = g.range;
  let yMin = g.y && g.y.min !== null ? g.y.min : null, yMax = g.y && g.y.max !== null ? g.y.max : null;
  const fns = [...g.curves, ...g.dists];
  if (yMin === null || yMax === null) {
    const ys = [0];
    for (const c of fns) for (let i = 0; i <= 200; i++) { const x = x0 + (x1 - x0) * i / 200; const v = c.discrete ? c.f(Math.round(x)) : c.f(x); if (Number.isFinite(v)) ys.push(v); }
    for (const p of g.points) if (Number.isFinite(p.y)) ys.push(p.y);
    for (const l of g.hlines) ys.push(l.v);
    if (yMin === null) yMin = Math.min(...ys);
    if (yMax === null) yMax = Math.max(...ys) * 1.1 || 1;
  }
  if (!(yMax > yMin)) yMax = yMin + 1;
  const X = x => L + (x - x0) / (x1 - x0) * pw, Y = y => T + ph - (y - yMin) / (yMax - yMin) * ph;
  const inY = y => Number.isFinite(y) && y >= yMin - (yMax - yMin) * 1e-6 && y <= yMax + (yMax - yMin) * 1e-6;
  const s = [];
  const xt = ticks(x0, x1), yt = ticks(yMin, yMax);
  for (const t of xt) s.push(`<line class="grid" x1="${X(t)}" x2="${X(t)}" y1="${T}" y2="${T + ph}"/><text class="tick" direction="ltr" x="${X(t)}" y="${T + ph + 16}" text-anchor="middle">${fmt(t)}</text>`);
  for (const t of yt) s.push(`<line class="grid" x1="${L}" x2="${L + pw}" y1="${Y(t)}" y2="${Y(t)}"/><text class="tick" direction="ltr" x="${L - 6}" y="${Y(t) + 4}" text-anchor="end">${fmt(t)}</text>`);
  s.push(`<clipPath id="${clip}"><rect x="${L}" y="${T}" width="${pw}" height="${ph}"/></clipPath>`);
  // Areas first, under the lines.
  g.areas.filter(a => !a.bad).forEach((a, i) => {
    const N = 300, top = [], bot = [];
    const from = Math.max(a.from, x0), to = Math.min(a.to, x1);
    let polys = [], cur = null;
    const step = a.dist ? 1 : (to - from) / N;
    if (a.dist) {
      for (let k = Math.ceil(from); k <= to; k++) { const h = a.hi(k), l = a.lo(k); if (h > l) s.push(`<rect clip-path="url(#${clip})" x="${X(k) - 4}" y="${Y(h)}" width="8" height="${Y(l) - Y(h)}" class="area" fill="${COLORS[(i + 3) % COLORS.length]}"/>`); }
    } else {
      for (let k = 0; k <= N; k++) {
        const x = from + step * k, h = a.hi(x), l = a.lo(x);
        if (Number.isFinite(h) && Number.isFinite(l) && h > l) { if (!cur) { cur = { top: [], bot: [] }; polys.push(cur); } cur.top.push([x, h]); cur.bot.push([x, l]); }
        else cur = null;
      }
      for (const p of polys) s.push(`<polygon clip-path="url(#${clip})" class="area" fill="${COLORS[(i + 3) % COLORS.length]}" points="${[...p.top, ...p.bot.reverse()].map(([x, y]) => `${X(x).toFixed(1)},${Y(y).toFixed(1)}`).join(' ')}"/>`);
      if (a.name && polys.length) {
        // Inside the area when it is tall enough; otherwise just above it.
        const big = polys.reduce((m, p) => (p.top.length > m.top.length ? p : m));
        let k = 0; big.top.forEach(([, y], j) => { if (Y(y) - Y(big.bot[j][1]) < Y(big.top[k][1]) - Y(big.bot[k][1])) k = j; });
        const cx = big.top[Math.floor(big.top.length / 2)][0];
        const j = big.top.findIndex(([x]) => x >= cx);
        const ty = Y(big.top[j][1]), by = Y(big.bot[j][1]);
        const y = by - ty > 30 ? (ty + by) / 2 + 4 : Math.max(T + 12, Y(Math.max(...big.top.map(([, v]) => v))) - 10);
        s.push(`<text class="arealbl" x="${X(cx)}" y="${y}" text-anchor="middle" direction="rtl">${escx(a.name)}</text>`);
      }
    }
    if (a.name && a.dist) s.push(`<text class="arealbl" x="${X((from + to) / 2)}" y="${T + 14}" text-anchor="middle" direction="rtl">${escx(a.name)}</text>`);
  });
  s.push(`<line class="axis" x1="${L}" x2="${L + pw}" y1="${Y(Math.max(yMin, Math.min(0, yMax)))}" y2="${Y(Math.max(yMin, Math.min(0, yMax)))}"/><line class="axis" x1="${X(Math.max(x0, Math.min(0, x1)))}" x2="${X(Math.max(x0, Math.min(0, x1)))}" y1="${T}" y2="${T + ph}"/>`);
  const labels = [];
  fns.forEach((c, i) => {
    const color = COLORS[i % COLORS.length], dash = DASH[i % DASH.length];
    if (c.discrete) {
      for (let k = Math.ceil(x0); k <= x1; k++) { const v = c.f(k); if (!inY(v)) continue; s.push(`<line x1="${X(k)}" x2="${X(k)}" y1="${Y(Math.max(yMin, 0))}" y2="${Y(v)}" stroke="${color}" stroke-width="2"/><circle cx="${X(k)}" cy="${Y(v)}" r="3" fill="${color}"/>`); }
      labels.push({ name: c.name, color, x: X(x1), y: T + 10 });
      return;
    }
    const N = 400; let d = '', pen = false, last = null;
    for (let k = 0; k <= N; k++) {
      const x = x0 + (x1 - x0) * k / N, y = c.f(x);
      const ok = Number.isFinite(y) && Math.abs(y - yMin) < (yMax - yMin) * 20 && Math.abs(y - yMax) < (yMax - yMin) * 20;
      if (!ok) { pen = false; continue; }
      d += `${pen ? 'L' : 'M'}${X(x).toFixed(1)},${Y(y).toFixed(1)}`; pen = true;
      if (inY(y)) last = [x, y];
    }
    s.push(`<path clip-path="url(#${clip})" d="${d}" fill="none" stroke="${color}" stroke-width="2.2" stroke-dasharray="${dash}"/>`);
    if (g.dists.includes(c)) {
      let px = x0, pv = -Infinity;
      for (let k = 0; k <= 200; k++) { const x = x0 + (x1 - x0) * k / 200, v = c.f(x); if (v > pv) { pv = v; px = x; } }
      if (inY(pv)) s.push(`<text class="curve" x="${X(px) + 10}" y="${Y(pv) + 4}" fill="${color}" direction="rtl" text-anchor="end">${escx(c.name)}</text>`);
    } else if (last) labels.push({ name: c.name, color, x: X(last[0]) + 6, y: Y(last[1]) });
  });
  for (const l of g.hlines) { if (!inY(l.v)) continue; s.push(`<line class="ref" x1="${L}" x2="${L + pw}" y1="${Y(l.v)}" y2="${Y(l.v)}"/>`); if (l.name) labels.push({ name: `${l.name} (${fmt(l.v)})`, color: '#555', x: L + pw + 6, y: Y(l.v) }); }
  for (const l of g.vlines) { if (l.v < x0 || l.v > x1) continue; s.push(`<line class="ref" x1="${X(l.v)}" x2="${X(l.v)}" y1="${T}" y2="${T + ph}"/>`); if (l.name) s.push(`<text class="reflbl" x="${X(l.v)}" y="${T - 6}" text-anchor="middle" direction="rtl">${escx(l.name)} (${fmt(l.v)})</text>`); }
  for (const p of g.points) {
    if (p.bad || !Number.isFinite(p.x) || !Number.isFinite(p.y) || p.x < x0 || p.x > x1 || !inY(p.y)) continue;
    s.push(`<line class="drop" x1="${X(p.x)}" x2="${X(p.x)}" y1="${Y(p.y)}" y2="${Y(Math.max(yMin, Math.min(0, yMax)))}"/><line class="drop" x1="${X(p.x)}" x2="${X(Math.max(x0, Math.min(0, x1)))}" y1="${Y(p.y)}" y2="${Y(p.y)}"/>`);
    s.push(`<circle cx="${X(p.x)}" cy="${Y(p.y)}" r="4.5" fill="#111"/>`);
    s.push(`<text class="pt" x="${X(p.x) + 8}" y="${Y(p.y) - 8}" direction="rtl" text-anchor="end">${escx(p.name ? `${p.name} ` : '')}<tspan direction="ltr" unicode-bidi="embed">(${fmt(p.x)}, ${fmt(p.y)})</tspan></text>`);
  }
  // Labels at the right edge, nudged apart so they never overlap.
  labels.sort((a, b) => a.y - b.y);
  for (let i = 1; i < labels.length; i++) if (labels[i].y - labels[i - 1].y < 15) labels[i].y = labels[i - 1].y + 15;
  for (const l of labels) s.push(`<text class="curve" x="${L + pw + 6}" y="${l.y + 4}" fill="${l.color}" direction="rtl" text-anchor="end">${escx(l.name)}</text>`);
  return wrap(g, s, W, H, L, T, pw, ph);
}

function wrap(g, s, W, H, L, T, pw, ph) {
  const head = [];
  if (g.x && g.x.label) head.push(`<text class="axlbl" x="${L + pw / 2}" y="${H - 10}" text-anchor="middle" direction="rtl">${escx(g.x.label)}</text>`);
  if (g.y && g.y.label) head.push(`<text class="axlbl" x="6" y="${T - 16}" text-anchor="end" direction="rtl">${escx(g.y.label)}</text>`);
  const svg = `<svg class="g" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${escx(g.title || 'גרף')}" dir="ltr">${s.join('')}${head.join('')}</svg>`;
  const cap = g.title ? `<figcaption>${escx(g.title)}</figcaption>` : '';
  return { html: `${svg}${cap}`, errors: g.errors, warnings: g.warnings };
}
