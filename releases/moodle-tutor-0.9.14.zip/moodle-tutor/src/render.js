// Turns a chapter the tutor wrote (a small subset of Markdown, LaTeX formulas, graph blocks and
// source notes) into HTML for the printed booklet. Pure: the formula and graph renderers are passed in,
// so the same code runs in the page and in the tests.

const SECTION_CLASS = { 'אינטואיציה': 'intuition', 'הגדרות': 'defs', 'דוגמה פתורה': 'example', 'טעויות נפוצות': 'mistakes', 'בדיקה עצמית': 'check', 'נוסחאות ומשפטים': 'formulas', 'מתי משתמשים': 'when', 'דגשים': 'stress' };
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// math(tex, display) -> html; graph(lines) -> html. Defaults show the source as text.
export function renderChapter(body, { math = (t, d) => `<code class="tex${d ? ' d' : ''}">${esc(t)}</code>`, graph = lines => `<pre class="graph-src">${esc(lines.join('\n'))}</pre>` } = {}) {
  const notes = [];
  const inline = text => {
    // Formulas and source notes are cut out first, so the other marks never touch them.
    const keep = [];
    const hold = html => `\u0000${keep.push(html) - 1}\u0000`;
    let t = String(text);
    // The same source twice gets the same number.
    t = t.replace(/\[מקור:\s*([^\]]+)\]/g, (_, src) => { const k = src.trim(); let n = notes.indexOf(k) + 1; if (!n) n = notes.push(k); return hold(`<sup class="fn">${n}</sup>`); });
    t = t.replace(/\$\$([^$]+)\$\$/g, (_, tex) => hold(math(tex.trim(), true)));
    t = t.replace(/\$([^$\n]+)\$/g, (_, tex) => hold(`<span class="m" dir="ltr">${math(tex.trim(), false)}</span>`));
    t = t.replace(/`([^`]+)`/g, (_, c) => hold(`<code dir="ltr">${esc(c)}</code>`));
    t = esc(t);
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<em>$2</em>');
    return t.replace(/\u0000(\d+)\u0000/g, (_, i) => keep[+i]);
  };

  const out = [];
  const lines = String(body || '').replace(/\r/g, '').split('\n');
  let list = null, section = false;
  const closeList = () => { if (list) { out.push(`</${list}>`); list = null; } };
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const l = raw.trim();
    // Code and graph blocks.
    const fence = l.match(/^```\s*([^\s`]*)\s*$/);
    if (fence) {
      closeList();
      const end = lines.findIndex((x, k) => k > i && /^\s*```\s*$/.test(x));
      const inner = lines.slice(i + 1, end < 0 ? lines.length : end);
      if (/^(גרף|graph)$/i.test(fence[1])) out.push(`<figure class="graph">${graph(inner.map(x => x.trim()).filter(Boolean))}</figure>`);
      else out.push(`<pre dir="ltr"><code>${esc(inner.join('\n'))}</code></pre>`);
      i = end < 0 ? lines.length : end;
      continue;
    }
    // A displayed formula: on one line, or between two $$ lines.
    if (/^\$\$/.test(l)) {
      closeList();
      let tex = l.slice(2), end = i;
      if (/\$\$$/.test(tex) && tex.length > 2) tex = tex.slice(0, -2);
      else { const e = lines.findIndex((x, k) => k > i && /\$\$\s*$/.test(x)); end = e < 0 ? i : e; tex = [tex, ...lines.slice(i + 1, end + 1)].join('\n').replace(/\$\$\s*$/, ''); }
      out.push(`<div class="formula" dir="ltr">${math(tex.trim(), true)}</div>`);
      i = end;
      continue;
    }
    if (!l) { closeList(); continue; }
    if (/^-{3,}$/.test(l)) { closeList(); continue; }
    // Tables: a header row, a separator row, then rows.
    if (l.startsWith('|') && i + 1 < lines.length && /^\|?\s*:?-{3,}/.test(lines[i + 1].trim())) {
      closeList();
      const cells = r => r.trim().replace(/^\||\|$/g, '').split('|').map(c => inline(c.trim()));
      const head = cells(l);
      const rows = [];
      let k = i + 2;
      while (k < lines.length && lines[k].trim().startsWith('|')) rows.push(cells(lines[k++]));
      out.push(`<table><thead><tr>${head.map(c => `<th>${c}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table>`);
      i = k - 1;
      continue;
    }
    const h = l.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      closeList();
      // A "##" heading opens a section; the known ones get their own look (examples, mistakes...).
      if (h[1].length === 2) {
        if (section) out.push('</section>');
        const kind = Object.entries(SECTION_CLASS).find(([k]) => h[2].replace(/\*/g, '').trim().startsWith(k));
        out.push(`<section class="sec${kind ? ` sec-${kind[1]}` : ''}">`);
        section = true;
      }
      const lvl = Math.min(6, h[1].length + 1); out.push(`<h${lvl}>${inline(h[2])}</h${lvl}>`); continue;
    }
    const ul = l.match(/^[-*+]\s+(.*)$/);
    const ol = l.match(/^\d+[.)]\s+(.*)$/);
    if (ul || ol) {
      const kind = ul ? 'ul' : 'ol';
      if (list !== kind) { closeList(); out.push(`<${kind}>`); list = kind; }
      out.push(`<li>${inline((ul || ol)[1])}</li>`);
      continue;
    }
    closeList();
    if (/^>\s?/.test(l)) { out.push(`<blockquote>${inline(l.replace(/^>\s?/, ''))}</blockquote>`); continue; }
    out.push(`<p${/^כאשר/.test(l) ? ' class="where"' : ''}>${inline(l)}</p>`);
  }
  closeList();
  if (section) out.push('</section>');
  if (notes.length) out.push(`<ol class="notes">${notes.map(n => `<li>${esc(n)}</li>`).join('')}</ol>`);
  return out.join('\n');
}

// A study chapter's answers go to the end of the booklet, so the reader tries the questions first.
export function splitAnswers(body) {
  const lines = String(body || '').split('\n');
  const at = lines.findIndex(l => /^#{2,3}\s*תשובות/.test(l.trim()));
  if (at < 0) return { main: body, answers: '' };
  const rest = lines.slice(at + 1);
  const next = rest.findIndex(l => /^#{1,3}\s/.test(l.trim()));
  const answers = (next < 0 ? rest : rest.slice(0, next)).join('\n').trim();
  const main = [...lines.slice(0, at), ...(next < 0 ? [] : rest.slice(next))].join('\n').trim();
  return { main, answers };
}
