// The course booklets: a study booklet (a chapter per topic, taught from zero) and a summary booklet
// (formulas, principles, when to use what). The tutor writes each chapter inside the chat, in a marked
// block; the extension reads it from the conversation (like the session summaries), keeps it, and
// shows both booklets on a page made for printing.

import { parseGraph } from './graph.js';

export const BOOKS = {
  study: { label: 'חוברת עזר לימודית', short: 'עזר', file: 'חוברת עזר לימודית' },
  summary: { label: 'חוברת סיכום ועקרונות', short: 'סיכום', file: 'חוברת סיכום ועקרונות' },
};

// The sections every chapter must have, in this order.
export const SECTIONS = {
  study: ['אינטואיציה', 'הגדרות', 'דוגמה פתורה', 'טעויות נפוצות', 'בדיקה עצמית', 'תשובות'],
  summary: ['נוסחאות ומשפטים', 'מתי משתמשים בכל כלי'],
};

const START = /^[ \t]*#{1,4}[ \t]*\**[ \t]*פרק[ \t]+לחוברת[ \t]*\**[ \t]*$/;
const CONT = /^[ \t]*#{1,4}[ \t]*\**[ \t]*המשך[ \t]+פרק[ \t]*\**[ \t]*$/;
const END = /^[ \t]*#{1,4}[ \t]*\**[ \t]*סוף[ \t]+פרק[ \t]*\**[ \t]*$/;
const HEAD = /^[ \t]*\**[ \t]*(חוברת|נושא|מקורות)[ \t]*\**[ \t]*:[ \t]*\**[ \t]*(.*?)[ \t]*\**[ \t]*$/;

function header(lines) {
  const h = {};
  let i = 0;
  for (; i < lines.length; i++) {
    const l = lines[i];
    if (!l.trim()) { if (Object.keys(h).length) { i++; break; } continue; }
    if (/^[ \t]*-{3,}[ \t]*$/.test(l)) { i++; break; }
    const m = l.match(HEAD);
    if (!m) break;
    h[m[1]] = m[2];
  }
  return { h, body: lines.slice(i).join('\n').trim() };
}

const bookOf = v => /סיכום|עקרונות/.test(v || '') ? 'summary' : /עזר|לימוד/.test(v || '') ? 'study' : null;

// One message from the tutor. Returns the complete chapters in it; `open` is a chapter that started but
// was cut (no end line); `tail` is text that finishes a chapter cut in an earlier message.
export function parseChapters(text) {
  const lines = String(text || '').replace(/\r/g, '').split('\n');
  const chapters = [];
  let open = null, tail = null, cur = null;
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (CONT.test(l) && !cur && tail === null) { cur = { cont: true, lines: [] }; continue; }
    if (START.test(l)) { if (cur && !cur.cont) open = cur.lines.join('\n'); cur = { lines: [] }; continue; }
    if (END.test(l) && cur) {
      if (cur.cont) tail = cur.lines.join('\n');
      else { const c = toChapter(cur.lines); if (c) chapters.push(c); }
      cur = null;
      continue;
    }
    if (cur) cur.lines.push(l);
  }
  if (cur && !cur.cont) open = cur.lines.join('\n');
  // The tutor may wrap the whole block in a code fence; a fence line around the block is not content.
  return { chapters, open: open && /\S/.test(open) ? open : null, tail };
}

function toChapter(lines) {
  const strip = lines.slice();
  while (strip.length && !strip[0].trim()) strip.shift();
  while (strip.length && !strip.at(-1).trim()) strip.pop();
  // A block the tutor wrapped in a code fence: the fence lines around it are not content.
  if (strip.length > 1 && /^\s*```(\w*|markdown|md)\s*$/.test(strip[0]) && !/גרף/.test(strip[0]) && /^\s*```\s*$/.test(strip.at(-1))) { strip.shift(); strip.pop(); }
  const { h, body } = header(strip);
  const book = bookOf(h['חוברת']);
  const topic = (h['נושא'] || '').trim();
  if (!book || !topic || !body || /^(\.\.\.|שם הנושא)$/.test(topic)) return null;
  const sources = (h['מקורות'] || '').split(/[;؛]/).map(s => s.trim()).filter(s => s && !/^(אין|—|-|\.\.\.)$/.test(s));
  return { book, topic, sources, body };
}

// A chapter cut at the end of one message, finished by the next one ("### המשך פרק").
export function joinCut(open, tail) {
  return toChapter(`${open}\n${tail}`.split('\n'));
}

// ---------- Checks ----------

const HEB = /[א-ת]/;
const STRONG = /[A-Za-zͰ-Ͽא-ת0-9$\\]/;
// Phrases that send the reader to the course materials or assume they were there.
const OUTSIDE = [/ראה\s+שקף/, /בשקף/, /בשקפים/, /במצגת/, /כפי\s+שראינו/, /כמו\s+שראינו/, /שראינו\s+ב/, /בהרצאה\s+(הקודמת|האחרונה|שעברה)/, /כפי\s+שהמרצה/, /כמו\s+שהמרצה/, /ראו?\s+(בקובץ|בתרגול|בהרצאה)/, /בתרגול\s+(הקודם|האחרון)/, /כמו\s+בתרגול/, /לפי\s+השקף/, /בעמוד\s+\d+\s+של/, /כפי\s+שלמדנו/, /כמו\s+שלמדנו/, /כזכור/];
const DEFINES = /(\s|^)(הוא|היא|הם|הן|פירושו|פירושה|מוגדר|מוגדרת|מוגדרים|נקרא|נקראת|נקראים|מתאר|מתארת|מודד|מודדת|זה\s+ש|כלומר)(\s|$|,)|:|—|–| - /;
const GREEK = 'alpha|beta|gamma|delta|epsilon|varepsilon|zeta|eta|theta|vartheta|iota|kappa|lambda|mu|nu|xi|pi|rho|sigma|tau|upsilon|phi|varphi|chi|psi|omega|Gamma|Delta|Theta|Lambda|Xi|Pi|Sigma|Phi|Psi|Omega';
const GREEK_RE = new RegExp(`\\\\(${GREEK})(?![a-zA-Z])`, 'g');
const GREEK_CHARS = { 'α': 'alpha', 'β': 'beta', 'γ': 'gamma', 'δ': 'delta', 'ε': 'epsilon', 'θ': 'theta', 'λ': 'lambda', 'μ': 'mu', 'σ': 'sigma', 'ρ': 'rho', 'π': 'pi', 'τ': 'tau', 'φ': 'phi', 'χ': 'chi', 'ω': 'omega', 'Δ': 'Delta', 'Σ': 'Sigma' };
const FUNCS = new Set(['sin', 'cos', 'tan', 'log', 'ln', 'exp', 'max', 'min', 'lim', 'sum', 'prod', 'int', 'frac', 'cdot', 'times', 'left', 'right', 'text', 'mathrm', 'operatorname', 'sqrt', 'bar', 'hat', 'tilde', 'mathbb', 'mathbf', 'leq', 'geq', 'neq', 'approx', 'infty', 'partial', 'quad', 'qquad', 'mid', 'Pr', 'det', 'dfrac', 'tfrac', 'binom', 'ldots', 'cdots', 'dots', 'to', 'rightarrow', 'Rightarrow', 'iff', 'in', 'sim', 'pm', 'overline', 'underline', 'displaystyle', 'begin', 'end', 'cases', 'le', 'ge', 'ne', 'cup', 'cap', 'subset', 'forall', 'exists', 'Var', 'Cov']);

// The symbols a formula uses: single letters and Greek letters (a name like "Var" or "\text{...}" is not one).
export function symbolsOf(tex) {
  const out = new Set();
  let t = String(tex).replace(/\\(text|mathrm|operatorname)\s*\{[^}]*\}/g, ' ').replace(/\\[,;:! ]/g, ' ');
  // Operators, not symbols: Δ before a quantity ("ΔQ" is "the change in Q"), E and P before brackets,
  // and the d of a derivative (dπ/dq, d^2π).
  t = t.replace(/(\\Delta|Δ)\s*(?=[A-Za-z\\{(])/g, ' ').replace(/\b([EP])\s*(?=[(\[]|\\left)/g, ' ');
  t = t.replace(/(^|[^A-Za-z\\])d(\^\{?\d\}?)?\s*(?=\\[A-Za-z]|[A-Za-z](?![A-Za-z])|[A-Z]{2,6}(?![A-Za-z])|\[)/g, '$1 ');
  // A letter label on a symbol (Q^S, q^d, Q^D) is part of its name.
  t = t.replace(/([A-Za-z])\s*\^\s*\{?\s*([A-Za-z])\s*\}?(?![A-Za-z{])/g, (_, a, b) => { out.add(`${a}^${b}`); return ' '; });
  for (const [ch, name] of Object.entries(GREEK_CHARS)) if (t.includes(ch)) out.add(name);
  t = t.replace(GREEK_RE, (_, g) => { out.add(g); return ' '; });
  t = t.replace(/\\[A-Za-z]+/g, ' ');
  for (const m of t.matchAll(/[A-Za-z]+/g)) {
    const w = m[0];
    if (FUNCS.has(w)) continue;
    if (w.length === 1) out.add(w);
    else if (/^(Var|Cov|Corr|max|min|arg|argmax|argmin|exp|log|ln|lim|sup|inf|plim)$/.test(w)) continue;
    // An abbreviation in capitals (TC, MC, AVC, MRTS) is one name; lower-case letters side by side are a product.
    else if (/^[A-Z]{2,6}$/.test(w)) out.add(w);
    else for (const c of w) out.add(c);
  }
  return out;
}

const CHAR_OF = { alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', epsilon: 'ε', varepsilon: 'ε', zeta: 'ζ', eta: 'η', theta: 'θ', vartheta: 'θ', iota: 'ι', kappa: 'κ', lambda: 'λ', mu: 'μ', nu: 'ν', xi: 'ξ', pi: 'π', rho: 'ρ', sigma: 'σ', tau: 'τ', upsilon: 'υ', phi: 'φ', varphi: 'φ', chi: 'χ', psi: 'ψ', omega: 'ω', Gamma: 'Γ', Delta: 'Δ', Theta: 'Θ', Lambda: 'Λ', Xi: 'Ξ', Pi: 'Π', Sigma: 'Σ', Phi: 'Φ', Psi: 'Ψ', Omega: 'Ω' };
const shown = s => CHAR_OF[s] || s;
// A Greek letter named in Hebrew words ("והחזקות אלפא ובטא") is explained too.
const HEB_GREEK = [['אלפא', 'alpha'], ['בטא', 'beta'], ['גמא', 'gamma'], ['דלתא', 'delta'], ['אפסילון', 'epsilon'], ['תטא', 'theta'], ['למדא', 'lambda'], ['למבדה', 'lambda'], ['סיגמא', 'sigma'], ['סיגמה', 'sigma'], ['פאי', 'pi'], ['טאו', 'tau'], ['אומגה', 'omega'], ['פסי', 'psi'], ['כי בריבוע', 'chi'], ['ניו', 'nu'], ['קסי', 'xi'], ['זטא', 'zeta'], ['אטא', 'eta'], ['רו', 'rho'], ['מיו', 'mu'], ['פי', 'phi']];

// Every line a reader sees as a line: lists, headings and table cells count; code, graphs and display
// formulas do not.
function proseLines(body) {
  const out = [];
  let fence = false, math = false;
  body.split('\n').forEach((raw, i) => {
    const l = raw.trim();
    if (/^```/.test(l)) { fence = !fence; return; }
    if (fence) return;
    if (/^\$\$/.test(l)) { if (!(l.length > 2 && /\$\$$/.test(l.slice(2)))) math = !math; return; }
    if (math || !l) return;
    if (/^\|?\s*:?-{3,}/.test(l)) return;
    const cells = l.startsWith('|') ? l.split('|').map(c => c.trim()).filter(Boolean) : [l];
    for (const c of cells) out.push({ n: i + 1, text: c });
  });
  return out;
}

// The text a reader starts reading: without list marks, heading marks, bold, quotes and footnotes.
const lead = s => s.replace(/^(#{1,6}\s+|[-*+]\s+|\d+[.)]\s+|>\s*)+/, '').replace(/\*\*|__|\*|`/g, '').replace(/\[מקור:[^\]]*\]/g, '').replace(/^["'“”„(«\s]+/, '');

export function lintChapter(ch) {
  const issues = [];
  const add = (code, line, text) => issues.push({ code, line, text });
  const body = ch.body || '';
  // 1. Direction: a line that starts or ends in a Latin or Greek letter, a digit or a formula flips.
  for (const { n, text } of proseLines(body)) {
    const t = lead(text);
    const first = (t.match(STRONG) || [])[0];
    if (first && !HEB.test(first)) add('rtl-start', n, `שורה שמתחילה ב־"${t.slice(0, 24)}"`);
    const noNotes = text.replace(/\[מקור:[^\]]*\]/g, '').replace(/[\s.,;:!?)"'”»\]*]+$/, '');
    const last = [...noNotes].reverse().find(c => /[A-Za-zͰ-Ͽא-ת$]/.test(c));
    if (last && !HEB.test(last) && HEB.test(noNotes)) add('rtl-end', n, `שורה שמסתיימת ב־"${noNotes.slice(-24)}"`);
  }
  // 2. The chapter stands on its own: no "as we saw in the lecture".
  body.split('\n').forEach((l, i) => {
    const t = l.replace(/\[מקור:[^\]]*\]/g, '');
    for (const re of OUTSIDE) { const m = t.match(re); if (m) { add('outside', i + 1, `"${m[0]}" שולח את הקורא לחומרי הקורס`); break; } }
  });
  // 3. A bold term is explained where it first appears.
  const seen = new Set();
  for (const { n, text } of proseLines(body)) {
    if (/^#{1,6}\s/.test(text)) continue;
    for (const m of text.matchAll(/\*\*([^*]+)\*\*/g)) {
      const term = m[1].trim().replace(/[:.]$/, '');
      // Bold as a label, not a term: a line that is only the bold text, a whole sentence, or a long phrase.
      if (lead(text).replace(/[:.\s]+$/, '') === term || /[.:]$/.test(m[1].trim()) || term.split(/\s+/).length > 4) continue;
      if (seen.has(term) || term.length > 40) continue;
      seen.add(term);
      if (!DEFINES.test(text.replace(m[0], ' '))) add('term', n, `המונח "${term}" מופיע בפעם הראשונה בלי הסבר`);
    }
  }
  // 3b. An abbreviation (SAVC, MR) is explained where the reader first meets it, not only after a formula later on.
  {
    const met = new Set();
    for (const { n, text } of proseLines(body)) {
      for (const m of text.matchAll(/(?<![A-Za-z])([A-Z]{2,6})(?![A-Za-z])/g)) {
        const ab = m[1];
        if (met.has(ab)) continue;
        met.add(ab);
        if (!DEFINES.test(text) && !/^כאשר/.test(lead(text))) add('abbr', n, `הקיצור ${ab} מופיע בפעם הראשונה בלי הסבר`);
      }
    }
  }
  // 4. Every symbol in a displayed formula is explained, in a "כאשר" line after it, once per chapter.
  const explained = new Set();
  // A "כאשר" line explains the symbols in it, and Greek letters named in Hebrew words.
  const explain = line => { for (const x of symbolsOf(line.replace(/[\u05d0-\u05ea]+/g, ' '))) explained.add(x); for (const [heb, name] of HEB_GREEK) if (line.includes(heb)) explained.add(name); };
  const lines = body.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i].trim();
    if (/^כאשר/.test(lead(l))) explain(l);
    // A definition in a sentence ("**הפדיון**, $R$: ...") explains the symbols written in it.
    else if (!/^\$\$/.test(l) && /\$[^$]+\$/.test(l) && DEFINES.test(l.replace(/\$[^$]*\$/g, ' '))) for (const m of l.matchAll(/\$([^$]+)\$/g)) explain(m[1]);
    if (!/^\$\$/.test(l)) continue;
    let tex = l.replace(/^\$\$/, '');
    let j = i;
    if (!/\$\$$/.test(tex) || tex === '') { const end = lines.findIndex((x, k) => k > i && /\$\$\s*$/.test(x)); if (end < 0) { add('math', i + 1, 'נוסחה שלא נסגרה ב־$$'); continue; } tex = lines.slice(i + 1, end + 1).join(' '); j = end; }
    tex = tex.replace(/\$\$\s*$/, '');
    const syms = [...symbolsOf(tex)];
    // The sentence that introduces the formula ("לפירמה העלות היא:") names what the formula defines.
    let pv = i - 1;
    while (pv >= 0 && !lines[pv].trim()) pv--;
    if (pv >= 0 && /:\s*$/.test(lines[pv].trim())) {
      for (const m of lines[pv].matchAll(/\$([^$]+)\$/g)) explain(m[1]);
      for (const [heb, name] of HEB_GREEK) if (lines[pv].includes(heb)) explained.add(name);
      const lhs = tex.split(/=|\\le|\\ge|<|>/)[0];
      if (lhs !== tex) for (const x of symbolsOf(lhs)) explained.add(x);
    }
    // Look ahead: the "כאשר" lines right after the formula count.
    let k = j + 1;
    while (k < lines.length && !lines[k].trim()) k++;
    while (k < lines.length && /^כאשר|^[-*]\s/.test(lead(lines[k].trim())) && !/^#/.test(lines[k].trim())) {
      if (/^כאשר/.test(lead(lines[k].trim())) || /^[-*]\s/.test(lines[k].trim())) explain(lines[k]);
      k++;
    }
    const known = new Set([...explained].map(shown));
    const missing = syms.filter(s => !explained.has(s) && !known.has(shown(s)));
    if (missing.length) add('formula', i + 1, `בנוסחה יש סמלים בלי הסבר ב"כאשר": ${missing.map(shown).join(', ')}`);
    i = j;
  }
  // 5. Graphs: the description can be drawn, and says what the reader is looking at.
  {
    const ls = body.split('\n');
    for (let i = 0; i < ls.length; i++) {
      if (!/^\s*```\s*(גרף|graph)\s*$/i.test(ls[i])) continue;
      const end = ls.findIndex((x, k) => k > i && /^\s*```\s*$/.test(x));
      let g;
      try { g = parseGraph(ls.slice(i + 1, end < 0 ? ls.length : end)); } catch (e) { g = { errors: [e.message], warnings: [] }; }
      for (const e of [...g.errors, ...g.warnings]) add('graph', i + 1, e);
      if (end < 0) { add('graph', i + 1, 'בלוק הגרף לא נסגר'); break; }
      i = end;
    }
  }
  // 6. The fixed sections.
  const heads = body.split('\n').filter(l => /^#{2,3}\s/.test(l.trim())).map(l => l.replace(/^#+\s*/, '').trim());
  for (const s of SECTIONS[ch.book] || []) if (!heads.some(h => h.startsWith(s))) add('section', 0, `חסר החלק "${s}"`);
  if (ch.book === 'study' && body.replace(/\s+/g, ' ').length < 600) add('short', 0, 'הפרק קצר מכדי ללמד נושא מאפס');
  return issues;
}

export const ISSUE_LABEL = {
  'rtl-start': 'כיוון: שורה שמתחילה שלא בעברית', 'rtl-end': 'כיוון: שורה שמסתיימת שלא בעברית', outside: 'הפניה לחומרי הקורס',
  term: 'מונח בלי הסבר', abbr: 'קיצור בלי הסבר', formula: 'נוסחה בלי הסבר לסמלים', math: 'נוסחה שבורה', section: 'חלק חסר', short: 'פרק קצר', graph: 'גרף שלא צויר',
};

// ---------- Keeping the chapters ----------

const norm = s => String(s || '').replace(/["'״׳]/g, '').replace(/\s+/g, ' ').trim();

// booklet: { study: [chapter...], summary: [...], open: {text, at} | null }. A chapter on a topic that is
// already there replaces it in place; a new topic goes at the end.
export function addChapters(booklet, chapters, when = new Date(), from = '') {
  const b = { study: [...((booklet && booklet.study) || [])], summary: [...((booklet && booklet.summary) || [])], open: (booklet && booklet.open) || null };
  const date = when.toISOString().slice(0, 10);
  for (const c of chapters) {
    const list = b[c.book];
    const entry = { topic: c.topic, sources: c.sources || [], body: c.body, date, from, issues: lintChapter(c) };
    const at = list.findIndex(x => norm(x.topic) === norm(c.topic));
    if (at >= 0) list[at] = { ...entry, first: list[at].first || list[at].date }; else list.push({ ...entry, first: date });
  }
  return b;
}

// Reads one tutor message into the booklet: whole chapters, a chapter cut at its end, or the rest of a
// chapter cut in an earlier message.
export function takeMessage(booklet, text, when = new Date(), from = '') {
  const { chapters, open, tail } = parseChapters(text);
  let b = booklet || { study: [], summary: [], open: null };
  const found = [...chapters];
  if (tail !== null && b.open) { const c = joinCut(b.open.text, tail); if (c) found.unshift(c); b = { ...b, open: null }; }
  if (!found.length && !open && tail === null) return { booklet: booklet, added: 0, cut: false };
  b = addChapters(b, found, when, from);
  if (open) b.open = { text: open, at: when.toISOString() };
  return { booklet: b, added: found.length, cut: !!open };
}

// The summary booklet as a project file: the tutor can lean on it in every conversation.
export function summaryDoc(courseName, booklet) {
  const L = [`# ${BOOKS.summary.label}: ${courseName}`, '', 'התוסף כותב את הקובץ מחדש מהפרקים שהמורה כותב בשיחות.'];
  for (const c of (booklet && booklet.summary) || []) L.push('', `## ${c.topic}`, '', c.body.replace(/^(#{1,4})\s/gm, (_, h) => `${'#'.repeat(Math.min(h.length + 1, 6))} `));
  return L.join('\n') + '\n';
}

// ---------- What the tutor is told ----------

export const GRAPH_SYNTAX = [
  'כותרת: היצע וביקוש לעבודה',
  'ציר אופקי: כמות עבודה, 0 עד 100',
  'ציר אנכי: שכר, 0 עד 50',
  'עקומה: היצע = 0.3*x + 10',
  'עקומה: ביקוש = 45 - 0.25*x',
  'נקודה: שיווי משקל = חיתוך היצע וביקוש',
  'קו אופקי: שכר מינימום = 35',
  'קו אנכי: תעסוקה בשכר מינימום = 40',
  'אזור: אובדן רווחה = בין היצע לביקוש, מ־40 עד שיווי משקל',
];
export function bookletInstructions() {
  const L = [];
  L.push('חוברות הקורס:');
  L.push('- לקורס יש שתי חוברות שהתוסף מרכיב מפרקים שאתה כותב: "חוברת עזר לימודית" ו"חוברת סיכום ועקרונות". אני מדפיס אותן ולומד מהן בלי חומרי הקורס לידי.');
  L.push('- בסוף כל נושא חדש שלמדנו שואלים במשפט אחד אם להוסיף פרק לחוברת. אם אמרתי כן, או כשאני כותב "פרק לחוברת", כותבים שני בלוקים על אותו נושא: אחד לחוברת העזר ואחד לחוברת הסיכום.');
  L.push('- פרק על נושא שכבר יש לו פרק מחליף אותו, ולכן בעדכון כותבים את הפרק כולו מחדש, עם אותו שם נושא בדיוק.');
  L.push('- הפרקים נכתבים בתוך ההודעה עצמה, ולא בקובץ, במסמך נפרד או בחלון צד. התוסף קורא רק את טקסט ההודעה.');
  L.push('- אם ההודעה נקטעה באמצע פרק, כשאכתוב "המשך" ממשיכים בדיוק מהמקום שבו נקטע, בבלוק שמתחיל בשורה "### המשך פרק" ונגמר בשורה "### סוף פרק".');
  L.push('- הקורא לא ראה את ההרצאות ואין לידו את חומרי הקורס. כל מונח מודגש בפעם הראשונה שהוא מופיע, ובאותו משפט מוסבר מה הוא. לא כותבים "כפי שראינו", "בשקף", "בהרצאה הקודמת", "כזכור" או "ראה קובץ".');
  L.push('- מקור מופיע רק בשורת "מקורות" של הפרק, או בהערה בסוף משפט בצורה [מקור: הרצאה 3, עמ׳ 12]. הקריאה לא תלויה בו. עמוד מציינים רק כשבטוחים שהדבר מופיע בו, ואחרת רק את שם הקובץ.');
  L.push('- טענה שנכונה רק בתנאים מסוימים נכתבת יחד עם התנאים, גם באינטואיציה ובחוברת הסיכום. למשל לא "בטווח הארוך הביקוש לא משפיע על המחיר", אלא "בענף של עלויות קבועות, בטווח הארוך הביקוש לא משפיע על המחיר".');
  L.push('- דוגמה או מספר שלא מופיעים בחומרי הקורס מסומנים במילים "דוגמה שלי", כדי שאדע מה מהקורס ומה לא.');
  L.push('- בחלק ההגדרות, כל מונח בא יחד עם הסמל או הקיצור שלו ועם פירוש האותיות. למשל: "העלות המשתנה הממוצעת בטווח הקצר, SAVC: האות S מציינת טווח קצר". מונח מקצועי שלא שייך לנושא, כמו "מונופול" או "פונקציית ייצור", מוסבר בחצי משפט במקום שבו הוא מופיע, או שלא משתמשים בו.');
  L.push('- כל כלל בא עם הסיבה שלו במשפט או שניים. למשל לא רק "העלות השולית חותכת את הממוצעת במינימום שלה", אלא גם למה.');
  L.push('- בגזירה ובדוגמה פתורה כותבים כל מעבר, גם צעד אלגברי פשוט כמו היפוך פונקציה או פתרון משוואה. מספר שמופיע בתשובה מופיע יחד עם החישוב שהוביל אליו.');
  L.push('- כששינוי מזיז עקומה, כותבים לאיזה כיוון היא זזה, למה, ומה קורה למחיר ולכמות. מקרה הפוך, כמו ירידה במקום עלייה, מוזכר במשפט. ברשימה של גורמים שמזיזים עקומה, לכל גורם כתוב הכיוון, וכל מונח בה מוסבר.');
  L.push('- דוגמה שלי עקבית עם הנוסחאות של הפרק. אם היא משנה הנחה, כותבים במפורש מה שונה ולמה. לפני שליחה בודקים שכל מספר בדוגמה נובע מהנוסחאות שבה.');
  L.push('- גרף שהטקסט מתאר מופיע גם כבלוק גרף, כולל מקרים שונים, למשל רווח והפסד. שני גרפים שמסבירים יחד, כמו פירמה ושוק, נכתבים כשני בלוקים זה אחרי זה, עם משפט שמקשר ביניהם. כשהגרף משתמש בפונקציה ההפוכה לזו שבטקסט, כמו מחיר כפונקציה של כמות, כותבים זאת במשפט לפני הגרף.');
  L.push('- נוסחה עומדת בשורה משלה, בין $$ לבין $$, בכתיב של LaTeX. מיד אחריה באה שורה שמתחילה במילה "כאשר" ומסבירה במילים כל סמל שעוד לא הוסבר בפרק. משתנה בודד באמצע משפט נכתב בין $ לבין $.');
  L.push('- כללי הכיוון שלמעלה חלים על כל שורה בפרק, גם על כותרות, פריטים ברשימה ותאים בטבלה.');
  L.push('- גרף מתארים בבלוק "גרף", והתוסף מצייר אותו. כל שורה היא סוג ונקודתיים. עקומה היא ביטוי במשתנה x, עם * לכפל ו־^ לחזקה. בהתפלגות כותבים נורמלית(ממוצע, סטיית תקן), בינומית(n, p), פואסון(קצב) או מעריכית(קצב). בעמודות כותבים שם = ערך, מופרדים בנקודה־פסיק. נקודה היא (x, y), או "חיתוך" של שתי עקומות. אזור הוא "בין" שתי עקומות, או "מתחת" לעקומה, ואפשר להגביל אותו ב"מעל" קו, "מתחת" לקו, או "מ־a עד b", כש־a ו־b הם מספרים או שמות של נקודות. הגרף נכתב בבלוק קוד שהשורה הראשונה שלו היא שלוש גרשיים הפוכים והמילה גרף, למשל:');
  for (const l of GRAPH_SYNTAX) L.push(`  ${l}`);
  L.push('- פרק בחוברת העזר מלמד את הנושא מאפס, עם החלקים האלה בדיוק, ככותרות ##, בסדר הזה: אינטואיציה, הגדרות, דוגמה פתורה, טעויות נפוצות, בדיקה עצמית, תשובות. הדוגמה פתורה צעד אחר צעד, עם מספרים, ומסבירה למה עושים כל צעד.');
  L.push('- פרק בחוברת הסיכום קצר, עמוד או שניים, עם הכותרות ## נוסחאות ומשפטים (כל אחד עם התנאים שלו) ו־## מתי משתמשים בכל כלי (איך מזהים בשאלה איזה כלי מתאים). אם המרצה מדגיש משהו, מוסיפים ## דגשים.');
  L.push('### פרק לחוברת');
  L.push('חוברת: עזר (או: סיכום)');
  L.push('נושא: שם הנושא');
  L.push('מקורות: הקבצים שעליהם נשען הפרק, מופרדים בנקודה־פסיק');
  L.push('');
  L.push('## אינטואיציה');
  L.push('תוכן החלק, וכך הלאה לכל החלקים');
  L.push('### סוף פרק');
  return L;
}
